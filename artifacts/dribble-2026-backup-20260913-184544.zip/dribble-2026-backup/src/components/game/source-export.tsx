import { useEffect, useMemo, useRef, useState } from "react";
import { PressButton } from "@/components/ui/press-button";
import { AppFrame } from "@/components/game/app-frame";

const SOURCE_URL = "/dribble-2026-source.txt";
const ZIP_PATH = "/dribble-2026-source.zip";
const CHUNK = 160_000;

function zipLink() {
  if (typeof window === "undefined") return "";
  const host = location.hostname;
  if (host === "localhost" || host === "127.0.0.1" || host === "0.0.0.0" || host === "[::1]") return "";
  return `${location.origin}${ZIP_PATH}`;
}

export function SourceExport({ onBack }: { onBack: () => void }) {
  const [text, setText] = useState("");
  const [err, setErr] = useState("");
  const [note, setNote] = useState("Loading the zip…");
  const [part, setPart] = useState(0);
  const [link, setLink] = useState("");
  const box = useRef<HTMLTextAreaElement>(null);
  const linkBox = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setLink(zipLink());
    let alive = true;
    fetch(SOURCE_URL)
      .then((r) => {
        if (!r.ok) throw new Error(`Couldn't load source (${r.status})`);
        return r.text();
      })
      .then((t) => {
        if (!alive) return;
        setText(t);
        setNote("Share the zip, copy the zip link, or copy the text in parts.");
      })
      .catch((e) => {
        if (!alive) return;
        setErr(e instanceof Error ? e.message : "Couldn't load source");
        setNote("");
      });
    return () => {
      alive = false;
    };
  }, []);

  const parts = useMemo(() => {
    if (!text) return [];
    const out: string[] = [];
    for (let i = 0; i < text.length; i += CHUNK) out.push(text.slice(i, i + CHUNK));
    return out;
  }, [text]);
  const current = parts[part] ?? "";

  async function copyPiece(piece: string, label: string, input?: HTMLInputElement | null) {
    try {
      await navigator.clipboard.writeText(piece);
      setNote(`Copied ${label}.`);
      return;
    } catch {
      /* fall through */
    }
    const el = input ?? box.current;
    if (el) {
      el.focus();
      el.select();
      try {
        document.execCommand("copy");
        setNote(`Copied ${label}.`);
        return;
      } catch {
        /* ignore */
      }
    }
    setNote("Clipboard blocked. Long-press the field → Select All → Copy.");
  }

  async function shareZip() {
    try {
      const res = await fetch(ZIP_PATH);
      if (!res.ok) throw new Error("zip missing");
      const buf = await res.arrayBuffer();
      const file = new File([buf], "dribble-2026-source.zip", { type: "application/zip" });
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: "Dribble 2026 source.zip" });
        setNote("Shared the zip. Send that file to the other AI.");
        return;
      }
    } catch (e) {
      if (e instanceof Error && e.name === "AbortError") {
        setNote("Share cancelled.");
        return;
      }
    }
    if (link) {
      await copyPiece(link, "the zip link", linkBox.current);
      return;
    }
    window.location.assign(ZIP_PATH);
  }

  return (
    <AppFrame>
      <div className="bg-bg px-4 py-6 text-fg">
        <div className="mx-auto flex max-w-xl flex-col gap-3">
          <PressButton className="min-h-11 text-xs tracking-[0.18em] text-muted uppercase" onPress={onBack}>
            Back
          </PressButton>
          <h1 className="font-display text-3xl">Source zip</h1>
          <p className="text-sm text-muted">
            Share the zip from your phone. If you need a link, copy the one below — long-press it if the button is blocked.
          </p>
          {err ? <p className="text-sm text-loss">{err}</p> : <p className="text-sm">{note}</p>}

          {link ? (
            <label className="block">
              <span className="text-xs font-semibold tracking-wide text-muted uppercase">Zip link</span>
              <input
                ref={linkBox}
                readOnly
                value={link}
                className="mt-1 min-h-12 w-full rounded-lg border border-border bg-elevated px-3 text-sm"
                onFocus={(e) => e.currentTarget.select()}
              />
            </label>
          ) : (
            <p className="text-sm text-muted">This preview has no public host. Use Share zip instead of a URL.</p>
          )}

          <PressButton className="min-h-14 rounded-lg bg-accent font-semibold text-accent-fg" onPress={() => void shareZip()}>
            Share zip
          </PressButton>
          {link && (
            <PressButton
              className="min-h-12 rounded-lg bg-elevated font-semibold"
              onPress={() => void copyPiece(link, "the zip link", linkBox.current)}
            >
              Copy zip link
            </PressButton>
          )}
          <a
            href={ZIP_PATH}
            download="dribble-2026-source.zip"
            className="flex min-h-12 items-center justify-center rounded-lg bg-elevated font-semibold"
          >
            Open / download zip
          </a>

          <p className="mt-4 text-xs font-semibold tracking-wide text-muted uppercase">Plain text fallback</p>
          <PressButton
            disabled={!text}
            className="min-h-12 rounded-lg bg-elevated font-semibold disabled:opacity-40"
            onPress={() => void copyPiece(text, "the full source")}
          >
            Copy everything as text
          </PressButton>

          {parts.length > 1 && (
            <div className="rounded-xl border border-border bg-elevated p-3">
              <p className="text-sm font-semibold">
                Part {part + 1} of {parts.length}
              </p>
              <div className="mt-3 flex gap-2">
                <PressButton
                  disabled={part <= 0}
                  className="min-h-12 flex-1 rounded-lg bg-bg font-semibold disabled:opacity-40"
                  onPress={() => setPart((p) => Math.max(0, p - 1))}
                >
                  Previous
                </PressButton>
                <PressButton
                  disabled={!current}
                  className="min-h-12 flex-1 rounded-lg bg-accent font-semibold text-accent-fg disabled:opacity-40"
                  onPress={() => void copyPiece(current, `part ${part + 1} of ${parts.length}`)}
                >
                  Copy this part
                </PressButton>
                <PressButton
                  disabled={part >= parts.length - 1}
                  className="min-h-12 flex-1 rounded-lg bg-bg font-semibold disabled:opacity-40"
                  onPress={() => setPart((p) => Math.min(parts.length - 1, p + 1))}
                >
                  Next
                </PressButton>
              </div>
            </div>
          )}

          <textarea
            ref={box}
            readOnly
            value={current || text}
            className="min-h-40 w-full rounded-lg border border-border bg-elevated p-3 font-mono text-[11px] leading-snug"
            onFocus={(e) => e.currentTarget.select()}
          />
        </div>
      </div>
    </AppFrame>
  );
}
