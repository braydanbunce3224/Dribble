import { useGame } from "@/game/store";
import { bindTap } from "@/lib/tap";
import { AppFrame } from "@/components/game/app-frame";
import { teamOf } from "@/game/teams";

export function PresserView() {
  const { state, answer, setView } = useGame();
  if (!state?.pendingPresser) {
    return (
      <AppFrame>
      <div className="flex flex-col items-center justify-center gap-3 px-6 py-16">
        <p className="font-display text-3xl">Podium's clear</p>
        <button type="button" className="min-h-12 rounded-lg bg-accent px-6 font-semibold text-accent-fg" {...bindTap(() => setView("hub"))}>
          Back to office
        </button>
      </div>
      </AppFrame>
    );
  }
  const p = state.pendingPresser;
  const q = p.questions[p.asked];
  const school = teamOf(state.playerTeamId);
  if (!q) {
    return (
      <AppFrame>
      <div className="flex flex-col items-center justify-center gap-3 px-6 py-16">
        <p className="font-display text-3xl">Podium's clear</p>
        <button type="button" className="min-h-12 rounded-lg bg-accent px-6 font-semibold text-accent-fg" {...bindTap(() => setView("hub"))}>
          Back to office
        </button>
      </div>
      </AppFrame>
    );
  }
  return (
    <AppFrame>
    <div className="px-4 py-8">
      <div className="mx-auto flex w-full max-w-lg flex-col">
        <p className="text-xs tracking-[0.18em] text-muted uppercase">
          {school.name} · question {p.asked + 1} of {p.questions.length}
        </p>
        <h1 className="font-display mt-3 text-3xl leading-tight">{q.prompt}</h1>
        <p className="mt-3 text-sm text-muted">Say it. The room, the AD, and the fans will take it how they take it.</p>
        <div className="mt-6 flex flex-col gap-2">
          {q.choices.map((c) => (
            <button
              key={c.id}
              type="button"
              data-presser-choice={c.id}
              {...bindTap(() => answer(c.id))}
              className="min-h-14 rounded-xl border border-border bg-elevated px-4 py-3 text-left text-sm leading-snug"
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>
    </div>
    </AppFrame>
  );
}
