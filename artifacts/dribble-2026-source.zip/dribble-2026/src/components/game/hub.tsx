import { useGame } from "@/game/store";
import { TEAM_BY_ID, teamOf } from "@/game/teams";
import { identityName, nextYourGame, recordLine, recruitingProgress, unreadMail, draftWaiting, portalOpen, portalOf, campWaiting, campOf, yourAwards, goatLine, gameOfDay, awardRace, settingsOf, seriesVs, runLabel } from "@/game/engine";
import { teamChemistry } from "@/game/chemistry";
import { contractLine, contractProgress } from "@/game/contract";
import { complianceLabel, complianceNote } from "@/game/compliance";
import { tapeLine, teamTape } from "@/game/analytics";
import { hangLine, mlLabel, spreadText } from "@/game/market";
import { COACH_AXES } from "@/game/develop";
import { bindTap } from "@/lib/tap";

export function Hub() {
  const { state, simWeek, simGame, playGame, setView, nextSeason, spendSkill, saveNow, setAssisted, openContract } = useGame();
  if (!state) return null;
  const t = state.teams[state.playerTeamId];
  const school = teamOf(state.playerTeamId);
  if (!t) {
    return (
      <div className="flex flex-col gap-3">
        <h1 className="font-display text-3xl">Missing team</h1>
        <p className="text-sm text-muted">This save has no office. Load another file or start a new job.</p>
      </div>
    );
  }
  const next = nextYourGame(state);
  const opp = next ? TEAM_BY_ID[next.homeId === state.playerTeamId ? next.awayId : next.homeId] : null;
  const off = state.phase === "offseason";
  const stayWaiting = draftWaiting(state);
  const campOpen = campWaiting(state);
  const boardWaiting = Boolean(
    off && state.contractReview && !state.contractReview.resolved && (state.contractReview.decision === "fire" || state.contractReview.decision === "extend"),
  );

  return (
    <div className="flex flex-col gap-4">
      <div className="scoreboard">
        <p className="scoreboard-kicker">
          {identityName(state.identity)} · {phaseLine(state)} · {state.season}
        </p>
        <h1 className="scoreboard-name">{school.name}</h1>
        <p className="scoreboard-record">{recordLine(t)}</p>
        <p className="scoreboard-next">
          {school.conference} · prestige {t.prestige}
          {state.identity.almaMaterId && state.identity.almaMaterId !== state.playerTeamId
            ? ` · alma mater ${TEAM_BY_ID[state.identity.almaMaterId]?.name}`
            : ""}
          {" · "}
          Career {state.history.wins}-{state.history.losses}
          {state.history.seasons ? ` · ${state.history.seasons} yr` : ""}
          {state.history.titles ? ` · ${state.history.titles} title${state.history.titles === 1 ? "" : "s"}` : ""}
          {state.history.finalFour ? ` · ${state.history.finalFour} F4` : ""}
          {state.history.elite8 ? ` · ${state.history.elite8} E8` : ""}
          {state.history.sweet16 ? ` · ${state.history.sweet16} S16` : ""}
          {" · "}
          {goatLine(state)}
        </p>
      </div>

      <div className="mood-row">
        <Stat label="AD" value={state.adHeat} />
        <Stat label="Fans" value={state.fanMood} />
        <Stat label="Donors" value={state.donorMood} />
      </div>

      {next && opp && (
        <div className="tip-card">
          <p className="tip-kicker">Next tip</p>
          <p className="font-display mt-1 text-3xl leading-none">{opp.name}</p>
          <p className="mt-1 text-sm text-muted">
            {next.homeId === state.playerTeamId ? "vs" : next.site === "neutral" ? "n" : "@"} {opp.abbr} · Week {next.week} · {next.kind === "conference" ? "League" : next.kind === "noncon" ? "Non-con" : next.kind === "mte" ? "Classic" : next.kind}
          </p>
          {(() => {
            const vs = seriesVs(state, state.playerTeamId, opp.id);
            if (!vs) return null;
            const streak = vs.streak === 0 ? "" : vs.streak > 1 ? ` · ${vs.streak} in a row` : vs.streak < -1 ? ` · ${Math.abs(vs.streak)} losses` : "";
            return (
              <p className="mt-1 text-xs text-muted">
                Series {vs.aWins}-{vs.bWins}
                {vs.last ? ` · last ${vs.last}` : ""}
                {streak}
              </p>
            );
          })()}
        </div>
      )}

      <div className="gym-actions">
        {off ? (
          <button
            type="button"
            className="span-2 min-h-12 rounded-lg bg-accent font-semibold text-accent-fg"
            {...bindTap(stayWaiting ? () => setView("draft") : campOpen ? () => setView("camp") : boardWaiting ? openContract : nextSeason)}
          >
            {stayWaiting ? "Stay or go" : campOpen ? "Training camp" : boardWaiting ? "The board is waiting" : "Next season"}
          </button>
        ) : state.phase === "preseason" ? (
          <button type="button" className="span-2 min-h-12 rounded-lg bg-accent font-semibold text-accent-fg" {...bindTap(() => setView("schedule"))}>
            Customize schedule
          </button>
        ) : (
          <>
            <button type="button" className="min-h-12 rounded-lg bg-accent font-semibold text-accent-fg" {...bindTap(playGame)}>
              Play game
            </button>
            <button type="button" className="min-h-12 rounded-lg bg-elevated font-semibold" {...bindTap(simGame)}>
              Sim game
            </button>
            <button type="button" className="span-2 min-h-12 rounded-lg bg-elevated font-semibold" {...bindTap(simWeek)}>
              Sim week
            </button>
          </>
        )}
        <button type="button" className="min-h-12 rounded-lg bg-elevated font-semibold" {...bindTap(() => setView("inbox"))}>
          Inbox{unreadMail(state) ? ` (${unreadMail(state)})` : ""}
        </button>
        <button type="button" className="min-h-12 rounded-lg bg-elevated font-semibold" {...bindTap(() => saveNow())}>
          Save now
        </button>
        <button type="button" className="span-2 min-h-12 rounded-lg bg-elevated font-semibold" {...bindTap(() => setView("saves"))}>
          Files
        </button>
      </div>

      {state.phase === "selection" && state.selection && !state.selection.revealed && (
        <div className="tip-card">
          <p className="tip-kicker">Selection Day</p>
          <p className="font-display mt-1 text-2xl">The envelope is on the desk.</p>
          <p className="mt-1 text-sm text-muted">
            League tournaments are in. The committee set the field of 68. Watch the reveal before March tips.
          </p>
          <button type="button" className="mt-3 min-h-11 rounded-lg bg-accent px-3 font-semibold text-accent-fg" {...bindTap(() => setView("selection"))}>
            Watch Selection Day
          </button>
        </div>
      )}
      {state.phase === "selection" && state.selection?.revealed && (
        <div className="tip-card">
          <p className="tip-kicker">Selection Day</p>
          <p className="font-display mt-1 text-2xl">
            {(() => {
              const bid = state.selection.ncaa.find((b) => b.teamId === state.playerTeamId);
              if (bid) return `${bid.seed} seed · ${bid.region}${bid.playIn ? " · Play-in" : ""}`;
              if (state.selection.nit.includes(state.playerTeamId)) return "Invite bid";
              if (state.selection.crown.includes(state.playerTeamId)) return "The Crown";
              return "Home for March";
            })()}
          </p>
          <p className="mt-1 text-sm text-muted">
            {state.selection.ncaa.filter((b) => b.path === "auto").length} auto bids · {state.selection.ncaa.filter((b) => b.path === "at-large").length} at-large. Sim week to tip the Play-in.
          </p>
          <button type="button" className="mt-3 min-h-11 rounded-lg bg-accent px-3 font-semibold text-accent-fg" {...bindTap(() => setView("bracketology"))}>
            Open the board
          </button>
        </div>
      )}
      {(state.phase === "ncaa" || state.phase === "nit" || state.phase === "crown" || state.phase === "conference") && (
        <p className="text-sm text-muted">
          {state.phase === "conference" ? "League tournament." : state.phase === "ncaa" ? "National Tournament." : state.phase === "nit" ? "The Invite." : "The Crown."}{" "}
          Sim week to play the round; Play game when it's yours.
        </p>
      )}

      {off && <LastRunBanner />}

      {off && state.offseasonReport && (
        <div className="rounded-xl bg-elevated p-4 panel">
          <p className="text-xs tracking-widest text-muted uppercase">Development report</p>
          <p className="font-display mt-1 text-2xl">{state.season} film</p>
          <ul className="mt-3 space-y-1 text-sm">
            {state.offseasonReport.grew.length === 0 && <li className="text-muted">{campOpen ? "Camp is open. Spend the points, then lock it." : "Nobody took a leap. Minutes and morale feed the next jump."}</li>}
            {state.offseasonReport.grew.map((g) => (
              <li key={g.id}>
                {g.name}{" "}
                <span className={g.after > g.before ? "text-win" : "text-loss"}>
                  {g.before} → {g.after}
                </span>
              </li>
            ))}
          </ul>
          {state.offseasonReport.graduated.length > 0 && (
            <p className="mt-3 text-xs text-muted">Out: {state.offseasonReport.graduated.map((g) => g.name).join(", ")}</p>
          )}
          {campOpen && (
            <button type="button" className="mt-3 min-h-11 w-full rounded-lg bg-accent font-semibold text-accent-fg" {...bindTap(() => setView("camp"))}>
              Open camp · {campOf(state).points} pts
            </button>
          )}
        </div>
      )}

      <div className="desk-grid">
        <WatchStrip />
        <ChemistryStrip />
        <ContractStrip />
        <GotdStrip />
        <PotwStrip />
        <RaceStrip />
        <CardStrip />
        <AwardsStrip />
        <ComplianceStrip />
        <AnalyticsStrip />
        <MarketStrip />
        <NewsStrip />
      </div>

      <NilStrip />

      {!off && <RecruitingCard />}
      <PortalStrip />

      {!off && (
        <label className="flex min-h-14 cursor-pointer items-start gap-3 rounded-xl bg-elevated px-3 py-3 panel">
          <input
            type="checkbox"
            className="mt-1 size-5 shrink-0 accent-current"
            checked={Boolean(state.cpuRecruit)}
            onChange={(e) => setAssisted(e.target.checked)}
          />
          <span>
            <span className="block font-semibold">Assisted recruiting</span>
            <span className="text-xs text-muted">Staff finishes the class. Portal hours stay on a separate clock. Turn it off to scout, offer, and visit yourself.</span>
          </span>
        </label>
      )}
      {off && portalOpen(state) && (
        <label className="flex min-h-14 cursor-pointer items-start gap-3 rounded-xl bg-elevated px-3 py-3 panel">
          <input
            type="checkbox"
            className="mt-1 size-5 shrink-0 accent-current"
            checked={Boolean(state.cpuRecruit)}
            onChange={(e) => setAssisted(e.target.checked)}
          />
          <span>
            <span className="block font-semibold">Assisted portal</span>
            <span className="text-xs text-muted">Staff works the spring board with portal hours. High-school hours do not spend here.</span>
          </span>
        </label>
      )}

      <div className="rounded-xl bg-elevated p-4 panel">
        <p className="text-xs tracking-widest text-muted uppercase">Coach skills · {state.skillPoints ?? 0} pts</p>
        <div className="mt-3 flex flex-col gap-2">
          {COACH_AXES.map((a) => {
            const v = state.coachSkills?.[a.id] ?? 48;
            return (
              <button
                key={a.id}
                type="button"
                disabled={!state.skillPoints}
                {...bindTap(() => spendSkill(a.id))}
                className="rounded-lg bg-bg px-3 py-2 text-left disabled:opacity-60"
              >
                <span className="flex justify-between text-sm font-semibold">
                  <span>{a.label}</span>
                  <span className="tabular-nums">{v}</span>
                </span>
                <span className="mt-0.5 block text-xs text-muted">{a.hint}</span>
                <span className="interest-bar mt-1 block">
                  <span style={{ width: `${v}%` }} />
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {state.history.log.length > 0 && (
        <div className="rounded-xl bg-elevated p-4 panel">
          <p className="text-xs tracking-widest text-muted uppercase">Banner room</p>
          <ul className="mt-3 space-y-1.5 text-sm">
            {state.history.log.slice().reverse().slice(0, 12).map((y) => (
              <li key={y.season} className="flex flex-wrap justify-between gap-2">
                <span className="font-semibold">{y.season}</span>
                <span className="tabular-nums text-muted">
                  {y.wins}-{y.losses}
                  {y.confTitle ? " · league" : ""}
                  {y.run ? ` · ${runLabel(y.run)}` : y.ncaaBid ? " · National" : ""}
                  {y.title && y.run !== "title" ? " · title" : ""}
                </span>
              </li>
            ))}
          </ul>
          <button type="button" className="mt-3 min-h-11 text-sm font-semibold text-accent" {...bindTap(() => setView("hof"))}>
            Hall of Fame
          </button>
        </div>
      )}

      {state.retired && (
        <div className="rounded-xl bg-elevated p-4 panel">
          <p className="text-xs tracking-widest text-muted uppercase">Retired</p>
          <p className="font-display mt-1 text-2xl">{goatLine(state)}</p>
          <p className="mt-1 text-sm text-muted">The chair is empty. Title to start another job.</p>
        </div>
      )}
      {state.phase === "preseason" && (
        <p className="text-sm text-muted">Build the non-conference slate and a holiday classic. Staff fills the year to 30 — classics count in that 30. Begin the season when it looks right.</p>
      )}
    </div>
  );
}

function phaseLine(state: { phase: string; week: number }) {
  if (state.phase === "preseason") return "Preseason";
  if (state.phase === "regular") return `Week ${state.week}`;
  if (state.phase === "conference") return "League tournament";
  if (state.phase === "selection") return "Selection Sunday";
  if (state.phase === "ncaa") return "National Tournament";
  if (state.phase === "nit") return "The Invite";
  if (state.phase === "crown") return "The Crown";
  return "Offseason";
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="mood-cell">
      <p>{label}</p>
      <p>{value}</p>
    </div>
  );
}

function LastRunBanner() {
  const { state } = useGame();
  if (!state) return null;
  const last = state.history.log[state.history.log.length - 1];
  if (!last?.run || last.season !== state.season) return null;
  const label = runLabel(last.run);
  if (!label) return null;
  return (
    <div className="tip-card">
      <p className="tip-kicker">{last.run === "title" ? "Champions" : "March"}</p>
      <p className="font-display mt-1 text-3xl">{label}</p>
      <p className="mt-1 text-sm text-muted">
        {last.wins}-{last.losses}
        {last.confTitle ? " · league title" : ""}
        {last.poy ? ` · ${last.poy} POY` : ""}
      </p>
    </div>
  );
}

function WatchStrip() {
  const { state, setView } = useGame();
  if (!state?.watch?.length) return null;
  const yours = state.watch.find((w) => w.yours) ?? state.watch[0]!;
  return (
    <button type="button" className="desk-tile" {...bindTap(() => setView("awards"))}>
      <p className="desk-kicker">Watch list</p>
      <p className="desk-head">{yours.name}</p>
      <p className="desk-note">
        {yours.yours ? "Yours · " : ""}
        {state.watch.length} names on the preseason board
      </p>
    </button>
  );
}

function RecruitingCard() {
  const { state, setView } = useGame();
  if (!state) return null;
  const p = recruitingProgress(state);
  const pct = (n: number) => `${(n / p.spots) * 100}%`;
  return (
    <button
      type="button"
      className="desk-tile"
      {...bindTap(() => setView("recruiting"))}
    >
      <p className="desk-kicker">Class</p>
      <p className="desk-head">
        {p.signed} signed · {p.open} open
      </p>
      <div className="class-fill mt-2" aria-hidden>
        {p.returning > 0 && <i className="ret" style={{ width: pct(p.returning) }} />}
        {p.signed > 0 && <i className="sig" style={{ width: pct(p.signed) }} />}
        {p.paper > 0 && <i className="pap" style={{ width: pct(p.paper) }} />}
      </div>
      <p className="desk-note">
        {p.close} close · {p.leaning} leaning · {p.left} scholarships left
      </p>
    </button>
  );
}

function PortalStrip() {
  const { state, setView } = useGame();
  if (!state || !portalOpen(state)) return null;
  const p = portalOf(state);
  const live = p.transfers.filter((t) => !t.committedTo);
  const yours = live.filter((t) => t.fromId === state.playerTeamId).length;
  const signed = p.transfers.filter((t) => t.committedTo === state.playerTeamId).length;
  return (
    <button
      type="button"
      className="desk-tile"
      {...bindTap(() => setView("recruiting"))}
    >
      <p className="desk-kicker">{p.window === "winter" ? "Winter portal" : "Spring portal"}</p>
      <p className="desk-head">
        {live.length} names · {p.hours}h
      </p>
      <p className="desk-note">
        {yours ? `${yours} from your locker room. ` : "Nobody of yours walked. "}
        {signed ? `${signed} signed.` : "Hours stay off the high-school clock."}
      </p>
    </button>
  );
}

function ChemistryStrip() {
  const { state, setView } = useGame();
  if (!state) return null;
  const c = teamChemistry(state, state.playerTeamId);
  return (
    <button
      type="button"
      className="desk-tile"
      {...bindTap(() => setView("roster"))}
    >
      <p className="desk-kicker">Chemistry</p>
      <p className="desk-head">
        {c.score} · {c.label}
      </p>
      <p className="desk-note">{c.note}</p>
    </button>
  );
}

function ContractStrip() {
  const { state, openContract } = useGame();
  if (!state?.contract) return null;
  const review = state.contractReview;
  const live = contractProgress(state);
  const open = live.filter((r) => !r.met).length;
  const title = review && !review.resolved
    ? review.decision === "fire"
      ? "You're out"
      : review.decision === "extend"
        ? "Extension on the desk"
        : "The board met"
    : `${state.contract.remaining} yr left`;
  return (
    <button
      type="button"
      className="desk-tile"
      {...bindTap(openContract)}
    >
      <p className="desk-kicker">Contract</p>
      <p className="desk-head">{title}</p>
      <p className="desk-note">
        {review && !review.resolved ? review.letter : contractLine(state.contract)}
        {!review && open > 0 ? ` · ${open} clause${open === 1 ? "" : "s"} still open` : ""}
      </p>
    </button>
  );
}

function CardStrip() {
  const { state, setView } = useGame();
  if (!state) return null;
  const card = state.reportCard;
  const exp = state.expectations;
  if (card) {
    return (
      <button type="button" className="desk-tile" {...bindTap(() => setView("contract"))}>
        <p className="desk-kicker">Report card</p>
        <p className="desk-head">{card.overall} · {card.season}</p>
        <p className="desk-note">{card.letter}</p>
      </button>
    );
  }
  if (!exp) return null;
  return (
    <div className="desk-tile">
      <p className="desk-kicker">AD wants</p>
      <p className="desk-head">{exp.wins} wins{exp.ncaa ? " · a bid" : ""}</p>
      <p className="desk-note">{exp.note}</p>
    </div>
  );
}

function AwardsStrip() {
  const { state, setView } = useGame();
  if (!state) return null;
  const mine = yourAwards(state);
  const last = (state.awards ?? []).filter((a) => a.kind === "poy").slice(-1)[0];
  if (!mine.length && !last) return null;
  return (
    <button type="button" className="desk-tile" {...bindTap(() => setView("awards"))}>
      <p className="desk-kicker">Awards</p>
      <p className="desk-head">{mine.length ? `${mine.length} honor${mine.length === 1 ? "" : "s"}` : last ? last.name : "Lists"}</p>
      <p className="desk-note">{mine[0] ? `${mine[0].name} · ${mine[0].kind}` : last ? `National POY · ${last.season}` : "Open the hardware."}</p>
    </button>
  );
}

function ComplianceStrip() {
  const { state, setView } = useGame();
  if (!state?.compliance) return null;
  const c = state.compliance;
  return (
    <button
      type="button"
      className="desk-tile"
      {...bindTap(() => setView("compliance"))}
    >
      <p className="desk-kicker">Compliance</p>
      <p className="desk-head">
        APR {c.apr} · {complianceLabel(c)}
      </p>
      <p className="desk-note">{complianceNote(state)}</p>
    </button>
  );
}

function AnalyticsStrip() {
  const { state, setView } = useGame();
  if (!state) return null;
  const tape = teamTape(state, state.playerTeamId);
  return (
    <button
      type="button"
      className="desk-tile"
      {...bindTap(() => setView("analytics"))}
    >
      <p className="desk-kicker">Tape</p>
      <p className="desk-head">
        {tape.kp ? `${tape.kp.adjEM >= 0 ? "+" : ""}${tape.kp.adjEM.toFixed(1)} AdjEM` : "Advanced"}
      </p>
      <p className="desk-note">{tapeLine(tape)}</p>
    </button>
  );
}

function MarketStrip() {
  const { state, setView } = useGame();
  if (!state) return null;
  const next = nextYourGame(state);
  const line = next ? hangLine(state, next) : null;
  const home = line ? TEAM_BY_ID[line.homeId] : null;
  const away = line ? TEAM_BY_ID[line.awayId] : null;
  const fav = line && home && away ? spreadText(line.homeSpread, home.abbr, away.abbr) : null;
  return (
    <button
      type="button"
      className="desk-tile"
      {...bindTap(() => setView("market"))}
    >
      <p className="desk-kicker">Betting odds</p>
      <p className="desk-head">
        {fav && line ? `${fav} · ${mlLabel(line.mlHome)} / ${mlLabel(line.mlAway)}` : "Lines"}
      </p>
      <p className="desk-note">{line ? `O/U ${line.total} · ${Math.round(line.pHome * 100)}% home` : "Spread, moneyline, total"}</p>
    </button>
  );
}

function NewsStrip() {
  const { state, setView } = useGame();
  if (!state) return null;
  const a = state.news[0];
  return (
    <button
      type="button"
      className="desk-tile"
      {...bindTap(() => setView("news"))}
    >
      <p className="desk-kicker">{a?.kicker === "Takes" ? "Takes" : "News"}</p>
      <p className="desk-head">{a?.headline ?? "The Desk"}</p>
      <p className="desk-note">{a ? `${a.outlet} · ${a.kicker}` : "The wire is quiet."}</p>
    </button>
  );
}

function NilStrip() {
  const { state, answerNil, setView } = useGame();
  if (!state || !settingsOf(state).nilOn) return null;
  const open = (state.nilAsks ?? []).filter((a) => !a.resolved);
  const donor = (state.donors ?? [])[0];
  if (!open.length && !donor) return null;
  return (
    <div className="rounded-xl bg-elevated p-4 panel">
      <p className="desk-kicker">NIL</p>
      <p className="font-display mt-1 text-2xl">Pool {state.nilCap}</p>
      {donor && (
        <p className="mt-1 text-xs text-muted">
          {donor.name} moved {donor.gift >= 0 ? "+" : ""}
          {donor.gift}. Cap sits at {state.nilCap}.
        </p>
      )}
      {open.map((a) => (
        <div key={a.playerId} className="mt-3">
          <p className="text-sm font-semibold">
            {a.name} wants {a.ask}
          </p>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <button type="button" className="min-h-11 rounded-lg bg-accent text-sm font-semibold text-accent-fg" {...bindTap(() => answerNil(a.playerId, true))}>
              Pay it
            </button>
            <button type="button" className="min-h-11 rounded-lg bg-bg text-sm font-semibold" {...bindTap(() => answerNil(a.playerId, false))}>
              Pass
            </button>
          </div>
        </div>
      ))}
      <button type="button" className="mt-3 min-h-11 text-sm font-semibold text-accent" {...bindTap(() => setView("settings"))}>
        NIL settings
      </button>
    </div>
  );
}

function GotdStrip() {
  const { state, setView } = useGame();
  if (!state || state.phase === "preseason" || state.phase === "offseason") return null;
  const g = gameOfDay(state);
  if (!g) return null;
  const home = TEAM_BY_ID[g.homeId];
  const away = TEAM_BY_ID[g.awayId];
  const res = state.results.find((r) => r.slotId === g.id);
  return (
    <button type="button" className="desk-tile" {...bindTap(() => setView("news"))}>
      <p className="desk-kicker">Game of the week</p>
      <p className="desk-head">
        {away?.abbr ?? "AWAY"} at {home?.abbr ?? "HOME"}
      </p>
      <p className="desk-note">
        {res ? `${res.awayScore}–${res.homeScore} final` : `Week ${g.week} · national TV`}
      </p>
    </button>
  );
}

function PotwStrip() {
  const { state, setView } = useGame();
  if (!state) return null;
  const p = (state.potw ?? [])[0];
  if (!p) return null;
  return (
    <button type="button" className="desk-tile" {...bindTap(() => setView("awards"))}>
      <p className="desk-kicker">Player of the week</p>
      <p className="desk-head">{p.name}</p>
      <p className="desk-note">
        {p.line}
        {p.yours ? " · yours" : ` · ${TEAM_BY_ID[p.teamId]?.abbr ?? ""}`}
      </p>
    </button>
  );
}

function RaceStrip() {
  const { state, setView } = useGame();
  if (!state || state.phase === "preseason" || state.phase === "offseason") return null;
  const race = awardRace(state, 3);
  if (!race.length) return null;
  const lead = race[0]!;
  return (
    <button type="button" className="desk-tile" {...bindTap(() => setView("awards"))}>
      <p className="desk-kicker">POY race</p>
      <p className="desk-head">{lead.name}</p>
      <p className="desk-note">
        {TEAM_BY_ID[lead.teamId]?.abbr ?? ""} {lead.yours ? "· yours" : ""} · {race.map((r) => r.name.split(" ").pop()).join(" · ")}
      </p>
    </button>
  );
}

