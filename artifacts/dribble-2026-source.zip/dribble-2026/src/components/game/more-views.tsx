import { useGame } from "@/game/store";
import { RanksView } from "@/components/game/ranks-view";
import { BracketView } from "@/components/game/bracket-view";
import { NewsView } from "@/components/game/news-view";

export function MoreViews() {
  const { view } = useGame();
  if (view === "standings") return <RanksView />;
  if (view === "news") return <NewsView />;
  if (view === "bracketology") return <BracketView />;
  if (view === "bracket") return <BracketView />;
  return <RanksView />;
}