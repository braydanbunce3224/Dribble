import { useMemo, useState } from "react";
import { useGame } from "@/game/store";
import { TEAM_BY_ID } from "@/game/teams";
import { NCAA_REGIONS } from "@/game/selection";
import { recOf } from "@/game/ranks";
import type { NcaaBid, NcaaRegion } from "@/game/types";
import { bindTap } from "@/lib/tap";

type Beat = "intro" | "ones" | "twos" | "threes" | "rest" | "you";

const ORDER: Beat[] = ["intro", "ones", "twos", "threes", "rest", "you"];

export function SelectionShow() {
  const { state, finishSelectionShow } = useGame();
  const [beat, setBeat] = useState<Beat>("intro");
  const field = state?.selection?.ncaa ?? [];
  const youId = state?.playerTeamId ?? "";
  const you = field.find((b) => b.teamId === youId);
  const bySeed = useMemo(() => {
    const m = new Map<number, NcaaBid[]>();
    for (const b of field) {
      const list = m.get(b.seed) ?? [];
      list.push(b);
      m.set(b.seed, list);
    }
    return m;
  }, [field]);

  if (!state) return null;

  const i = ORDER.indexOf(beat);
  function next() {
    const n = ORDER[i + 1];
    if (!n) {
      finishSelectionShow();
      return;
    }
    setBeat(n);
  }

  const nit = state.selection?.nit.includes(youId);
  const crown = state.selection?.crown.includes(youId);
  const school = TEAM_BY_ID[youId];

  return (
    <div className="app-frame sel-show">
      <div className="sel-bar" />
      <div className="app-scroll sel-inner">
        <p className="sel-kicker">Selection Day · {state.season}</p>
        {beat === "intro" && (
          <div className="sel-beat">
            <h1 className="sel-title">The committee has set the field.</h1>
            <p className="sel-copy">
              68 teams. Four 1-seeds. Play-in in Dayton. Your name is in the envelope — or it isn’t.
            </p>
          </div>
        )}
        {beat === "ones" && <SeedLine n={1} rows={bySeed.get(1) ?? []} youId={youId} rec={(id) => recOf(state, id)} />}
        {beat === "twos" && <SeedLine n={2} rows={bySeed.get(2) ?? []} youId={youId} rec={(id) => recOf(state, id)} />}
        {beat === "threes" && <SeedLine n={3} rows={bySeed.get(3) ?? []} youId={youId} rec={(id) => recOf(state, id)} />}
        {beat === "rest" && (
          <div className="sel-beat">
            <h1 className="sel-title">The rest of the field</h1>
            <div className="sel-rest">
              {Array.from({ length: 13 }, (_, x) => x + 4).map((seed) => (
                <p key={seed}>
                  <span className="sel-seed-n">{seed}</span>
                  {(bySeed.get(seed) ?? []).map((b) => (
                    <span key={b.teamId} className={b.teamId === youId ? "sel-you" : ""}>
                      {TEAM_BY_ID[b.teamId]?.abbr ?? b.teamId}
                      {b.playIn ? "*" : ""}
                    </span>
                  ))}
                </p>
              ))}
            </div>
            <p className="sel-copy">* Play-in</p>
          </div>
        )}
        {beat === "you" && (
          <div className="sel-beat sel-envelope">
            <p className="sel-kicker">Your envelope</p>
            <h1 className="sel-title">
              {you
                ? `${you.seed} seed · ${you.region}`
                : nit
                  ? "The Invite"
                  : crown
                    ? "The Crown"
                    : "Home for March"}
            </h1>
            <p className="sel-copy">
              {school?.name} {recOf(state, youId)}
              {you ? ` · ${you.path === "auto" ? "auto bid" : "at-large"}${you.playIn ? " · Play-in" : ""}` : ""}
            </p>
          </div>
        )}
      </div>
        <div className="sel-actions">
          <button type="button" className="sel-btn" {...bindTap(next)}>
            {beat === "intro" ? "Open the envelope" : beat === "you" ? "See the bracket" : "Next"}
          </button>
          {beat !== "you" && (
            <button type="button" className="sel-skip" {...bindTap(finishSelectionShow)}>
              Skip to the board
            </button>
          )}
        </div>
    </div>
  );
}

function SeedLine({
  n,
  rows,
  youId,
  rec,
}: {
  n: number;
  rows: NcaaBid[];
  youId: string;
  rec: (id: string) => string;
}) {
  const byRegion = (r: NcaaRegion) => rows.filter((b) => b.region === r);
  return (
    <div className="sel-beat">
      <h1 className="sel-title">The {n}-seeds</h1>
      <ul className="sel-quad">
        {NCAA_REGIONS.map((region) => {
          const bids = byRegion(region);
          return (
            <li key={region} className={bids.some((b) => b.teamId === youId) ? "sel-you-card" : ""}>
              <p className="sel-reg">{region}</p>
              {bids.map((b) => (
                <p key={b.teamId} className="sel-team">
                  {TEAM_BY_ID[b.teamId]?.name}
                  <span>{rec(b.teamId)}</span>
                </p>
              ))}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
