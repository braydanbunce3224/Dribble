import { useEffect, useMemo, useState } from "react";
import { useGame } from "@/game/store";
import { CAREER_MAX_PRESTIGE, careerEligible, CONFERENCES, TEAM_BY_ID, TEAMS } from "@/game/teams";
import { loadSave } from "@/game/persist";
import { PressButton } from "@/components/ui/press-button";
import { packTitle } from "@/game/names";
import { DIFFICULTY_OPTS } from "@/game/engine";
import type { View } from "@/game/types";
import titlePoster from "@/assets/dribble-title.jpg";
import { AppFrame } from "@/components/game/app-frame";
import { bindTap } from "@/lib/tap";
import { applyMenuGo } from "@/game/menu-go";
import { isMenuArmed, onMenuArmed, peekQueuedGo } from "@/game/menu-boot";

const ERAS: { decade: number; kicker: string; blurb: string; tags: string[] }[] = [
  {
    decade: 1960,
    kicker: "Westwood's decade",
    blurb: "Westwood owns March. No three-point line, no shot clock, no NIL. The lane belongs to the bigs, and most of the country still plays in regional leagues.",
    tags: ["No 3-point line", "No shot clock", "No NIL"],
  },
  {
    decade: 1970,
    kicker: "After the dynasty",
    blurb: "The last Westwood banners, then the field cracks open. Bloomington, Milwaukee, and the independents punch up. Still no threes and no player pay — just the paint and the whistle.",
    tags: ["No 3-point line", "No NIL", "Independents matter"],
  },
  {
    decade: 1980,
    kicker: "The arc arrives",
    blurb: "1986 paints the three-point line. The Eastern league goes prime time. The Strip, The Harbor, and Bloomington set the tone. NIL does not exist; TV money does.",
    tags: ["3s from 1986", "No NIL", "Big East rise"],
  },
  {
    decade: 1990,
    kicker: "The modern game",
    blurb: "Threes are standard. Durham, Lexington, The Strip, Ann Arbor. Recruiting is the whole job and the shoe companies already know your living room. Players still cannot be paid.",
    tags: ["3-point line", "No NIL", "Recruiting is king"],
  },
  {
    decade: 2000,
    kicker: "One-and-done",
    blurb: "The NBA age rule turns rosters over every spring. Mid-majors steal March. Analytics creep onto the bench. NIL is still a rumor in the booster club.",
    tags: ["3-point line", "No NIL", "Freshman stars"],
  },
  {
    decade: 2010,
    kicker: "Portal years",
    blurb: "The three-point boom and the transfer portal (2018). Main Line, Grounds, Spokane. You develop or you reload. Pay-for-play is coming — it is not here yet.",
    tags: ["3-point line", "No NIL", "Transfer portal"],
  },
  {
    decade: 2020,
    kicker: "NIL and the carousel",
    blurb: "Name, image, and likeness is live. Conferences realign, the portal is a second recruiting season, and every AD has a donor on speed dial. This is the modern job.",
    tags: ["3-point line", "NIL is live", "Portal + realignment"],
  },
];

function eraMeta(decade: number | null) {
  return ERAS.find((e) => e.decade === decade) ?? null;
}

export function TitleFlow() {
  const { view } = useGame();
  if (view === "create") return <CreateCoach />;
  if (view === "select") return <TeamSelect />;
  if (view === "eras") return <EraSelect />;
  return <TitleScreen />;
}

function NamesEntry({ from }: { from: View }) {
  const { openNames, namesStamp } = useGame();
  void namesStamp;
  return (
    <PressButton
      className="mt-3 min-h-12 w-full rounded-lg bg-elevated px-4 py-2 text-left font-semibold shadow-[inset_0_0_0_1px_rgba(255,255,255,0.16)]"
      onPress={() => openNames(from)}
    >
      Import team names
      <span className="mt-0.5 block text-xs font-normal text-muted">Active: {packTitle()}</span>
    </PressButton>
  );
}

function clearMenuHash() {
  if (typeof window === "undefined") return;
  if (location.hash.startsWith("#hh-")) {
    history.replaceState(null, "", `${location.pathname}${location.search}`);
  }
}

function TitleBtn({
  go,
  className,
  children,
}: {
  go: string;
  className: string;
  children: React.ReactNode;
}) {
  return (
    <button type="button" className={className} data-go={go} onClick={() => applyMenuGo(go)}>
      {children}
    </button>
  );
}

function TitleScreen() {
  const toast = useGame((s) => s.toast);
  const saves = useGame((s) => s.saves);
  const [hasSave, setHasSave] = useState(false);
  const [armed, setArmed] = useState(isMenuArmed);
  const [queued, setQueued] = useState<string | null>(null);
  useEffect(() => {
    setHasSave(Boolean(loadSave()));
  }, []);
  useEffect(() => {
    setQueued(peekQueuedGo());
    return onMenuArmed(() => {
      setQueued(peekQueuedGo());
      setArmed(true);
    });
  }, []);
  const has = hasSave || saves.length > 0;
  const bootLine = queued === "career"
    ? "Career — one second."
    : queued === "dynasty"
      ? "Pick a school — one second."
      : queued === "eras"
        ? "Eras — one second."
        : queued === "continue"
          ? "Continue — one second."
          : queued === "saves"
            ? "Files — one second."
            : queued === "hof"
              ? "Hall of Fame — one second."
              : "The gym's opening";

  return (
    <div className={`title-screen${armed ? "" : " is-booting"}`}>
      <img src={titlePoster} alt="" className="title-poster" draggable={false} />
      <nav className="title-menu" aria-label="Main menu" aria-busy={!armed}>
        <h1 className="sr-only">Dribble 2026</h1>
        <div className="title-boot" aria-hidden={armed}>
          <p className="title-boot-kicker" aria-live={armed ? "off" : "polite"}>
            {bootLine}
          </p>
          <span className="title-boot-track" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-label="Loading the menu">
            <span className="title-boot-fill" />
          </span>
        </div>
        <TitleBtn go="career" className={`title-btn title-btn-primary${queued === "career" ? " is-queued" : ""}`}>
          Career
        </TitleBtn>
        <TitleBtn go="dynasty" className={`title-btn title-btn-ghost${queued === "dynasty" ? " is-queued" : ""}`}>
          Pick a school
        </TitleBtn>
        <TitleBtn go="eras" className={`title-btn title-btn-ghost${queued === "eras" ? " is-queued" : ""}`}>
          Eras
        </TitleBtn>
        {has && (
          <TitleBtn go="continue" className={`title-btn title-btn-ghost${queued === "continue" ? " is-queued" : ""}`}>
            Continue
          </TitleBtn>
        )}
        <div className="title-menu-row">
          <TitleBtn go="saves" className={`title-btn title-btn-ghost${queued === "saves" ? " is-queued" : ""}`}>
            Files
          </TitleBtn>
          <TitleBtn go="hof" className={`title-btn title-btn-ghost${queued === "hof" ? " is-queued" : ""}`}>
            Hall of Fame
          </TitleBtn>
        </div>
        {toast && <p className="mt-3 text-sm text-loss">{toast}</p>}
      </nav>
    </div>
  );
}

function EraSelect() {
  const { pickEra, setView } = useGame();
  return (
    <AppFrame>
      <div className="bg-bg px-4 py-6 text-fg">
        <div className="mx-auto max-w-xl">
          <PressButton
            className="min-h-11 text-xs tracking-[0.18em] text-muted uppercase"
            onPress={() => {
              if (location.hash.startsWith("#hh-")) history.replaceState(null, "", `${location.pathname}${location.search}`);
              setView("title");
            }}
          >
            Back
          </PressButton>
          <h1 className="font-display mt-1 text-4xl">Eras</h1>
          <p className="mt-2 text-sm text-muted">
            Pick a decade and walk into that version of college basketball. Rules, money, and the powers of the day follow the year you choose. Modern Career and Pick a school stay in today.
          </p>
          <NamesEntry from="eras" />
          <ul className="mt-6 flex flex-col gap-3">
            {ERAS.map((era) => (
              <li key={era.decade}>
                <PressButton
                  onPress={() => pickEra(era.decade)}
                  className="flex min-h-28 w-full touch-manipulation flex-col rounded-xl border border-border bg-elevated p-4 text-left"
                >
                  <span className="flex items-baseline justify-between gap-3">
                    <span className="font-display text-3xl leading-none">{era.decade}s</span>
                    <span className="text-[11px] tracking-[0.14em] text-accent uppercase">{era.kicker}</span>
                  </span>
                  <span className="mt-2 text-sm leading-snug text-muted">{era.blurb}</span>
                  <span className="mt-3 flex flex-wrap gap-1.5">
                    {era.tags.map((tag) => (
                      <span key={tag} className="rounded-full bg-bg px-2 py-0.5 text-[10px] font-semibold tracking-wide text-fg/80 uppercase">
                        {tag}
                      </span>
                    ))}
                  </span>
                </PressButton>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </AppFrame>
  );
}

function CreateCoach() {
  const { draftCoach, setDraftCoach, draftDifficulty, setDraftDifficulty, setView, selectMode, eraDecade } = useGame();
  const [q, setQ] = useState("");
  const alma = draftCoach.almaMaterId ? TEAM_BY_ID[draftCoach.almaMaterId] : null;
  const list = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return [];
    return TEAMS.filter(
      (t) =>
        t.name.toLowerCase().includes(query) ||
        t.city.toLowerCase().includes(query) ||
        t.abbr.toLowerCase().includes(query),
    ).slice(0, 12);
  }, [q]);
  const nextLabel = selectMode === "career" ? "Choose first job" : "Pick a school";
  const backTo = selectMode === "eras" ? "eras" : selectMode === "dynasty" ? "select" : "title";

  return (
    <AppFrame>
      <div className="bg-bg px-4 py-6 text-fg">
        <div className="mx-auto max-w-xl">
          <PressButton
            className="min-h-11 text-xs tracking-[0.18em] text-muted uppercase"
            onPress={() => {
              if (backTo === "title") clearMenuHash();
              setView(backTo);
            }}
          >
            Back
          </PressButton>
          <h1 className="font-display mt-1 text-4xl">Create a coach</h1>
          <p className="mt-2 text-sm text-muted">
            {selectMode === "career"
              ? "First jobs are lower-prestige schools. Name and alma mater are optional."
              : selectMode === "eras" && eraDecade
                ? `You'll walk into the ${eraDecade}s — ${eraMeta(eraDecade)?.kicker ?? "a different college game"}. Alma mater still pulls that program toward you.`
                : "Name, age, and alma mater. That school reaches further for you on the carousel."}
          </p>
          <NamesEntry from="create" />
          <p className="mt-6 text-[11px] tracking-[0.16em] text-subtle uppercase">Difficulty</p>
          <div className="mt-2 flex flex-col gap-2">
            {DIFFICULTY_OPTS.map((d) => (
              <button
                key={d.id}
                type="button"
                className={`min-h-12 rounded-lg px-3 py-2 text-left ${draftDifficulty === d.id ? "bg-accent text-accent-fg" : "bg-elevated"}`}
                {...bindTap(() => setDraftDifficulty(d.id))}
              >
                <span className="block font-semibold">{d.label}</span>
                <span className={`block text-xs ${draftDifficulty === d.id ? "text-accent-fg/80" : "text-muted"}`}>{d.hint}</span>
              </button>
            ))}
          </div>
          <PressButton
            className="mt-5 min-h-14 w-full touch-manipulation rounded-lg bg-accent px-5 font-semibold text-accent-fg"
            onPress={() => setView("select")}
          >
            {nextLabel}
          </PressButton>
          <label className="mt-6 block text-[11px] tracking-[0.16em] text-subtle uppercase">First name</label>
          <input className="mt-2 h-12 w-full rounded-lg border border-border bg-elevated px-3 text-fg" value={draftCoach.first} onChange={(e) => setDraftCoach({ first: e.target.value.slice(0, 18) })} placeholder="First" />
          <label className="mt-4 block text-[11px] tracking-[0.16em] text-subtle uppercase">Last name</label>
          <input className="mt-2 h-12 w-full rounded-lg border border-border bg-elevated px-3 text-fg" value={draftCoach.last} onChange={(e) => setDraftCoach({ last: e.target.value.slice(0, 20) })} placeholder="Last" />
          <p className="mt-5 text-[11px] tracking-[0.16em] text-subtle uppercase">Age</p>
          <div className="mt-2 flex items-center gap-3">
            <button type="button" className="h-12 w-14 rounded-lg bg-elevated" {...bindTap(() => setDraftCoach({ age: Math.max(28, draftCoach.age - 1) }))}>
              −
            </button>
            <span className="font-display min-w-16 text-center text-3xl">{draftCoach.age}</span>
            <button type="button" className="h-12 w-14 rounded-lg bg-elevated" {...bindTap(() => setDraftCoach({ age: Math.min(64, draftCoach.age + 1) }))}>
              +
            </button>
          </div>

          <p className="mt-6 text-[11px] tracking-[0.16em] text-subtle uppercase">Alma mater</p>
          <p className="mt-1 text-sm text-muted">Optional. Search to pick. They will reach further when that job opens.</p>
          {alma && (
            <p className="mt-2 text-sm text-accent">
              {alma.name} · {alma.mascot}
              <button type="button" className="ml-3 text-xs text-muted underline" {...bindTap(() => setDraftCoach({ almaMaterId: "" }))}>
                Clear
              </button>
            </p>
          )}
          <input
            className="mt-2 h-12 w-full rounded-lg border border-border bg-elevated px-3 text-fg"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search Kentucky, Gonzaga, Albany…"
          />
          <ul className="mt-2">
            {list.map((t) => (
              <li key={t.id} className="border-b border-border">
                <PressButton
                  onPress={() => {
                    setDraftCoach({ almaMaterId: t.id });
                    setQ("");
                  }}
                  className="flex min-h-14 w-full items-center gap-3 px-1 py-2 text-left"
                >
                  <span className="size-2.5 shrink-0 rounded-full" style={{ background: t.color }} />
                  <span className="flex-1">
                    <span className="block font-semibold">{t.name}</span>
                    <span className="text-xs text-muted">{t.city} · prestige {t.prestige}</span>
                  </span>
                </PressButton>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </AppFrame>
  );
}

function TeamSelect() {
  const { selectedTeamId, pickTeam, startDynasty, setView, selectMode, eraDecade, draftCoach, toast, namesStamp } = useGame();
  void namesStamp;
  const career = selectMode === "career";
  const [q, setQ] = useState("");
  const [conf, setConf] = useState<string>("ALL");
  const pool = career ? TEAMS.filter(careerEligible) : TEAMS;
  const list = useMemo(() => {
    const base = conf === "ALL" ? pool : pool.filter((t) => t.conference === conf);
    const query = q.trim().toLowerCase();
    const filtered = query
      ? base.filter((t) => t.name.toLowerCase().includes(query) || t.mascot.toLowerCase().includes(query) || t.city.toLowerCase().includes(query))
      : base;
    return [...filtered].sort((a, b) => (career ? a.prestige - b.prestige : b.prestige - a.prestige));
  }, [conf, q, pool, career]);
  const searching = q.trim().length >= 2 || conf !== "ALL";
  const shown = searching ? list.slice(0, 60) : list.slice(0, 24);
  const picked = selectedTeamId ? TEAM_BY_ID[selectedTeamId] : null;
  const alma = draftCoach.almaMaterId ? TEAM_BY_ID[draftCoach.almaMaterId] : null;
  const backTo = career || selectMode === "eras" ? "create" : "title";

  return (
    <AppFrame
      footer={
        picked ? (
          <div className="border-t border-border bg-elevated px-4 py-3" style={{ paddingBottom: "calc(0.75rem + var(--dock-pad))" }}>
            <p className="text-[11px] tracking-[0.16em] text-muted uppercase">{career ? "Career" : "Dynasty"}</p>
            <p className="font-display mt-1 text-2xl">{picked.name}</p>
            <p className="mt-1 text-sm text-muted">{picked.mascot} · prestige {picked.prestige}</p>
            <PressButton
              className="mt-3 min-h-14 w-full touch-manipulation rounded-lg bg-accent font-semibold text-accent-fg"
              onPress={() => startDynasty(picked.id)}
            >
              Take this job
            </PressButton>
            <PressButton className="mt-2 min-h-11 w-full text-sm text-muted" onPress={() => pickTeam(null)}>
              Pick a different school
            </PressButton>
          </div>
        ) : undefined
      }
    >
      <div className="bg-bg px-4 py-6 text-fg">
        <div className="mx-auto max-w-xl">
          <PressButton
            className="min-h-11 text-xs tracking-[0.18em] text-muted uppercase"
            onPress={() => {
              if (backTo === "title") clearMenuHash();
              setView(backTo);
            }}
          >
            Back
          </PressButton>
          <h1 className="font-display mt-1 text-4xl">{career ? "First job" : eraDecade ? `${eraDecade}s · ${eraMeta(eraDecade)?.kicker ?? "job"}` : "Take the job"}</h1>
          <p className="mt-2 text-sm text-muted">
            {career
              ? `Career opens at prestige ${CAREER_MAX_PRESTIGE} and under. ${pool.length} schools.`
              : eraDecade
                ? eraMeta(eraDecade)?.blurb ?? "Tap a school, then take the job."
                : "Tap a school, then take the job."}
            {alma ? ` Alma mater: ${alma.name}.` : ""}
          </p>
          <NamesEntry from="select" />
          {!career && (
            <PressButton className="mt-2 min-h-11 text-sm text-accent underline" onPress={() => setView("create")}>
              Edit coach
            </PressButton>
          )}
          {toast && <p className="mt-3 text-sm text-loss">{toast}</p>}
          {career && pool.length === 0 && <p className="mt-4 text-sm text-loss">No eligible jobs. Go back and pick a school instead.</p>}
          <input className="mt-4 h-12 w-full rounded-lg border border-border bg-elevated px-3" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search Albany, Vermont…" />
          <div className="mt-3 flex gap-2 overflow-x-auto pb-2">
            <Chip on={conf === "ALL"} onClick={() => setConf("ALL")} label="All" />
            {CONFERENCES.filter((c) => pool.some((t) => t.conference === c.id)).map((c) => (
              <Chip key={c.id} on={conf === c.id} onClick={() => setConf(c.id)} label={c.short} />
            ))}
          </div>
          <ul className="mt-2 space-y-2">
            {shown.map((t) => (
              <li key={t.id}>
                <PressButton
                  onPress={() => pickTeam(t.id)}
                  className={`flex min-h-16 w-full items-center gap-3 rounded-xl border px-3 py-2 text-left ${selectedTeamId === t.id ? "border-accent bg-elevated" : "border-border bg-elevated/60"}`}
                >
                  <span className="size-3 shrink-0 rounded-full" style={{ background: t.color }} />
                  <span className="flex-1">
                    <span className="block font-semibold">{t.name}</span>
                    <span className="text-xs text-muted">{t.mascot} · {t.city} · {t.prestige}</span>
                  </span>
                  <span className="rounded-full bg-accent/15 px-3 py-1 text-[11px] font-bold tracking-wider text-accent uppercase">
                    {selectedTeamId === t.id ? "Selected" : "Pick"}
                  </span>
                </PressButton>
              </li>
            ))}
          </ul>
          {list.length > shown.length && (
            <p className="mt-3 pb-8 text-sm text-muted">
              Showing {shown.length} of {list.length} schools. Search or pick a league to see the rest.
            </p>
          )}
          {list.length <= shown.length && list.length > 0 && (
            <p className="mt-3 pb-8 text-sm text-muted">
              {list.length} of {pool.length} schools.
            </p>
          )}
        </div>
      </div>
    </AppFrame>
  );
}

function Chip({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button type="button" {...bindTap(onClick)} className={`h-9 shrink-0 rounded-full px-3 text-sm font-semibold ${on ? "bg-accent text-accent-fg" : "bg-elevated text-fg"}`}>
      {label}
    </button>
  );
}
