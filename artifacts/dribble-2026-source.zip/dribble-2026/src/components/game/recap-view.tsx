import { useEffect } from "react";
import { useGame } from "@/game/store";
import { TEAM_BY_ID } from "@/game/teams";
import { recapFor, resultFor, yourGames } from "@/game/engine";
import { bindTap } from "@/lib/tap";
import type { GameResult, RecapPlayer } from "@/game/types";

function Board({ result }: { result: GameResult }) {
  const home = TEAM_BY_ID[result.homeId];
  const away = TEAM_BY_ID[result.awayId];
  const homeWin = result.homeScore > result.awayScore;
  return (
    <div className="recap-board">
      <div className={`recap-side ${homeWin ? "is-win" : "is-loss"}`}>
        <span className="recap-dot" style={{ background: home?.color }} />
        <div className="min-w-0">
          <p className="recap-school">{home?.name ?? result.homeId}</p>
          <p className="recap-mascot">{home?.mascot}</p>
        </div>
        <p className="recap-pts">{result.homeScore}</p>
      </div>
      <div className={`recap-side ${homeWin ? "is-loss" : "is-win"}`}>
        <span className="recap-dot" style={{ background: away?.color }} />
        <div className="min-w-0">
          <p className="recap-school">{away?.name ?? result.awayId}</p>
          <p className="recap-mascot">{away?.mascot}</p>
        </div>
        <p className="recap-pts">{result.awayScore}</p>
      </div>
    </div>
  );
}

function Line({ p }: { p: RecapPlayer }) {
  const three = p.tpa != null ? `${p.tpm ?? 0}–${p.tpa}` : "—";
  const ft = p.fta != null ? `${p.ftm ?? 0}–${p.fta}` : "—";
  return (
    <tr>
      <td className="recap-name">
        <span className="recap-pos">{p.pos}</span>
        {p.name}
      </td>
      <td>{p.min}</td>
      <td>{p.pts}</td>
      <td>{p.reb}</td>
      <td>{p.ast}</td>
      <td>
        {p.fgm}–{p.fga}
      </td>
      <td>{three}</td>
      <td>{ft}</td>
    </tr>
  );
}

function Box({ title, color, rows }: { title: string; color?: string; rows: RecapPlayer[] }) {
  return (
    <div className="recap-box">
      <p className="recap-box-h">
        <span className="recap-dot" style={{ background: color }} />
        {title}
      </p>
      <table>
        <thead>
          <tr>
            <th className="recap-name">Player</th>
            <th>MIN</th>
            <th>PTS</th>
            <th>REB</th>
            <th>AST</th>
            <th>FG</th>
            <th>3PT</th>
            <th>FT</th>
          </tr>
        </thead>
        <tbody>
          {rows.slice(0, 8).map((p) => (
            <Line key={p.id} p={p} />
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function RecapView() {
  const { state, recapId, closeRecap, openRecap } = useGame();
  const result = state
    ? state.results.find((r) => r.id === recapId) ?? [...state.results].reverse().find((r) => r.homeId === state.playerTeamId || r.awayId === state.playerTeamId)
    : undefined;
  const you = state?.playerTeamId;
  const youWin = Boolean(
    state && result && (result.homeId === you ? result.homeScore : result.awayScore) > (result.homeId === you ? result.awayScore : result.homeScore),
  );
  const slot = state && result ? state.schedule.find((g) => g.id === result.slotId) : undefined;
  const banner = Boolean(youWin && (slot?.kind === "ncaa" || slot?.kind === "conf-tourney"));
  const ncaaLeft = Boolean(
    state && you && state.schedule.some((g) => g.kind === "ncaa" && !g.resultId && (g.homeId === you || g.awayId === you)),
  );
  const national = Boolean(youWin && slot?.kind === "ncaa" && !ncaaLeft);
  useEffect(() => {
    if (!banner) return;
    try {
      navigator.vibrate?.([40, 40, 80, 40, 120]);
    } catch {
      /* no haptics */
    }
  }, [banner, result?.id]);

  if (!state) return null;
  if (!result) {
    return (
      <div className="flex flex-col gap-4">
        <h1 className="font-display text-3xl">Recap</h1>
        <p className="text-sm text-muted">No final on the board yet. Sim or play a game first.</p>
        <button type="button" className="min-h-12 rounded-lg bg-accent font-semibold text-accent-fg" {...bindTap(closeRecap)}>
          Back
        </button>
      </div>
    );
  }
  const recap = recapFor(state, result);
  const archive = yourGames(state)
    .filter((g) => g.resultId)
    .sort((a, b) => b.week - a.week)
    .slice(0, 8);

  return (
    <div className="recap-sheet">
      {banner && <TitleBurst national={Boolean(national)} />}
      <p className="recap-kicker">
        {recap.played ? "Played" : "Simulated"} · Week {result.week} · {result.minutes ?? 40} min
      </p>
      <h1 className="recap-hed">{recap.headline}</h1>
      <p className="recap-lede">{recap.lede}</p>
      <Board result={result} />
      <p className={`recap-wl ${youWin ? "text-win" : "text-loss"}`}>
        {national ? "National champions" : banner && slot?.kind === "conf-tourney" ? "League champions" : youWin ? "Win" : "Loss"}
      </p>

      <div className="recap-copy">
        {(recap.grafs ?? []).map((g, i) => (
          <p key={i}>{g}</p>
        ))}
      </div>

      <div className="recap-key">
        <p className="recap-kicker">Key sequence</p>
        <p>{recap.keyPlay}</p>
      </div>

      <div className="recap-factors">
        <div>
          <p className="recap-kicker">{TEAM_BY_ID[result.homeId]?.abbr ?? "Home"}</p>
          <p>
            {recap.homePpp.toFixed(2)} PPP · {recap.homeTo} TO · {recap.homeOrb} ORB
          </p>
        </div>
        <div>
          <p className="recap-kicker">{TEAM_BY_ID[result.awayId]?.abbr ?? "Away"}</p>
          <p>
            {recap.awayPpp.toFixed(2)} PPP · {recap.awayTo} TO · {recap.awayOrb} ORB
          </p>
        </div>
      </div>

      <Box title={TEAM_BY_ID[result.homeId]?.name ?? "Home"} color={TEAM_BY_ID[result.homeId]?.color} rows={recap.homeLeaders} />
      <Box title={TEAM_BY_ID[result.awayId]?.name ?? "Away"} color={TEAM_BY_ID[result.awayId]?.color} rows={recap.awayLeaders} />

      {recap.notes.length > 0 && (
        <ul className="recap-notes">
          {recap.notes.map((n) => (
            <li key={n}>{n}</li>
          ))}
        </ul>
      )}

      {archive.length > 1 && (
        <div className="recap-archive">
          <p className="recap-kicker">This season</p>
          <div className="recap-archive-list">
            {archive.map((g) => {
              const r = resultFor(state, g);
              if (!r) return null;
              const oppId = g.homeId === state.playerTeamId ? g.awayId : g.homeId;
              const youScore = g.homeId === state.playerTeamId ? r.homeScore : r.awayScore;
              const oppScore = g.homeId === state.playerTeamId ? r.awayScore : r.homeScore;
              const on = r.id === result.id;
              return (
                <button
                  key={g.id}
                  type="button"
                  className={`recap-chip ${on ? "is-on" : ""}`}
                  {...bindTap(() => openRecap(r.id))}
                >
                  {youScore > oppScore ? "W" : "L"} {youScore}–{oppScore} {TEAM_BY_ID[oppId]?.abbr}
                </button>
              );
            })}
          </div>
        </div>
      )}

      <button type="button" className="recap-done" {...bindTap(closeRecap)}>
        Continue
      </button>
    </div>
  );
}

function TitleBurst({ national }: { national: boolean }) {
  const bits = Array.from({ length: 28 }, (_, i) => i);
  return (
    <div className="title-burst" aria-hidden>
      {bits.map((i) => (
        <i
          key={i}
          style={{
            left: `${(i * 37) % 100}%`,
            animationDelay: `${(i % 8) * 0.08}s`,
            background: i % 3 === 0 ? "var(--color-ap-gold)" : i % 3 === 1 ? "var(--color-win)" : "var(--color-accent)",
          }}
        />
      ))}
      <p className="title-burst-line">{national ? "Cut the nets." : "League title."}</p>
    </div>
  );
}
