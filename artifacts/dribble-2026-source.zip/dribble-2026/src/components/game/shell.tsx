import { useState, type CSSProperties } from "react";
import {
  Award,
  CalendarDays,
  ClipboardList,
  Ellipsis,
  FileText,
  Scale,
  LayoutGrid,
  ListOrdered,
  Mail,
  Newspaper,
  Trophy,
  Type,
  Users,
  Activity,
  TrendingUp,
  GraduationCap,
  Dumbbell,
  Search,
  Settings,
} from "lucide-react";
import { useGame } from "@/game/store";
import { inkOn, teamOf } from "@/game/teams";
import { unreadMail, settingsOf } from "@/game/engine";
import type { View } from "@/game/types";
import { bindTap } from "@/lib/tap";

const PRIMARY: { id: View; label: string; icon: typeof LayoutGrid }[] = [
  { id: "hub", label: "Office", icon: LayoutGrid },
  { id: "roster", label: "Roster", icon: Users },
  { id: "schedule", label: "Games", icon: CalendarDays },
  { id: "recruiting", label: "Recruit", icon: ClipboardList },
];

const MORE: { id: View; label: string; icon: typeof LayoutGrid; hint: string }[] = [
  { id: "search", label: "Search", icon: Search, hint: "Players, recruits, the whole board" },
  { id: "inbox", label: "Inbox", icon: Mail, hint: "AD and donor mail" },
  { id: "news", label: "News", icon: Newspaper, hint: "Game stories, Takes, the national desk" },
  { id: "standings", label: "Ranks", icon: ListOrdered, hint: "League, Eval, Efficiency, Writers" },
  { id: "analytics", label: "Tape", icon: Activity, hint: "Four factors, usage, the next matchup" },
  { id: "market", label: "Betting odds", icon: TrendingUp, hint: "Spreads, totals, moneylines" },
  { id: "bracketology", label: "Bracket", icon: Trophy, hint: "The Desk and Sunday Board" },
  { id: "contract", label: "Contract", icon: FileText, hint: "Years, GOAT, the carousel" },
  { id: "draft", label: "Draft", icon: GraduationCap, hint: "Stay or go, mock, the league board" },
  { id: "camp", label: "Camp", icon: Dumbbell, hint: "Focus, points, redshirt after the jump" },
  { id: "awards", label: "Awards", icon: Award, hint: "Races, POTW, All-Americans" },
  { id: "compliance", label: "Compliance", icon: Scale, hint: "APR, NIL, the NCAA book" },
  { id: "hof", label: "Hall of Fame", icon: Award, hint: "Banners across every job on this device" },
  { id: "saves", label: "Saves", icon: ClipboardList, hint: "Manual files and load" },
  { id: "names", label: "Names", icon: Type, hint: "Real schools or a custom pack" },
  { id: "settings", label: "Settings", icon: Settings, hint: "Difficulty, NIL, God Mode, color" },
];

const MORE_VIEWS = new Set<View>(["inbox", "standings", "bracketology", "news", "bracket", "team", "saves", "selection", "names", "hof", "contract", "compliance", "analytics", "market", "draft", "camp", "awards", "settings", "search"]);

export function Shell({ children }: { children: React.ReactNode }) {
  const { state, view, setView, leaveToTitle, showTutorial, openNames, clearFeedback } = useGame();
  const [moreOpen, setMoreOpen] = useState(false);
  if (!state) return <>{children}</>;
  const team = teamOf(state.playerTeamId);
  const rt = state.teams[state.playerTeamId];
  const unread = unreadMail(state);
  const moreOn = MORE_VIEWS.has(view);
  const tint = settingsOf(state).teamColor;
  const shellStyle = tint
    ? ({
        "--color-accent": team.color,
        "--color-accent-fg": inkOn(team.color),
        "--team-tint": team.color,
      } as CSSProperties)
    : undefined;

  function go(id: View) {
    setMoreOpen(false);
    clearFeedback();
    if (id === "names") {
      openNames(view === "hub" ? "hub" : view);
      return;
    }
    setView(id);
  }

  return (
    <div className={`app-frame ${tint ? "is-team" : ""}`} style={shellStyle}>
      <header className="chrome-header border-b border-border">
        <div className="mx-auto flex max-w-5xl items-center gap-2 px-3 py-2">
          <span className="size-2.5 shrink-0 rounded-full" style={{ background: team.color }} />
          <span className="font-display min-w-0 flex-1 truncate text-lg">{team.name}</span>
          <span className="header-record text-sm text-muted">
            {rt ? `${rt.wins}-${rt.losses}` : "—"}
          </span>
          <button
            type="button"
            aria-label={unread ? `Mail, ${unread} unread` : "Mail"}
            {...bindTap(() => go("inbox"))}
            className="relative flex size-11 shrink-0 items-center justify-center rounded-lg text-fg"
          >
            <Mail className="size-5" />
            {unread > 0 && (
              <span className="absolute top-1.5 right-1.5 min-w-4 rounded-full bg-loss px-1 text-center text-[10px] leading-4 font-bold text-fg">
                {unread}
              </span>
            )}
          </button>
          <button type="button" className="min-h-11 shrink-0 px-2 text-xs text-muted" {...bindTap(leaveToTitle)}>
            Title
          </button>
        </div>
      </header>

      <main className="app-scroll mx-auto min-w-0 w-full max-w-5xl px-3 py-4 md:px-6">
        {children}
      </main>

      {moreOpen && (
        <div className="more-overlay" role="dialog" aria-label="More">
          <button type="button" className="more-dim" aria-label="Close" {...bindTap(() => setMoreOpen(false))} />
          <div className="more-sheet">
            <div className="more-sheet-card">
              <p className="shrink-0 px-4 pt-3 pb-2 text-[11px] tracking-[0.16em] text-muted uppercase">More</p>
              <ul className="more-sheet-list flex flex-col">
                {MORE.map((item) => {
                  const Icon = item.icon;
                  return (
                    <li key={item.id} className="border-t border-border first:border-t-0">
                      <button
                        type="button"
                        {...bindTap(() => go(item.id))}
                        className="flex min-h-14 w-full items-center gap-3 px-4 text-left"
                      >
                        <Icon className="size-4 shrink-0 text-muted" />
                        <span className="min-w-0 flex-1">
                          <span className="block font-semibold">{item.label}</span>
                          <span className="block truncate text-xs text-muted">{item.hint}</span>
                        </span>
                        {item.id === "inbox" && unread > 0 && (
                          <span className="rounded-full bg-loss px-2 py-0.5 text-[11px] font-bold">{unread}</span>
                        )}
                      </button>
                    </li>
                  );
                })}
                <li className="border-t border-border">
                  <button type="button" {...bindTap(() => { setMoreOpen(false); showTutorial(); })} className="flex min-h-12 w-full items-center px-4 text-sm text-muted">
                    Tutorial
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      <nav className="dock" aria-label="Main">
        <div className="mx-auto grid max-w-5xl grid-cols-5">
          {PRIMARY.map((item) => {
            const Icon = item.icon;
            const on = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                {...bindTap(() => go(item.id))}
                className={`flex min-h-12 min-w-0 flex-col items-center justify-center gap-0.5 px-0.5 text-[11px] leading-tight font-semibold ${on ? "text-fg" : "text-muted"}`}
              >
                <Icon className="size-4 shrink-0" />
                <span className="max-w-full truncate">{item.label}</span>
              </button>
            );
          })}
          <button
            type="button"
            {...bindTap(() => {
              clearFeedback();
              setMoreOpen((v) => !v);
            })}
            className={`flex min-h-12 min-w-0 flex-col items-center justify-center gap-0.5 px-0.5 text-[11px] leading-tight font-semibold ${moreOn || moreOpen ? "text-fg" : "text-muted"}`}
          >
            <span className="relative">
              <Ellipsis className="size-4" />
              {unread > 0 && <span className="absolute -top-1 -right-1 size-1.5 rounded-full bg-loss" />}
            </span>
            More
          </button>
        </div>
      </nav>
    </div>
  );
}
