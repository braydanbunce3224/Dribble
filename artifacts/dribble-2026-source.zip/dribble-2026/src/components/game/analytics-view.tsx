import { useMemo } from "react";
import { useGame } from "@/game/store";
import { TEAM_BY_ID } from "@/game/teams";
import { nextYourGame } from "@/game/engine";
import { gameLog, matchup, playerTape, tapeLine, teamTape } from "@/game/analytics";
import { bindTap } from "@/lib/tap";

function pct(rank: number, n = 365) {
  return Math.round(100 * (1 - (rank - 1) / Math.max(1, n - 1)));
}

function Bar({
  label,
  rank,
  fmt,
}: {
  label: string;
  value: number;
  rank: number;
  goodHigh: boolean;
  fmt: string;
}) {
  const p = pct(rank);
  return (
    <div className="tape-factor">
      <div className="tape-factor-top">
        <span>{label}</span>
        <span className="tabular-nums">{fmt}</span>
      </div>
      <span className="interest-bar">
        <span style={{ width: `${Math.max(8, p)}%` }} className={p >= 50 ? "is-good" : "is-thin"} />
      </span>
      <p className="tape-rank">{rank} national</p>
    </div>
  );
}

export function AnalyticsView() {
  const { state, openRecap } = useGame();
  if (!state) return null;
  const you = state.playerTeamId;
  const tape = useMemo(() => teamTape(state, you), [state, you]);
  const players = useMemo(() => playerTape(state, you), [state, you]);
  const log = useMemo(() => gameLog(state, you), [state, you]);
  const next = nextYourGame(state);
  const scout = next ? matchup(state, you, next.homeId === you ? next.awayId : next.homeId, next.week, next.homeId === you ? "home" : next.site === "neutral" ? "neutral" : "away") : null;
  const school = TEAM_BY_ID[you];
  const t = state.teams[you];
  const kp = tape.kp;

  return (
    <div className="tape-sheet">
      <p className="tape-kicker">The tape</p>
      <h1 className="font-display text-3xl">{school?.name ?? "Analytics"}</h1>
      <p className="mt-1 text-sm text-muted">
        {t ? `${t.wins}-${t.losses}` : "No record"} · {tapeLine(tape)}
      </p>

      {kp && (
        <div className="tape-em">
          <div>
            <p className="tape-kicker">AdjEM</p>
            <p className="tape-big tabular-nums">
              {kp.adjEM >= 0 ? "+" : ""}
              {kp.adjEM.toFixed(1)}
            </p>
            <p className="text-xs text-muted">{kp.rank} national</p>
          </div>
          <div>
            <p className="tape-kicker">AdjO</p>
            <p className="tape-mid tabular-nums">{kp.adjO.toFixed(1)}</p>
            <p className="text-xs text-muted">{kp.adjORank} · offense</p>
          </div>
          <div>
            <p className="tape-kicker">AdjD</p>
            <p className="tape-mid tabular-nums">{kp.adjD.toFixed(1)}</p>
            <p className="text-xs text-muted">{kp.adjDRank} · defense</p>
          </div>
          <div>
            <p className="tape-kicker">Tempo</p>
            <p className="tape-mid tabular-nums">{kp.adjT.toFixed(1)}</p>
            <p className="text-xs text-muted">{kp.adjTRank} · poss/40</p>
          </div>
        </div>
      )}

      {scout && (
        <div className="tape-match">
          <p className="tape-kicker">Next · week {scout.week}</p>
          <p className="font-display mt-1 text-2xl">
            {TEAM_BY_ID[scout.oppId]?.name} · {scout.expYou}–{scout.expOpp}
          </p>
          <p className="mt-1 text-sm text-muted">
            Your {scout.youAdjO.toFixed(1)} AdjO vs their {scout.oppAdjD.toFixed(1)} AdjD · {scout.tempo.toFixed(1)} possessions
          </p>
          <p className="mt-2 text-sm">{scout.note}</p>
        </div>
      )}

      <section>
        <p className="tape-kicker">Four factors · offense</p>
        <div className="tape-grid">
          <Bar label="True shooting" value={tape.off.ts} rank={tape.offRank.ts} goodHigh fmt={`${(tape.off.ts * 100).toFixed(1)}%`} />
          <Bar label="Turnover rate" value={tape.off.tov} rank={tape.offRank.tov} goodHigh={false} fmt={`${(tape.off.tov * 100).toFixed(1)}%`} />
          <Bar label="Off. boards / 100" value={tape.off.orb} rank={tape.offRank.orb} goodHigh fmt={tape.off.orb.toFixed(1)} />
          <Bar label="FT rate" value={tape.off.ftr} rank={tape.offRank.ftr} goodHigh fmt={tape.off.ftr.toFixed(2)} />
        </div>
      </section>

      <section>
        <p className="tape-kicker">Four factors · defense</p>
        <div className="tape-grid">
          <Bar label="TS% allowed" value={tape.def.ts} rank={tape.defRank.ts} goodHigh={false} fmt={`${(tape.def.ts * 100).toFixed(1)}%`} />
          <Bar label="TOs forced" value={tape.def.tov} rank={tape.defRank.tov} goodHigh fmt={`${(tape.def.tov * 100).toFixed(1)}%`} />
          <Bar label="OR allowed / 100" value={tape.def.orb} rank={tape.defRank.orb} goodHigh={false} fmt={tape.def.orb.toFixed(1)} />
          <Bar label="FT rate allowed" value={tape.def.ftr} rank={tape.defRank.ftr} goodHigh={false} fmt={tape.def.ftr.toFixed(2)} />
        </div>
      </section>

      <div className="tape-splits">
        <div>
          <p className="tape-kicker">Home</p>
          <p className="tabular-nums">
            {tape.homeW}-{tape.homeL} · {tape.homePpp.toFixed(2)} PPP
          </p>
        </div>
        <div>
          <p className="tape-kicker">Road</p>
          <p className="tabular-nums">
            {tape.awayW}-{tape.awayL} · {tape.awayPpp.toFixed(2)} PPP
          </p>
        </div>
        <div>
          <p className="tape-kicker">Luck</p>
          <p className="tabular-nums">{kp ? `${kp.luck >= 0 ? "+" : ""}${kp.luck.toFixed(3)}` : "—"}</p>
        </div>
      </div>

      <section className="tape-box">
        <p className="tape-box-h">Rotation · advanced</p>
        {players.length === 0 ? (
          <p className="px-3 py-3 text-sm text-muted">Boxes fill after a final. Sim or play.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th className="tape-name">Player</th>
                <th>GP</th>
                <th>MIN</th>
                <th>PTS</th>
                <th>P40</th>
                <th>TS%</th>
                <th>USG</th>
              </tr>
            </thead>
            <tbody>
              {players.slice(0, 10).map((p) => (
                <tr key={p.id}>
                  <td className="tape-name">
                    <span className="recap-pos">{p.pos}</span>
                    {p.name}
                  </td>
                  <td>{p.gp}</td>
                  <td>{p.min}</td>
                  <td>{p.pts}</td>
                  <td>{p.p40.toFixed(1)}</td>
                  <td>{(p.ts * 100).toFixed(1)}</td>
                  <td>{p.usg.toFixed(1)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      <section className="tape-box">
        <p className="tape-box-h">Game log</p>
        {log.length === 0 ? (
          <p className="px-3 py-3 text-sm text-muted">Nothing in the book.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Wk</th>
                <th className="tape-name">Opp</th>
                <th></th>
                <th>Score</th>
                <th>PPP</th>
                <th>TS%</th>
              </tr>
            </thead>
            <tbody>
              {log.map((g) => (
                <tr key={g.resultId}>
                  <td>{g.week}</td>
                  <td className="tape-name">
                    <button type="button" className="tape-link" {...bindTap(() => openRecap(g.resultId, "analytics"))}>
                      {g.home ? "vs" : "@"} {TEAM_BY_ID[g.oppId]?.abbr ?? g.oppId}
                    </button>
                  </td>
                  <td className={g.won ? "text-win" : "text-loss"}>{g.won ? "W" : "L"}</td>
                  <td className="tabular-nums">
                    {g.pf}–{g.pa}
                  </td>
                  <td>{g.ppp.toFixed(2)}</td>
                  <td>{(g.ts * 100).toFixed(1)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}
