import { useGame } from "@/game/store";
import { APR_LINE, complianceLabel, complianceNote } from "@/game/compliance";
import { bindTap } from "@/lib/tap";

export function ComplianceView() {
  const { state, setView } = useGame();
  if (!state) return null;
  const c = state.compliance;
  if (!c) return null;
  const nilOn = state.eraDecade == null || state.eraDecade >= 2020;

  return (
    <div className="flex flex-col gap-4">
      <button type="button" className="min-h-11 self-start text-sm font-semibold text-accent" {...bindTap(() => setView("hub"))}>
        ← Office
      </button>
      <div>
        <p className="text-xs tracking-[0.18em] text-muted uppercase">Indianapolis · the book</p>
        <h1 className="font-display mt-1 text-3xl">Compliance</h1>
        <p className="mt-1 text-sm text-muted">{complianceNote(state)}</p>
      </div>

      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="rounded-xl bg-elevated py-3">
          <p className="text-xs tracking-widest text-muted uppercase">APR</p>
          <p className={`font-display mt-1 text-2xl ${c.apr < APR_LINE ? "text-loss" : ""}`}>{c.apr}</p>
        </div>
        <div className="rounded-xl bg-elevated py-3">
          <p className="text-xs tracking-widest text-muted uppercase">Heat</p>
          <p className="font-display mt-1 text-2xl">{c.heat}</p>
        </div>
        <div className="rounded-xl bg-elevated py-3">
          <p className="text-xs tracking-widest text-muted uppercase">File</p>
          <p className="font-display mt-1 text-2xl">{complianceLabel(c)}</p>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-elevated p-4">
        <p className="text-xs tracking-[0.18em] text-muted uppercase">The 2026 book</p>
        <ul className="mt-3 space-y-2 text-sm leading-relaxed text-muted">
          <li>
            <span className="font-semibold text-fg">APR 930.</span> Bylaw 14. Fall under the line and the NCAA championship is gone. IQ and minutes on kids who can't stay eligible drag the rate.
          </li>
          <li>
            <span className="font-semibold text-fg">{nilOn ? "House pool." : "No NIL."}</span>{" "}
            {nilOn
              ? `Revenue share is a cap, not a wink. An ask over your pool is an extra-benefit file.`
              : `This era does not allow pay. Offer a kid who wants money and it's Bylaw 16.`}
          </li>
          <li>
            <span className="font-semibold text-fg">Dead period.</span> Official visits during the National, the Invite, and the Crown are a violation.
          </li>
          <li>
            <span className="font-semibold text-fg">Contact limit.</span> Three living-room visits in a week and Compliance starts counting flights.
          </li>
        </ul>
      </div>

      <div className="rounded-xl border border-border bg-elevated p-4">
        <p className="text-xs tracking-[0.18em] text-muted uppercase">File</p>
        {c.flags.length === 0 && <p className="mt-2 text-sm text-muted">No flags. Keep it that way.</p>}
        <ul className="mt-3 flex flex-col gap-3">
          {c.flags.map((f) => (
            <li key={f.id}>
              <p className="text-[11px] tracking-widest text-muted uppercase">
                {f.severity} · {f.kind} · wk {f.week}
              </p>
              <p className="mt-1 text-sm leading-relaxed">{f.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}