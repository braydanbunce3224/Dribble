import { useState } from "react";
import { useGame } from "@/game/store";
import { bindTap } from "@/lib/tap";
import { AppFrame } from "@/components/game/app-frame";

const STEPS = [
  { title: "Office", body: "The office is home. Play the next game and call every possession — motion, post, press — or sim it. The play you call is the play they run. Your contract sits under chemistry: years left, wins, and whether the board wants a National bid. Miss the last year and the carousel moves." },
  { title: "Schedule", body: "Customize the non-conference slate — home, away, or a holiday classic. Classics count in the 30. Three games a week, 30 on the year. Bigger schools can decline if your prestige is too low. Begin the season when the board looks right; staff fills empty nights." },
  { title: "Recruiting", body: "Class progress shows returning, signed, and paper out. Scout, offer, or visit and they move to Targets. 48 interest is April range; 68 is close to signing. Offers spend a scholarship." },
  { title: "Roster", body: "Tap a player for the skill chart — shoot, finish, defense, IQ — plus potential. Minutes set roles. Check-ins raise morale. Chemistry is roles, returning players, the locker room, and IQ. It shows up as the extra pass — or as nobody wanting the ball." },
  { title: "Inbox", body: "The AD and donors write. Compliance sits next to the contract: APR 930 is the NCAA line, extra benefits and dead-period visits heat the file, and a hot file or a rate under 930 takes the National bid. Use Inbox in the tab bar — or Back to office — so you're never stuck in the mail." },
  { title: "March", body: "After league tournaments, Selection Day names the 68. Ranks, news, Bracket, and the Hall of Fame live under More. The Invite and The Crown sit behind the National cut. Jobs that last — banners, bids, league titles — rank in the Hall." },
];

export function Tutorial() {
  const { skipTutorial, finishTutorial } = useGame();
  const [i, setI] = useState(0);
  const step = STEPS[i]!;
  const last = i === STEPS.length - 1;
  return (
    <AppFrame
      footer={
        <div className="flex gap-2 px-5 py-3" style={{ paddingBottom: "calc(0.75rem + var(--dock-pad))" }}>
          {i > 0 && (
            <button type="button" className="min-h-12 flex-1 rounded-lg bg-elevated font-semibold" {...bindTap(() => setI(i - 1))}>
              Back
            </button>
          )}
          <button
            type="button"
            className="min-h-12 flex-[2] rounded-lg bg-accent font-semibold text-accent-fg"
            {...bindTap(() => (last ? finishTutorial() : setI(i + 1)))}
          >
            {last ? "Take the job" : "Next"}
          </button>
        </div>
      }
    >
      <div className="px-5 py-8">
        <div className="mx-auto flex w-full max-w-lg flex-col">
        <div className="flex items-center justify-between">
          <p className="text-xs tracking-[0.18em] text-muted uppercase">How this job works</p>
          <button type="button" className="min-h-11 text-sm text-muted" {...bindTap(skipTutorial)}>
            Skip tutorial
          </button>
        </div>
        <p className="mt-6 text-xs text-subtle">{i + 1} / {STEPS.length}</p>
        <h1 className="font-display mt-2 text-4xl">{step.title}</h1>
        <p className="mt-4 text-base leading-relaxed text-muted">{step.body}</p>
        </div>
      </div>
    </AppFrame>
  );
}
