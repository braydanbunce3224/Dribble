import { Fragment, useMemo, useState } from "react";
import { useGame } from "@/game/store";
import { TEAM_BY_ID, CONFERENCES } from "@/game/teams";
import { apPoll, kenpom, netCutoff, netRanks, recOf, teamLabel, type RankKind } from "@/game/ranks";
import { bindTap } from "@/lib/tap";

export function RanksView() {
  const { state } = useGame();
  const [tab, setTab] = useState<RankKind>("league");
  const [q, setQ] = useState("");
  if (!state) return null;
  return (
    <div className="flex flex-col gap-3">
      <div>
        <h1 className="font-display text-3xl">Ranks</h1>
        <p className="mt-1 text-sm text-muted">League table, the Eval, efficiency tape, and the writers' poll.</p>
      </div>
      <div className="chip-row">
        {([
          ["league", "League"],
          ["net", "Eval"],
          ["kenpom", "Efficiency"],
          ["ap", "Writers"],
        ] as const).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={`min-h-11 rounded-full px-4 text-sm font-semibold ${tab === id ? "bg-accent text-accent-fg" : "bg-elevated"}`}
            {...bindTap(() => setTab(id))}
          >
            {label}
          </button>
        ))}
      </div>
      <input
        className="h-11 rounded-lg border border-border bg-elevated px-3 text-sm"
        placeholder="Find a team"
        value={q}
        onChange={(e) => setQ(e.target.value)}
      />
      {tab === "league" && <LeagueBoard q={q} />}
      {tab === "net" && <NetBoard q={q} />}
      {tab === "kenpom" && <KenpomBoard q={q} />}
      {tab === "ap" && <ApBoard q={q} />}
    </div>
  );
}

function matchQ(id: string, q: string) {
  if (!q.trim()) return true;
  const t = TEAM_BY_ID[id];
  const s = q.trim().toLowerCase();
  return Boolean(t && (`${t.name} ${t.mascot} ${t.abbr} ${t.conference}`).toLowerCase().includes(s));
}

function LeagueBoard({ q }: { q: string }) {
  const { state } = useGame();
  const you = state?.playerTeamId;
  const confId = you && state ? state.teams[you]?.conference : undefined;
  const rows = useMemo(() => {
    if (!state || !confId) return [];
    return Object.values(state.teams)
      .filter((t) => t.conference === confId)
      .sort((a, b) => b.confW - a.confW || b.wins - a.wins || b.confL - a.confL);
  }, [state, confId]);
  if (!state || !confId) return null;
  const conf = CONFERENCES.find((c) => c.id === confId);
  const shown = rows.filter((t) => matchQ(t.id, q));
  return (
    <div className="rank-board rank-bo">
      <div className="bo-top">
        <p className="bo-brand">{conf?.name ?? "League"}</p>
        <p className="bo-sub">Conference standings · {rows.length} schools · Week {state.week}</p>
      </div>
      <div className="rank-scroller">
        <table>
          <thead>
            <tr>
              <th>Rank</th>
              <th>Team</th>
              <th>Conf</th>
              <th>Overall</th>
            </tr>
          </thead>
          <tbody>
            {shown.map((t) => (
              <tr key={t.id} className={t.id === you ? "you" : undefined}>
                <td>{rows.indexOf(t) + 1}</td>
                <td>{teamLabel(t.id)}</td>
                <td className="tabular-nums">{t.confW}-{t.confL}</td>
                <td className="tabular-nums">{recOf(state, t.id)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function NetBoard({ q }: { q: string }) {
  const { state } = useGame();
  const rows = useMemo(() => (state ? netRanks(state) : []), [state]);
  if (!state) return null;
  const you = state.playerTeamId;
  const cut = netCutoff(rows);
  const shown = rows.filter((r) => matchQ(r.id, q));
  return (
    <div className="rank-board rank-bo">
      <div className="bo-top">
        <p className="bo-brand">Eval Board</p>
        <p className="bo-sub">National evaluation ranks with tournament résumés · Week {state.week} · {state.results.length} games · all {rows.length} teams</p>
      </div>
      <div className="rank-scroller">
      <table>
        <thead>
          <tr>
            <th>Rank</th>
            <th>Team</th>
            <th>Record</th>
            <th>Q1</th>
            <th>Q2</th>
            <th>Q3</th>
            <th>Q4</th>
            <th>Non-D1</th>
          </tr>
        </thead>
        <tbody>
          {shown.map((r) => (
            <Fragment key={r.id}>
              {r.rank === cut + 1 && !q.trim() && (
                <tr className="bo-cut">
                  <td colSpan={8}>Current National Tournament cutoff · last at-large is Eval {cut}</td>
                </tr>
              )}
              <tr id={`net-${r.id}`} className={r.id === you ? "you" : undefined}>
                <td className="tabular-nums">
                  {r.rank}
                  {r.prevRank !== r.rank && (
                    <span className={`prev ${r.prevRank > r.rank ? "up" : "down"}`}>
                      {r.prevRank} {r.prevRank > r.rank ? "▲" : "▼"}
                    </span>
                  )}
                </td>
                <td>
                  <span className="bo-name">{teamLabel(r.id, true)}</span>
                </td>
                <td className="tabular-nums">{r.wins}-{r.losses}</td>
                <td className="tabular-nums">{r.q1w}-{r.q1l}</td>
                <td className="tabular-nums">{r.q2w}-{r.q2l}</td>
                <td className="tabular-nums">{r.q3w}-{r.q3l}</td>
                <td className="tabular-nums">{r.q4w}-{r.q4l}</td>
                <td className="tabular-nums">{r.nonD1w}-{r.nonD1l}</td>
              </tr>
            </Fragment>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  );
}

function KenpomBoard({ q }: { q: string }) {
  const { state } = useGame();
  const rows = useMemo(() => (state ? kenpom(state) : []), [state]);
  if (!state) return null;
  const you = state.playerTeamId;
  const shown = rows.filter((r) => matchQ(r.id, q));
  const em = (n: number, d = 2) => `${n > 0 ? "+" : ""}${n.toFixed(d)}`;
  const luck = (n: number) => `${n > 0 ? "+" : ""}${n.toFixed(3)}`;
  return (
    <div className="rank-board rank-kp">
      <div className="kp-top">
        <p className="kp-brand">Efficiency</p>
      </div>
      <p className="kp-title">{state.season} Adjusted college basketball ratings</p>
      <p className="kp-meta">
        Adjusted to average D-I on a neutral floor. Recent games weighted more. Through week {state.week} ({state.results.length} games) · {rows.length} teams
      </p>
      <div className="rank-scroller">
      <table>
        <thead>
          <tr>
            <th>Rk</th>
            <th>Team</th>
            <th>Conf</th>
            <th className="num">W-L</th>
            <th className="num">AdjEM</th>
            <th className="num">AdjO</th>
            <th className="num">AdjD</th>
            <th className="num">AdjT</th>
            <th className="num">Luck</th>
            <th className="num">SOS</th>
            <th className="num">OppO</th>
            <th className="num">OppD</th>
            <th className="num">NCSOS</th>
          </tr>
        </thead>
        <tbody>
          {shown.map((r) => (
            <tr key={r.id} id={`kp-${r.id}`} className={r.id === you ? "you" : undefined}>
              <td className="tabular-nums">{r.rank}</td>
              <td className="kp-name">{TEAM_BY_ID[r.id]?.name}</td>
              <td>{r.conf}</td>
              <td className="num tabular-nums">{r.wins}-{r.losses}</td>
              <td className="num tabular-nums">{em(r.adjEM)}</td>
              <td className="num tabular-nums">{r.adjO.toFixed(1)}<span className="sub">{r.adjORank}</span></td>
              <td className="num tabular-nums">{r.adjD.toFixed(1)}<span className="sub">{r.adjDRank}</span></td>
              <td className="num tabular-nums">{r.adjT.toFixed(1)}<span className="sub">{r.adjTRank}</span></td>
              <td className="num tabular-nums">{luck(r.luck)}<span className="sub">{r.luckRank}</span></td>
              <td className="num tabular-nums">{em(r.sosEM)}<span className="sub">{r.sosRank}</span></td>
              <td className="num tabular-nums">{r.oppO.toFixed(1)}<span className="sub">{r.oppORank}</span></td>
              <td className="num tabular-nums">{r.oppD.toFixed(1)}<span className="sub">{r.oppDRank}</span></td>
              <td className="num tabular-nums">{em(r.ncsos)}<span className="sub">{r.ncsosRank}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  );
}

function ApBoard({ q }: { q: string }) {
  const { state } = useGame();
  const rows = useMemo(() => (state ? apPoll(state) : []), [state]);
  if (!state) return null;
  const you = state.playerTeamId;
  const shown = rows.filter((r) => matchQ(r.id, q));
  return (
    <div className="rank-board rank-ap">
      <div className="flex items-end justify-between px-3 pt-3 pb-2">
        <p className="text-xs font-bold tracking-[0.22em] text-ap-gold">WRITERS POLL</p>
        <p className="text-xs text-ap-fg/70">Men's basketball · {rows.length} teams</p>
      </div>
      <div className="rank-scroller">
      <table>
        <thead>
          <tr>
            <th>Rk</th>
            <th>Team</th>
            <th>Rec</th>
            <th>Pts</th>
            <th>1st</th>
          </tr>
        </thead>
        <tbody>
          {shown.map((r) => (
            <Fragment key={r.id}>
              {r.rank === 26 && !q.trim() && (
                <tr className="ap-cut">
                  <td colSpan={5}>Others receiving votes</td>
                </tr>
              )}
              {r.rank === 41 && !q.trim() && (
                <tr className="ap-cut">
                  <td colSpan={5}>Unranked ballot</td>
                </tr>
              )}
              <tr id={`ap-${r.id}`} className={r.id === you ? "you" : undefined}>
                <td className="tabular-nums">{r.rank}</td>
                <td className="font-semibold">{TEAM_BY_ID[r.id]?.name}</td>
                <td className="tabular-nums">{recOf(state, r.id)}</td>
                <td className="tabular-nums">{r.points || "—"}</td>
                <td className="tabular-nums">{r.first || "—"}</td>
              </tr>
            </Fragment>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  );
}
