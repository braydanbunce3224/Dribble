import { useMemo, useState } from "react";
import { useGame } from "@/game/store";
import { CONFERENCES, TEAM_BY_ID, TEAMS } from "@/game/teams";
import { DIFFICULTY_OPTS, settingsOf } from "@/game/engine";
import { bindTap } from "@/lib/tap";
import type { ConferenceId, Difficulty } from "@/game/types";

export function SettingsView() {
  const { state, patchLeague, moveTeam, setView } = useGame();
  const [q, setQ] = useState("");
  const [pick, setPick] = useState<string | null>(null);
  if (!state) return null;
  const s = settingsOf(state);
  const list = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return TEAMS.slice(0, 8);
    return TEAMS.filter(
      (t) =>
        t.name.toLowerCase().includes(query) ||
        t.abbr.toLowerCase().includes(query) ||
        t.id.includes(query) ||
        t.city.toLowerCase().includes(query),
    ).slice(0, 16);
  }, [q]);
  const chosen = pick ? TEAM_BY_ID[pick] : null;
  const live = chosen ? state.teams[chosen.id] : null;

  return (
    <div className="flex flex-col gap-4">
      <button type="button" className="min-h-11 self-start text-sm font-semibold text-accent" {...bindTap(() => setView("hub"))}>
        ← Office
      </button>
      <div>
        <p className="text-xs tracking-[0.18em] text-muted uppercase">The book</p>
        <h1 className="font-display mt-1 text-3xl">Settings</h1>
        <p className="mt-1 text-sm text-muted">Difficulty, NIL, flips, colors. God Mode for the carousel and the board.</p>
      </div>

      <div className="rounded-xl border border-border bg-elevated p-4">
        <p className="text-xs tracking-[0.18em] text-muted uppercase">Difficulty</p>
        <ul className="mt-3 flex flex-col gap-2">
          {DIFFICULTY_OPTS.map((d) => (
            <li key={d.id}>
              <button
                type="button"
                className={`min-h-14 w-full rounded-lg px-3 py-2 text-left ${s.difficulty === d.id ? "bg-accent text-accent-fg" : "bg-bg"}`}
                {...bindTap(() => patchLeague({ difficulty: d.id as Difficulty }))}
              >
                <span className="block font-semibold">{d.label}</span>
                <span className={`block text-xs ${s.difficulty === d.id ? "text-accent-fg/80" : "text-muted"}`}>{d.hint}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      <Toggle
        on={s.nilOn}
        title="NIL"
        hint="Donors, raises, and the pool. Off eras still let you kill it here."
        onToggle={(v) => patchLeague({ nilOn: v })}
      />
      <Toggle
        on={s.flipsOn}
        title="Flips and decommits"
        hint="Pledges can walk. Visits can steal them back."
        onToggle={(v) => patchLeague({ flipsOn: v })}
      />
      <Toggle
        on={s.teamColor}
        title="Team color"
        hint="Chrome picks up your school's color."
        onToggle={(v) => patchLeague({ teamColor: v })}
      />
      <Toggle
        on={s.godMode}
        title="God Mode"
        hint="Force a pledge. Move a program. Jump jobs. Force a win once."
        onToggle={(v) => patchLeague({ godMode: v, forceWin: v ? s.forceWin : false })}
      />
      {s.godMode && (
        <Toggle
          on={s.forceWin}
          title="Force the next win"
          hint="Your next sim lands on the right side. Burns after one game."
          onToggle={(v) => patchLeague({ forceWin: v })}
        />
      )}

      {s.godMode && (
        <div className="rounded-xl border border-border bg-elevated p-4">
          <p className="text-xs tracking-[0.18em] text-muted uppercase">Realignment</p>
          <p className="mt-1 text-sm text-muted">Offseason or preseason. Packed leagues swap a peer the other way.</p>
          <input
            className="mt-3 h-12 w-full rounded-lg border border-border bg-bg px-3"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search a program…"
          />
          <ul className="mt-2">
            {list.map((t) => {
              const rt = state.teams[t.id];
              return (
                <li key={t.id} className="border-t border-border first:border-t-0">
                  <button
                    type="button"
                    className={`flex min-h-12 w-full items-center justify-between gap-2 text-left text-sm ${pick === t.id ? "text-accent" : ""}`}
                    {...bindTap(() => setPick(t.id))}
                  >
                    <span className="font-semibold">{t.name}</span>
                    <span className="text-xs text-muted">{rt?.conference ?? t.conference}</span>
                  </button>
                </li>
              );
            })}
          </ul>
          {chosen && live && (
            <div className="mt-3">
              <p className="text-xs text-muted">
                {chosen.name} is in {live.conference}. Tap a league.
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {CONFERENCES.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    disabled={c.id === live.conference}
                    className="min-h-11 rounded-full bg-bg px-3 text-xs font-semibold disabled:opacity-40"
                    {...bindTap(() => moveTeam(chosen.id, c.id as ConferenceId))}
                  >
                    {c.short}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Toggle({
  on,
  title,
  hint,
  onToggle,
}: {
  on: boolean;
  title: string;
  hint: string;
  onToggle: (v: boolean) => void;
}) {
  return (
    <label className="flex min-h-14 cursor-pointer items-start gap-3 rounded-xl border border-border bg-elevated px-3 py-3">
      <input type="checkbox" className="mt-1 size-5 shrink-0 accent-current" checked={on} onChange={(e) => onToggle(e.target.checked)} />
      <span>
        <span className="block font-semibold">{title}</span>
        <span className="text-xs text-muted">{hint}</span>
      </span>
    </label>
  );
}
