import { useGame } from "@/game/store";
import { teamOf } from "@/game/teams";
import { clockLabel, crowdFill, liveYouOffense, offeredCalls, OFF_OPTS, DEF_OPTS } from "@/game/plays";
import { hangLine, mlLabel, spreadText } from "@/game/market";
import { seriesVs, winProb } from "@/game/engine";
import { bindTap } from "@/lib/tap";
import { AppFrame } from "@/components/game/app-frame";
import type { DefPlay, GameState, LiveEvent, LiveGame, OffPlay } from "@/game/types";

export function GameView() {
  const { state, runCall, simRest, leaveGame, lockPlan } = useGame();
  const live = state?.liveGame ?? undefined;
  const crowd = state && live ? crowdFill(state, live) : { home: 0.5, away: 0.2, packed: false, split: false };

  if (!state || !live) {
    return (
      <AppFrame>
      <div className="flex flex-col items-center justify-center gap-3 px-6 py-16">
        <p className="font-display text-3xl">Game's over</p>
        <button type="button" className="min-h-12 rounded-lg bg-accent px-6 font-semibold text-accent-fg" {...bindTap(leaveGame)}>
          Office
        </button>
      </div>
      </AppFrame>
    );
  }
  const home = teamOf(live.homeId);
  const away = teamOf(live.awayId);
  const youHome = live.homeId === state.playerTeamId;
  const youOff = liveYouOffense(state);
  const last = live.log.find((e) => e.kind && e.kind !== "period") ?? live.log[0];
  const ht = live.planned && live.half === 2 && !live.htAdj && !live.done;
  const calls = offeredCalls(state);

  if (!live.planned && !live.done) {
    return (
      <AppFrame
        footer={
          <div className="border-t border-border px-4 py-3" style={{ paddingBottom: "calc(0.75rem + var(--dock-pad))" }}>
            <button type="button" data-tip-off="1" className="min-h-12 w-full rounded-lg bg-accent font-semibold text-accent-fg" {...bindTap(lockPlan)}>
              Tip off
            </button>
            <button type="button" className="mt-2 min-h-11 w-full text-sm text-muted" {...bindTap(simRest)}>
              Sim rest of game
            </button>
          </div>
        }
      >
        <Pregame state={state} live={live} />
      </AppFrame>
    );
  }

  return (
    <AppFrame
      footer={
        live.done ? (
          <div className="px-4 py-3" style={{ paddingBottom: "calc(0.75rem + var(--dock-pad))" }}>
            <p className="font-display text-2xl">Final</p>
            <button type="button" className="mt-3 min-h-12 w-full rounded-lg bg-accent font-semibold text-accent-fg" {...bindTap(leaveGame)}>
              Read recap
            </button>
          </div>
        ) : (
          <div className="border-t border-border px-4 py-3" style={{ paddingBottom: "calc(0.75rem + var(--dock-pad))" }}>
            <p className="text-[11px] tracking-[0.16em] text-subtle uppercase">
              {ht ? "Halftime — mix the plan" : youOff ? "Your ball — pick a call" : "Them — pick a defense"}
            </p>
            <div className={`mt-2 grid gap-2 ${ht ? "grid-cols-3" : "grid-cols-2"}`}>
              {calls.map((c) => (
                <button
                  key={String(c.id)}
                  type="button"
                  {...bindTap(() => runCall(c.side, c.id))}
                  className="min-h-14 rounded-xl border border-border bg-elevated px-3 py-3 text-left text-sm font-semibold"
                >
                  {c.label}
                </button>
              ))}
            </div>
            <button type="button" className="mt-2 min-h-11 w-full text-sm text-muted" {...bindTap(simRest)}>
              Sim rest of game
            </button>
          </div>
        )
      }
    >
      <div className="px-4 pt-6 pb-4">
      <div className="mx-auto flex w-full max-w-lg flex-col md:max-w-2xl">
        <p className="text-xs tracking-[0.18em] text-muted uppercase">{clockLabel(live.half, live.clock)}</p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <ScoreCard name={home.abbr} score={live.homeScore} you={youHome} color={home.color} hasBall={live.poss === "home"} />
          <ScoreCard name={away.abbr} score={live.awayScore} you={!youHome} color={away.color} hasBall={live.poss === "away"} />
        </div>
        {!live.done && (
          <p className="mt-2 text-center text-xs tracking-[0.16em] text-muted uppercase">{winProb(live, youHome)}% to win</p>
        )}

        <Gamecast
          live={live}
          homeColor={home.color}
          awayColor={away.color}
          homeAbbr={home.abbr}
          crowd={crowd}
        />

        {last && (
          <div className="mt-3">
            <p className="text-sm leading-relaxed">
              <span className="text-xs text-muted">{last.t} · </span>
              {last.text}
            </p>
            {last.impact && (
              <p className={`mt-2 text-sm font-semibold ${(last.pts ?? 0) > 0 ? "text-win" : "text-loss"}`}>
                {last.impact}
              </p>
            )}
          </div>
        )}

        <ul className="mt-6 space-y-2 text-xs text-muted">
          {live.log.filter((e) => e !== last).slice(0, 10).map((e, i) => (
            <li key={`${e.t}-${i}`}>
              <span className="text-subtle">{e.t}</span> · {e.text}
            </li>
          ))}
        </ul>
      </div>
      </div>
    </AppFrame>
  );
}

function Pregame({ state, live }: { state: GameState; live: LiveGame }) {
  const { setPlan } = useGame();
  const home = teamOf(live.homeId);
  const away = teamOf(live.awayId);
  const ht = state.teams[live.homeId];
  const at = state.teams[live.awayId];
  const slot = state.schedule.find((g) => g.id === live.slotId);
  const line = slot ? hangLine(state, slot) : null;
  const youHome = live.homeId === state.playerTeamId;
  const series = seriesVs(state, live.homeId, live.awayId);
  const off = (live.planOff ?? state.gamePlan?.off ?? ["motion", "pnr", "spread"]) as OffPlay[];
  const def = (live.planDef ?? state.gamePlan?.def ?? ["man", "pack"]) as DefPlay[];
  const crowd = crowdFill(state, live);

  return (
    <div className="px-4 pt-6 pb-4">
      <div className="mx-auto flex w-full max-w-lg flex-col">
        <p className="text-xs tracking-[0.18em] text-muted uppercase">Gameplan · mix and match</p>
        <h1 className="font-display mt-1 text-3xl">
          {away.abbr} at {home.abbr}
        </h1>
        <p className="mt-1 text-sm text-muted">
          {ht ? `${ht.wins}-${ht.losses}` : "—"} · {at ? `${at.wins}-${at.losses}` : "—"}
          {line ? ` · ${spreadText(line.homeSpread, home.abbr, away.abbr)} · O/U ${line.total} · ${youHome ? mlLabel(line.mlHome) : mlLabel(line.mlAway)}` : ""}
        </p>
        {series && (
          <p className="mt-1 text-xs text-muted">
            All-time {series.aWins}-{series.bWins}
            {series.last ? ` · last ${series.last}` : ""}
            {series.streak > 1 ? ` · ${home.abbr} ${series.streak} in a row` : series.streak < -1 ? ` · ${away.abbr} ${Math.abs(series.streak)} in a row` : ""}
          </p>
        )}
        <p className="mt-2 text-xs text-muted">
          {crowd.split ? "Split crowd" : crowd.packed ? "Building is packed" : "Home gym"} · {Math.round(crowd.home * 100)}% house
        </p>

        <p className="mt-5 text-xs tracking-[0.16em] text-muted uppercase">Offense · 1st / 2nd / 3rd look</p>
        <div className="mt-2 flex flex-col gap-2">
          {off.slice(0, 3).map((id, i) => (
            <PlanRow
              key={`off-${i}`}
              label={i === 0 ? "1st" : i === 1 ? "2nd" : "3rd"}
              value={OFF_OPTS.find((o) => o.id === id)?.label ?? id}
              options={OFF_OPTS}
              onPick={(next) => setPlan("off", i, next)}
            />
          ))}
        </div>
        <p className="mt-5 text-xs tracking-[0.16em] text-muted uppercase">Defense · primary / change</p>
        <div className="mt-2 flex flex-col gap-2">
          {def.slice(0, 2).map((id, i) => (
            <PlanRow
              key={`def-${i}`}
              label={i === 0 ? "Base" : "Change"}
              value={DEF_OPTS.find((o) => o.id === id)?.label ?? id}
              options={DEF_OPTS}
              onPick={(next) => setPlan("def", i, next)}
            />
          ))}
        </div>
        <p className="mt-4 text-xs text-muted">
          {youHome ? "You have the home floor." : "Road gym. The plan still tips first."}
        </p>
      </div>
    </div>
  );
}

function PlanRow<T extends string>({
  label,
  value,
  options,
  onPick,
}: {
  label: string;
  value: string;
  options: { id: T; label: string }[];
  onPick: (id: T) => void;
}) {
  return (
    <div className="rounded-xl border border-border bg-elevated p-3">
      <p className="text-[11px] tracking-widest text-muted uppercase">{label} · {value}</p>
      <div className="mt-2 flex flex-wrap gap-1">
        {options.map((o) => (
          <button
            key={o.id}
            type="button"
            className={`min-h-10 rounded-lg px-2 text-xs font-semibold ${o.label === value ? "bg-accent text-accent-fg" : "bg-bg"}`}
            {...bindTap(() => onPick(o.id))}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function ScoreCard({ name, score, you, color, hasBall }: { name: string; score: number; you: boolean; color: string; hasBall: boolean }) {
  return (
    <div className={`rounded-xl border px-3 py-3 ${you ? "border-accent bg-elevated" : "border-border bg-surface"}`}>
      <p className="flex items-center gap-2 text-[11px] tracking-widest uppercase">
        <span className="size-2 rounded-full" style={{ background: color }} />
        {name} {you ? "· you" : ""}
        {hasBall && <span className="ml-auto text-[10px] tracking-normal text-accent">ball</span>}
      </p>
      <p className="font-display mt-1 text-4xl tabular-nums">{score}</p>
    </div>
  );
}

function runHeat(log: LiveEvent[]): number {
  let pts = 0;
  for (const e of log) {
    if (!e.kind || e.kind === "period") continue;
    const scored = Boolean(e.made) && (e.pts ?? 0) > 0;
    if (e.poss === "away" && scored) break;
    if (e.poss === "home" && scored) pts += e.pts ?? 0;
  }
  if (pts <= 0) return 0;
  if (pts <= 4) return 0.18;
  if (pts <= 7) return 0.4;
  if (pts <= 11) return 0.68;
  if (pts <= 15) return 0.88;
  return 1;
}

function Gamecast({
  live,
  homeColor,
  awayColor,
  homeAbbr,
  crowd,
}: {
  live: LiveGame;
  homeColor: string;
  awayColor: string;
  homeAbbr: string;
  crowd: { home: number; away: number; packed: boolean; split: boolean };
}) {
  const marks = live.log.filter((e) => e.kind && e.kind !== "period" && e.x != null && e.y != null).slice(0, 12);
  const last = marks[0];
  const heat = runHeat(live.log);
  const house = heat >= 0.68
    ? "The building is up"
    : crowd.split
      ? "Split crowd"
      : crowd.packed
        ? "Packed house"
        : "Gamecast";
  return (
    <div className="mt-4 overflow-hidden rounded-xl border border-border bg-[#1a3a24]">
      <svg viewBox="0 0 94 56" className="block h-auto w-full" role="img" aria-label="Gamecast floor">
        <rect width="94" height="50" fill="#1a3a24" />
        <rect x="1" y="1" width="92" height="48" fill="none" stroke="rgba(242,241,236,0.35)" strokeWidth="0.4" />
        <line x1="47" y1="1" x2="47" y2="49" stroke="rgba(242,241,236,0.28)" strokeWidth="0.3" />
        <circle cx="47" cy="25" r="6" fill="none" stroke="rgba(242,241,236,0.28)" strokeWidth="0.3" />
        <circle cx="47" cy="25" r="3.6" fill={homeColor} opacity="0.35" />
        <text x="47" y="26.4" textAnchor="middle" fontSize="2.4" fill="rgba(242,241,236,0.9)" fontFamily="system-ui, sans-serif" fontWeight="700">
          {homeAbbr.slice(0, 4)}
        </text>
        <Key x={0} />
        <Key x={75} />
        <Arc cx={5.25} right={false} />
        <Arc cx={88.75} right />
        <Hoop cx={5.25} />
        <Hoop cx={88.75} />
        {marks.slice().reverse().map((e, i) => (
          <Mark key={`${e.t}-${i}`} e={e} homeColor={homeColor} awayColor={awayColor} dim={e !== last} />
        ))}
        <Crowd y={50.4} fill={Math.min(1, crowd.home + heat * 0.18)} color={homeColor} side="left" />
        <Crowd y={50.4} fill={crowd.away} color={awayColor} side="right" />
      </svg>
      <div className="flex items-center justify-between bg-black/35 px-3 py-1.5 text-[10px] tracking-widest text-[#d5e0d4] uppercase">
        <span data-crowd-heat={heat.toFixed(2)}>{house}</span>
        <span>
          {last?.kind === "three" ? "3PT" : last?.kind === "two" ? "2PT" : last?.kind === "ft" ? "FT" : last?.kind === "to" ? "TO" : "LIVE"}
          {last && last.kind !== "period" ? (last.made ? " · good" : last.kind === "to" ? "" : " · miss") : ""}
        </span>
      </div>
    </div>
  );
}

function Crowd({ y, fill, color, side }: { y: number; fill: number; color: string; side: "left" | "right" }) {
  const n = 18;
  const dots = Array.from({ length: n }, (_, i) => i);
  const lit = Math.round(n * fill);
  const start = side === "left" ? 3 : 49;
  return (
    <g>
      {dots.map((i) => (
        <rect
          key={`${side}-${i}`}
          x={start + i * 2.3}
          y={y}
          width="1.8"
          height="4.2"
          rx="0.3"
          fill={i < lit ? color : "rgba(242,241,236,0.12)"}
          opacity={i < lit ? 0.85 : 0.35}
        />
      ))}
    </g>
  );
}

function Key({ x }: { x: number }) {
  return (
    <g>
      <rect x={x + 1} y="16" width="18" height="18" fill="none" stroke="rgba(242,241,236,0.28)" strokeWidth="0.3" />
      <circle cx={x + 19} cy="25" r="6" fill="none" stroke="rgba(242,241,236,0.22)" strokeWidth="0.3" />
    </g>
  );
}

function Arc({ cx, right }: { cx: number; right: boolean }) {
  const s = right ? 1 : -1;
  return (
    <path
      d={`M ${cx + s * 3} 3.2 L ${cx + s * 3} 8 A 22.15 22.15 0 0 ${right ? 1 : 0} ${cx + s * 3} 42 L ${cx + s * 3} 46.8`}
      fill="none"
      stroke="rgba(242,241,236,0.32)"
      strokeWidth="0.3"
    />
  );
}

function Hoop({ cx }: { cx: number }) {
  return (
    <g>
      <line x1={cx < 47 ? 1 : 93} y1="17" x2={cx < 47 ? 1 : 93} y2="33" stroke="rgba(242,241,236,0.4)" strokeWidth="0.5" />
      <circle cx={cx} cy="25" r="0.9" fill="none" stroke="#c45c3e" strokeWidth="0.35" />
    </g>
  );
}

function Mark({ e, homeColor, awayColor, dim }: { e: LiveEvent; homeColor: string; awayColor: string; dim: boolean }) {
  const fill = e.poss === "away" ? awayColor : homeColor;
  const r = e.kind === "three" ? 1.35 : 1.1;
  if (e.kind === "to") {
    return (
      <g opacity={dim ? 0.35 : 1} transform={`translate(${e.x}, ${e.y})`}>
        <line x1={-1.2} y1={-1.2} x2={1.2} y2={1.2} stroke="#c48982" strokeWidth="0.45" />
        <line x1={1.2} y1={-1.2} x2={-1.2} y2={1.2} stroke="#c48982" strokeWidth="0.45" />
      </g>
    );
  }
  return (
    <circle
      cx={e.x}
      cy={e.y}
      r={r}
      fill={e.made ? fill : "none"}
      stroke={fill}
      strokeWidth="0.45"
      opacity={dim ? 0.4 : 1}
    />
  );
}
