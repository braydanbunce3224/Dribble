import type { Award, GameState, Player } from "./types";
import { TEAM_BY_ID } from "./teams";

function score(p: Player) {
  const min = p.seasonMinutes || p.mpg * Math.max(1, p.seasonGames);
  const usage = p.usage ?? clampUse(p.mpg);
  return min * (0.55 + p.ovr / 180) * (0.7 + usage / 80) * (0.85 + (p.skills.shoot + p.skills.finish) / 400);
}

function clampUse(mpg: number) {
  return Math.max(8, Math.min(38, Math.round(mpg * 2.15)));
}

function nm(p: Player) {
  return `${p.first} ${p.last}`;
}

function row(kind: Award["kind"], team: Award["team"], p: Player, you: string): Award {
  return {
    season: 0,
    kind,
    team,
    playerId: p.id,
    teamId: p.teamId,
    name: nm(p),
    pos: p.pos,
    yours: p.teamId === you,
  };
}

export function rollAwards(state: GameState): Award[] {
  const you = state.playerTeamId;
  const pool = state.players.filter((p) => (p.seasonGames ?? 0) >= 6 && !p.redshirt);
  if (pool.length < 20) return [];
  const ranked = pool.slice().sort((a, b) => score(b) - score(a) || b.ovr - a.ovr);
  const out: Award[] = [];
  const poy = ranked[0];
  if (poy) out.push({ ...row("poy", "", poy, you), season: state.season });

  const dpool = pool.slice().sort((a, b) => b.skills.defense * (b.mpg + 4) - a.skills.defense * (a.mpg + 4) || b.ovr - a.ovr);
  if (dpool[0] && dpool[0].id !== poy?.id) out.push({ ...row("dpoy", "", dpool[0], you), season: state.season });
  else if (dpool[1]) out.push({ ...row("dpoy", "", dpool[1], you), season: state.season });

  const frosh = pool.filter((p) => p.year === 1).sort((a, b) => score(b) - score(a))[0];
  if (frosh) out.push({ ...row("freshman", "", frosh, you), season: state.season });

  const aaTeams: Award["team"][] = ["1st", "1st", "1st", "1st", "1st", "2nd", "2nd", "2nd", "2nd", "2nd", "3rd", "3rd", "3rd", "3rd", "3rd"];
  ranked.slice(0, 15).forEach((p, i) => {
    out.push({ ...row("all-american", aaTeams[i] ?? "3rd", p, you), season: state.season });
  });

  const byConf = new Map<string, Player[]>();
  for (const p of pool) {
    const conf = state.teams[p.teamId]?.conference ?? TEAM_BY_ID[p.teamId]?.conference ?? "SEC";
    const a = byConf.get(conf);
    if (a) a.push(p);
    else byConf.set(conf, [p]);
  }
  for (const [, list] of byConf) {
    const top = list.sort((a, b) => score(b) - score(a)).slice(0, 10);
    top.forEach((p, i) => {
      out.push({ ...row("all-conf", i < 5 ? "1st" : "2nd", p, you), season: state.season });
    });
  }

  const coachPool = Object.values(state.teams).slice().sort((a, b) => {
    const aw = a.wins - a.losses;
    const bw = b.wins - b.losses;
    return bw - aw || b.confW - a.confW;
  });
  const coach = coachPool[0];
  if (coach) {
    out.push({
      season: state.season,
      kind: "coach",
      team: "",
      teamId: coach.id,
      name: coach.coachName || TEAM_BY_ID[coach.id]?.name || "Staff",
      yours: coach.id === you,
    });
  }
  return out;
}

export function awardLine(a: Award) {
  if (a.kind === "poy") return `National Player of the Year · ${a.name}`;
  if (a.kind === "dpoy") return `Defensive Player of the Year · ${a.name}`;
  if (a.kind === "freshman") return `Freshman of the Year · ${a.name}`;
  if (a.kind === "coach") return `Coach of the Year · ${a.name}`;
  if (a.kind === "all-american") return `All-American ${a.team} · ${a.name}`;
  return `All-Conference ${a.team} · ${a.name}`;
}

export function yourAwards(state: GameState, season?: number) {
  const yr = season ?? state.season;
  return (state.awards ?? []).filter((a) => a.season === yr && a.yours);
}
