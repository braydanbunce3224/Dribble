import type { GameState, Mail } from "./types";
import { TEAM_BY_ID } from "./teams";
import { hashString, mulberry32, pick, type Rng } from "./rng";
import { identityName } from "./engine-util";
import type { GameCtx } from "./presser";

function mail(partial: Omit<Mail, "read">): Mail {
  return { ...partial, read: false };
}

export function afterGameMail(state: GameState, ctx: GameCtx): Mail[] {
  const rng = mulberry32(state.seed ^ hashString(ctx.slotId) ^ 0xbad);
  const out: Mail[] = [];
  if (rng() < 0.42) out.push(adNote(state, ctx, rng));
  if (rng() < 0.34) out.push(fanNote(state, ctx, rng));
  if (rng() < 0.3) out.push(boosterNote(state, ctx, rng));
  return [...out, ...state.mail].slice(0, 40);
}

export function weeklyStakeholderMail(state: GameState, week: number): Mail[] {
  const rng = mulberry32(state.seed ^ (week * 4243));
  if (week < 2) return state.mail;
  if (rng() > 0.55) return state.mail;
  const t = state.teams[state.playerTeamId]!;
  const pct = t.wins + t.losses ? t.wins / (t.wins + t.losses) : 0.5;
  const who = pick(rng, ["ad", "fan", "booster"] as const);
  const extra =
    who === "ad" ? adWeekly(state, pct, week, rng) : who === "fan" ? fanWeekly(state, pct, week, rng) : boosterWeekly(state, pct, week, rng);
  return [extra, ...state.mail].slice(0, 40);
}

export function presserFollowup(state: GameState, ad: number, fans: number, morale: number): Mail {
  const rng = mulberry32(state.seed ^ (state.week * 17) ^ (ad * 9 + fans * 5 + morale));
  const name = identityName(state.identity);
  const school = TEAM_BY_ID[state.playerTeamId]!;
  if (ad >= 3) {
    return mail({
      id: `press-${state.week}-${state.results.length}-ad`,
      from: "Athletic Director",
      subject: pick(rng, ["That's the job", "The board heard you", "Keep that voice"]),
      body: pick(rng, [
        `${name}, that's how you talk for this place. The board texted me before I got back to the suite.`,
        `Clean. Short. No mess for me to clean. Do that again after the next one.`,
        `Donors like a coach who sounds like he has a plan. Tonight you did.`,
      ]),
      week: state.week,
      tone: "good",
    });
  }
  if (ad <= -3) {
    return mail({
      id: `press-${state.week}-${state.results.length}-ad`,
      from: "Athletic Director",
      subject: pick(rng, ["Watch the mic", "My phone is hot", "Not in my building"]),
      body: pick(rng, [
        `You made my night harder. The board watches the podium too. Next time think about who is standing behind the cameras.`,
        `${name}: I don't need a viral clip. I need a coach who doesn't set the alumni on fire.`,
        `If you want to fight the media, do it in my office, not on the record. We're ${school.name}. Act like it.`,
      ]),
      week: state.week,
      tone: "bad",
    });
  }
  return mail({
    id: `press-${state.week}-${state.results.length}-ad`,
    from: "Athletic Director",
    subject: pick(rng, ["Noted", "Fine", "Just win one"]),
    body: pick(rng, [
      `Fine. Just win the next one so I don't have to explain the quotes.`,
      `I can live with that. Don't make me live with a losing streak on top of it.`,
      `Noted. The podium is not the problem. The scoreboard might be.`,
    ]),
    week: state.week,
    tone: "even",
  });
}

function adNote(state: GameState, ctx: GameCtx, rng: Rng): Mail {
  const name = identityName(state.identity);
  if (ctx.won && ctx.margin >= 12) {
    return mail({
      id: `adg-${ctx.slotId}`,
      from: "Athletic Director",
      subject: pick(rng, ["That's more like it", "The suite was loud", "Keep stacking"]),
      body: pick(rng, [
        `${ctx.youScore}-${ctx.oppScore} against ${ctx.oppName}. That's the version of us I sold in July.`,
        `${name}, the suite stayed on its feet. Do not let this be a one-off.`,
        `I can raise money on nights like this. Give me a few more.`,
      ]),
      week: ctx.week,
      tone: "good",
    });
  }
  if (!ctx.won && ctx.margin >= 12) {
    return mail({
      id: `adg-${ctx.slotId}`,
      from: "Athletic Director",
      subject: pick(rng, ["We need a response", "Not why we hired you", "Call me tomorrow"]),
      body: pick(rng, [
        `${ctx.record} after ${ctx.oppName}. That is not why we hired you. I need a stretch of basketball that looks like a plan.`,
        `I'm going to get questions at breakfast. I need something better than "we'll watch the film."`,
        `${name}: a ${ctx.margin}-point night in this league puts my job next to yours. Fix the thing that is broken.`,
      ]),
      week: ctx.week,
      tone: "bad",
    });
  }
  if (ctx.won) {
    return mail({
      id: `adg-${ctx.slotId}`,
      from: "Athletic Director",
      subject: pick(rng, ["Good", "Bank it", "On to the next"]),
      body: pick(rng, [
        `${ctx.record}. Bank it. Don't get cute with the next one.`,
        `A win is a win. The board likes the column more than the style points.`,
        `We're still in it. Keep the locker room on this side of the ball.`,
      ]),
      week: ctx.week,
      tone: "good",
    });
  }
  return mail({
    id: `adg-${ctx.slotId}`,
    from: "Athletic Director",
    subject: pick(rng, ["Checking in", "One night", "Get the next"]),
    body: pick(rng, [
      `${ctx.record} after ${ctx.oppName}. Get the next one and this stays a footnote.`,
      `I didn't love the body language. I don't need a speech. I need a response on the floor.`,
      `We're still in it if you say we are. Say it in the gym, not in my inbox.`,
    ]),
    week: ctx.week,
    tone: "even",
  });
}

function fanNote(state: GameState, ctx: GameCtx, rng: Rng): Mail {
  const from = pick(rng, ["Season-ticket holder", "Student section", "Message board", "Alumni chapter"]);
  if (ctx.won) {
    return mail({
      id: `fang-${ctx.slotId}`,
      from,
      subject: pick(rng, ["That's our team", "We felt that one", "More of that"]),
      body: pick(rng, [
        `${ctx.oppName} came in loud. You sent them out quiet. Do it again Saturday.`,
        `The upper deck was standing. Don't forget who fills it when the weather is bad.`,
        `${ctx.youScore}-${ctx.oppScore}. That's the version we bought tickets for.`,
      ]),
      week: ctx.week,
      tone: "good",
    });
  }
  return mail({
    id: `fang-${ctx.slotId}`,
    from,
    subject: pick(rng, ["Show something", "We've seen this", "Get mad"]),
    body: pick(rng, [
      `We've sat through worse. Don't make us sit through indifferent.`,
      `${ctx.oppName} wanted it more. That's the part I can't explain to the people I dragged here.`,
      `Boos are honest. Take them personally. Then go win.`,
    ]),
    week: ctx.week,
    tone: "bad",
  });
}

function boosterNote(state: GameState, ctx: GameCtx, rng: Rng): Mail {
  const nil = ctx.nil;
  const from = nil ? pick(rng, ["NIL collective", "Lead donor", "Collective board"]) : pick(rng, ["Booster club", "Letterwinner", "Tip-off club"]);
  if (ctx.won) {
    return mail({
      id: `bstr-${ctx.slotId}`,
      from,
      subject: pick(rng, ["We're in", "That's fundable", "Keep feeding us wins"]),
      body: nil
        ? pick(rng, [
            `Nights like ${ctx.oppName} make the phone ring. Keep the roster together and the checks stay easy.`,
            `I can sell this. Don't go cheap in the portal if we're actually trying.`,
            `The collective will do its part if the product looks like this.`,
          ])
        : pick(rng, [
            `That's the kind of night that fills the golf outing. Thank you.`,
            `The tip-off club is happy. Keep them that way.`,
            `I wrote a check in 1998. Nights like this are why.`,
          ]),
      week: ctx.week,
      tone: "good",
    });
  }
  return mail({
    id: `bstr-${ctx.slotId}`,
    from,
    subject: pick(rng, ["Harder to raise", "We're watching", "Product question"]),
    body: nil
      ? pick(rng, [
          `It's hard to ask people for NIL money after a night like ${ctx.oppName}. Give me something to sell.`,
          `The collective isn't a charity. Put a team on the floor that looks invested.`,
          `We're not walking. We're waiting. Don't make us wait into March.`,
        ])
      : pick(rng, [
          `The golf outing got quieter. Wins talk. This didn't.`,
          `I've been in the building since the old gym. This group looks soft.`,
          `We'll still show up. It would help if they did too.`,
        ]),
    week: ctx.week,
    tone: "bad",
  });
}

function adWeekly(state: GameState, pct: number, week: number, rng: Rng): Mail {
  const t = state.teams[state.playerTeamId]!;
  const tone = pct >= 0.6 ? "good" : pct <= 0.38 ? "bad" : "even";
  return mail({
    id: `adw-${week}`,
    from: "Athletic Director",
    subject: tone === "good" ? pick(rng, ["The building believes", "Keep the line moving", "Board is calm"]) : tone === "bad" ? pick(rng, ["We need a response", "Temperature check", "My week"]) : pick(rng, ["Checking in", "Still in it", "Week " + week]),
    body:
      tone === "good"
        ? pick(rng, [
            `${t.wins}-${t.losses}. Donors are picking up the phone. Keep the locker room on this side of the ball.`,
            `The board likes the direction. Don't give them a reason to start a new conversation.`,
            `Good week. Recruiting is easier when the product matches the brochure.`,
          ])
        : tone === "bad"
          ? pick(rng, [
              `${t.wins}-${t.losses} is not why we hired you. The fan base is loud. I need a stretch of basketball that looks like a plan.`,
              `I'm taking meetings I don't want to take. Change the temperature.`,
              `This is still your job. Act like you want to keep it.`,
            ])
          : pick(rng, [
              `${t.wins}-${t.losses}. We're still in it. Don't get cute with the schedule or the portal.`,
              `Even week. Even is fine. Drift is not.`,
              `Keep the room together. That's the whole note.`,
            ]),
    week,
    tone,
  });
}

function fanWeekly(state: GameState, pct: number, week: number, rng: Rng): Mail {
  const from = pick(rng, ["Season-ticket holder", "Student section", "Call-in show"]);
  const tone = pct >= 0.6 ? "good" : pct <= 0.38 ? "bad" : "even";
  return mail({
    id: `fanw-${week}`,
    from,
    subject: tone === "good" ? pick(rng, ["We're in", "Love this group", "Saturday can't come"]) : tone === "bad" ? pick(rng, ["Show up", "Same old", "Empty seats"]) : pick(rng, ["Still here", "Week " + week, "From the upper deck"]),
    body:
      tone === "good"
        ? pick(rng, ["This team is fun again. Don't overcoach it.", "The student line wrapped around the bookstore. That's on you.", "Keep playing like you mean it and we'll keep filling it."])
        : tone === "bad"
          ? pick(rng, ["We're not asking for perfect. We're asking for a pulse.", "I can get this product on the radio for free. Give me a reason to pay.", "The walkouts started in the second half. That's a choice."])
          : pick(rng, ["We'll be there. Play like you know that.", "Not buzzing, not leaving. That's the fan base you have.", "Do something worth a text thread."]),
    week,
    tone,
  });
}

function boosterWeekly(state: GameState, pct: number, week: number, rng: Rng): Mail {
  const nil = state.nilCap > 0;
  const from = nil ? "NIL collective" : "Booster club";
  const tone = pct >= 0.6 ? "good" : pct <= 0.38 ? "bad" : "even";
  return mail({
    id: `bstrw-${week}`,
    from,
    subject: tone === "good" ? pick(rng, ["Funds are moving", "Easy yes", "We're aligned"]) : tone === "bad" ? pick(rng, ["Harder ask", "Waiting", "Product"]) : pick(rng, ["Check-in", "Still writing", "From the club"]),
    body:
      tone === "good"
        ? nil
          ? pick(rng, ["The collective had a good week because you did. Keep the roster happy.", "I can make calls when the product looks like a program."])
          : pick(rng, ["The tip-off club is in. Don't waste it.", "Wins make the annual drive easy. Thank you."])
        : tone === "bad"
          ? nil
            ? pick(rng, ["People don't write NIL checks for  .400 basketball. Change the number.", "We're not out. We're tired of selling hope."])
            : pick(rng, ["The booster board is restless. A win would help my next meeting.", "I've been patient. Patience has a season too."])
          : pick(rng, ["We'll keep doing our part. Do yours on the floor.", "No panic. No parade. Just basketball."]),
    week,
    tone,
  });
}
