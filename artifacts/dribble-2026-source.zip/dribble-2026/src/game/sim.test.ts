import assert from "node:assert/strict";
import { test } from "node:test";
import { lockSchedule, newDynasty, simGame, beginLiveGame, runLiveRest, closeLive, recapFor } from "./engine.ts";
import { simContest } from "./sim.ts";
import { mulberry32 } from "./rng.ts";

function fgPct(rows: { fgm: number; fga: number }[]) {
  const fga = rows.reduce((n, p) => n + p.fga, 0);
  const fgm = rows.reduce((n, p) => n + p.fgm, 0);
  return fga ? fgm / fga : 0;
}

test("simmed box scores add up and look like college basketball", () => {
  let s = lockSchedule(newDynasty("kentucky", 41, { careerMode: false }));
  const rng = mulberry32(41);
  const game = simContest(s, "kentucky", s.schedule[0]!.awayId === "kentucky" ? s.schedule[0]!.homeId : s.schedule[0]!.awayId, rng, { site: "home" });
  assert.equal(game.homeLines.reduce((n, p) => n + p.pts, 0), game.homeScore);
  assert.equal(game.awayLines.reduce((n, p) => n + p.pts, 0), game.awayScore);
  assert.notEqual(game.homeScore, game.awayScore);
  assert.ok(game.homeScore >= 48 && game.homeScore <= 110, `home ${game.homeScore}`);
  assert.ok(game.awayScore >= 48 && game.awayScore <= 110, `away ${game.awayScore}`);
  const minH = game.homeLines.reduce((n, p) => n + p.min, 0);
  assert.ok(Math.abs(minH - game.minutes * 5) <= 2, `minutes ${minH}`);
  const pct = fgPct(game.homeLines);
  assert.ok(pct >= 0.34 && pct <= 0.62, `fg% ${pct}`);
  for (const p of game.homeLines) {
    assert.ok(p.fgm <= p.fga);
    assert.ok((p.tpm ?? 0) <= (p.tpa ?? 0));
    assert.ok((p.ftm ?? 0) <= (p.fta ?? 0));
    const made2 = p.fgm - (p.tpm ?? 0);
    const ident = made2 * 2 + (p.tpm ?? 0) * 3 + (p.ftm ?? 0);
    assert.equal(ident, p.pts, `${p.name} pts ${p.pts} vs ${ident}`);
    assert.ok(p.min <= 39);
  }
  const star = game.homeLines[0]!;
  assert.ok(star.pts <= 42, `star ${star.pts}`);
  assert.ok(star.fga >= 4 || star.pts < 12);
});

test("shooters take more threes than bigs", () => {
  let s = lockSchedule(newDynasty("duke", 9, { careerMode: false }));
  const rng = mulberry32(9);
  const opp = s.schedule.find((g) => g.homeId === "duke" || g.awayId === "duke")!;
  const other = opp.homeId === "duke" ? opp.awayId : opp.homeId;
  const game = simContest(s, "duke", other, rng, { site: "home" });
  const wings = game.homeLines.filter((p) => p.pos === "SG" || p.pos === "PG");
  const bigs = game.homeLines.filter((p) => p.pos === "C" || p.pos === "PF");
  const wing3 = wings.reduce((n, p) => n + (p.tpa ?? 0), 0);
  const big3 = bigs.reduce((n, p) => n + (p.tpa ?? 0), 0);
  assert.ok(wing3 >= big3, `wings ${wing3} bigs ${big3}`);
});

test("played and simmed recaps keep a real box", () => {
  let s = lockSchedule(newDynasty("kansas", 3, { careerMode: false, identity: { first: "Box", last: "Check", age: 44, almaMaterId: "kansas" } }));
  s = { ...simGame(s), pendingPresser: null };
  const r = s.results.find((x) => x.homeId === "kansas" || x.awayId === "kansas")!;
  const recap = recapFor(s, r);
  assert.equal(recap.homeLeaders.reduce((n, p) => n + p.pts, 0), r.homeScore);
  assert.equal(recap.awayLeaders.reduce((n, p) => n + p.pts, 0), r.awayScore);
  const star = recap.homeLeaders[0]!;
  assert.ok(star.fga >= star.fgm);
  const pct = star.fga ? star.fgm / star.fga : 0;
  assert.ok(pct <= 0.85 || star.fga <= 4, `hot shooting ${star.fgm}-${star.fga}`);

  let live = beginLiveGame(s)!;
  live = runLiveRest(live);
  assert.ok(live.liveGame?.done);
  const hs = live.liveGame!.homeScore;
  const as = live.liveGame!.awayScore;
  s = closeLive(live);
  const last = s.results[s.results.length - 1]!;
  assert.equal(last.homeScore, hs);
  assert.equal(last.awayScore, as);
  const liveRecap = recapFor(s, last);
  assert.equal(liveRecap.homeLeaders.reduce((n, p) => n + p.pts, 0), last.homeScore);
});
