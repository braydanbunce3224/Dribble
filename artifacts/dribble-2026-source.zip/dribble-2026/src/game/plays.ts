import type { DefPlay, GameState, LiveEvent, LiveGame, OffPlay, Player } from "./types";
import { TEAM_BY_ID } from "./teams";
import { clamp, gaussian, hashString, mulberry32, pick, randInt, type Rng } from "./rng";
import { teamChemistry } from "./chemistry";
import { availableRoster } from "./college";
import { blankLine, credit, onCourtFive } from "./sim";

export interface CallOption {
  id: OffPlay | DefPlay;
  side: "off" | "def";
  label: string;
}

export function clockLabel(half: number, clock: number) {
  const total = Math.max(0, Math.floor(Number.isFinite(clock) ? clock : 0));
  const m = Math.floor(total / 60);
  const s = total % 60;
  const per = half >= 3 ? `OT${half - 2}` : `H${half}`;
  return `${per} ${m}:${s.toString().padStart(2, "0")}`;
}

function roster(state: GameState, teamId: string) {
  return availableRoster(state, teamId);
}

function pickPlayer(rng: Rng, r: Player[], prefer: Player["pos"][] | null) {
  const pool = prefer ? r.filter((p) => prefer.includes(p.pos)) : r;
  const use = pool.length ? pool : r;
  if (!use.length) {
    return {
      id: "walk",
      first: "Walk",
      last: "On",
      pos: "SG" as const,
      year: 1,
      ovr: 60,
      potential: 60,
      morale: 50,
      teamId: "",
      mpg: 10,
      skills: { shoot: 60, finish: 60, defense: 60, iq: 60 },
      seasonMinutes: 0,
      seasonGames: 0,
      careerMinutes: 0,
      careerGames: 0,
    };
  }
  const w = use.map((p) => {
    const usg = p.usage ?? p.mpg * 2.15;
    const skill = prefer?.includes("C") || prefer?.includes("PF")
      ? (p.skills?.finish ?? p.ovr)
      : prefer?.includes("SG") || prefer?.includes("SF")
        ? (p.skills?.shoot ?? p.ovr)
        : ((p.skills?.shoot ?? p.ovr) + (p.skills?.finish ?? p.ovr) + (p.skills?.iq ?? p.ovr)) / 3;
    return Math.max(1, p.mpg * 1.2 + usg * 0.85 + skill * 0.55);
  });
  let t = rng() * w.reduce((s, n) => s + n, 0);
  for (let i = 0; i < use.length; i++) {
    t -= w[i]!;
    if (t <= 0) return use[i]!;
  }
  return use[0]!;
}

function teamOvr(state: GameState, teamId: string) {
  const r = roster(state, teamId).slice(0, 8);
  if (!r.length) return 70;
  return r.reduce((s, p) => s + p.ovr, 0) / r.length;
}

function nm(p: Player) {
  return `${p.first} ${p.last}`;
}

const OFF_META: Record<OffPlay, { label: string; prefer: Player["pos"][] | null }> = {
  motion: { label: "Motion", prefer: null },
  pnr: { label: "Pick & roll", prefer: ["PG", "SG"] },
  post: { label: "Post up", prefer: ["PF", "C"] },
  iso: { label: "Clear-out", prefer: ["PG", "SG", "SF"] },
  spread: { label: "Hunt a three", prefer: ["SG", "SF"] },
  push: { label: "Push tempo", prefer: ["PG", "SG"] },
  horns: { label: "Horns", prefer: ["PG", "PF"] },
  floppy: { label: "Floppy", prefer: ["SG", "SF"] },
  delay: { label: "Hold for last", prefer: ["PG", "SG"] },
  hammer: { label: "Hammer", prefer: ["SF", "SG"] },
};

const DEF_META: Record<DefPlay, { label: string }> = {
  man: { label: "Man" },
  zone: { label: "2-3 zone" },
  press: { label: "Full-court press" },
  pack: { label: "Pack-line" },
  trap: { label: "Sideline trap" },
  switch: { label: "Switch all" },
  foul: { label: "Foul him" },
  sag: { label: "Sag the paint" },
};

export const OFF_OPTS: { id: OffPlay; label: string }[] = (Object.keys(OFF_META) as OffPlay[]).map((id) => ({
  id,
  label: OFF_META[id].label,
}));
export const DEF_OPTS: { id: DefPlay; label: string }[] = (Object.keys(DEF_META) as DefPlay[]).map((id) => ({
  id,
  label: DEF_META[id].label,
}));

export function crowdFill(state: GameState, live: LiveGame) {
  const hp = state.teams[live.homeId]?.prestige ?? TEAM_BY_ID[live.homeId]?.prestige ?? 60;
  const ap = state.teams[live.awayId]?.prestige ?? TEAM_BY_ID[live.awayId]?.prestige ?? 60;
  const slot = state.schedule.find((g) => g.id === live.slotId);
  const neutral = slot?.site === "neutral" || slot?.kind === "ncaa" || slot?.kind === "nit" || slot?.kind === "crown" || slot?.kind === "mte" || slot?.kind === "conf-tourney";
  const home = clamp((hp - 32) / 62, 0.28, 0.98);
  const away = clamp((ap - 40) / 70, 0.12, 0.72);
  if (neutral) {
    const mix = clamp((home + away) / 2, 0.35, 0.9);
    return { home: mix, away: mix, packed: mix >= 0.78, split: true };
  }
  return { home, away: away * 0.42, packed: home >= 0.82, split: false };
}

function clash(off: OffPlay, def: DefPlay): { two: number; three: number; to: number; ft: number; note: string } {
  let two = 0, three = 0, to = 0, ft = 0;
  let note = "";

  if (off === "post" && def === "pack") { two -= 0.12; three += 0.05; note = "Pack-line fronted the post."; }
  else if (off === "post" && def === "man") { two += 0.11; note = "The block was theirs."; }
  else if (off === "post" && def === "zone") { two += 0.08; note = "Soft middle. The 5 went to work."; }
  else if (off === "post" && def === "trap") { to += 0.1; three += 0.06; note = "They trapped the catch. Kick or die."; }
  else if (off === "spread" && def === "zone") { three += 0.14; two -= 0.06; note = "Zone left the corner."; }
  else if (off === "spread" && def === "press") { to += 0.12; note = "Press jumped the skip."; }
  else if (off === "spread" && def === "pack") { three -= 0.06; note = "Pack-line ran the shooter off the line."; }
  else if (off === "push" && def === "press") { two += 0.1; to += 0.1; note = "Press vs the push — live by the break."; }
  else if (off === "push" && def === "sag") { two += 0.08; note = "They sagged. The rim was there early."; }
  else if (off === "iso" && def === "trap") { to += 0.14; note = "Double came on the clear-out."; }
  else if (off === "iso" && def === "switch") { two += 0.07; note = "Switch left a mismatch on an island."; }
  else if (off === "iso" && def === "pack") { two -= 0.07; note = "Help sat in the paint. Iso had nowhere."; }
  else if (off === "pnr" && def === "trap") { to += 0.11; three += 0.07; note = "Trap on the screen. Pocket or turnover."; }
  else if (off === "pnr" && def === "switch") { two += 0.09; note = "Switch. The roll was open."; }
  else if (off === "pnr" && def === "sag") { three += 0.06; note = "They sat back. The pull-up was there."; }
  else if (off === "motion" && def === "man") { two += 0.05; to -= 0.04; note = "Motion vs man — the cut was on time."; }
  else if (off === "motion" && def === "zone") { three += 0.05; note = "Extra pass vs the zone."; }
  else if (off === "horns" && def === "man") { two += 0.08; note = "Horns got a dive at the nail."; }
  else if (off === "horns" && def === "zone") { two += 0.06; three += 0.04; note = "High post vs zone."; }
  else if (off === "floppy" && def === "zone") { three += 0.12; note = "Floppy into a gap in the zone."; }
  else if (off === "floppy" && def === "switch") { three -= 0.05; two += 0.04; note = "They switched the screen. Floppy died."; }
  else if (off === "hammer" && def === "zone") { three += 0.1; note = "Corner was empty. Hammer."; }
  else if (off === "hammer" && def === "man") { two += 0.08; note = "Backdoor cut vs overplay."; }
  else if (off === "delay" && def === "press") { to -= 0.06; note = "They pressed a hold. You burned clock."; }
  else if (off === "delay" && def === "foul") { ft += 0.5; note = "They sent you to the line on purpose."; }
  else if (def === "foul") { ft += 0.8; two -= 0.2; three -= 0.2; note = "Intentional foul. Live at the stripe."; }
  else if (def === "press") { to += 0.07; note = "Pressure on the ball."; }
  else if (def === "trap") { to += 0.08; note = "Trap came."; }
  else note = "The call was on.";

  return { two, three, to, ft, note };
}

function mix(off: OffPlay, def: DefPlay) {
  const m = { two: 0.4, three: 0.28, ft: 0.14, to: 0.18 };
  if (off === "post") { m.two += 0.2; m.three -= 0.14; m.ft += 0.06; }
  if (off === "spread" || off === "floppy") { m.three += 0.22; m.two -= 0.14; }
  if (off === "iso") { m.two += 0.08; m.to += 0.05; }
  if (off === "pnr" || off === "horns") { m.two += 0.1; m.three += 0.04; }
  if (off === "push") { m.two += 0.08; m.three += 0.06; m.to += 0.05; }
  if (off === "hammer") { m.three += 0.1; m.two += 0.06; }
  if (off === "delay") { m.two += 0.08; m.to -= 0.06; m.three -= 0.04; }
  if (off === "motion") { m.to -= 0.04; }
  if (def === "press" || def === "trap") { m.to += 0.1; }
  if (def === "zone") { m.three += 0.1; m.two -= 0.08; }
  if (def === "pack") { m.two -= 0.08; m.three += 0.05; }
  if (def === "foul") { m.ft = 0.85; m.two = 0.05; m.three = 0.05; m.to = 0.05; }
  const c = clash(off, def);
  m.to = Math.max(0.04, m.to + c.to);
  m.ft = Math.max(0.04, m.ft + c.ft * 0.15);
  const sum = m.two + m.three + m.ft + m.to;
  m.two /= sum; m.three /= sum; m.ft /= sum; m.to /= sum;
  return m;
}

function rollKind(rng: Rng, off: OffPlay, def: DefPlay): "two" | "three" | "ft" | "to" {
  const m = mix(off, def);
  const x = rng();
  if (x < m.two) return "two";
  if (x < m.two + m.three) return "three";
  if (x < m.two + m.three + m.ft) return "ft";
  return "to";
}

function describe(off: OffPlay, def: DefPlay, kind: "two" | "three" | "ft" | "to", made: boolean, a: Player, b: Player, defP: Player, and1: boolean): string {
  const A = nm(a);
  const B = nm(b);
  const D = nm(defP);
  const tag = OFF_META[off].label;
  if (def === "foul") {
    return `${tag}: they grab ${A} before the shot. Line.`;
  }
  if (off === "post") {
    if (kind === "two") return made
      ? (and1 ? `Post: ${A} seals ${D}, finishes, and-one.` : `Post: ${A} drop-steps ${D} and finishes.`)
      : `Post: ${A} backs ${D} down. Short.`;
    if (kind === "three") return made ? `Post: double comes. ${A} kicks ${B} — corner three.` : `Post: kick to ${B}, the three is off.`;
    if (kind === "ft") return `Post: ${A} is hacked on the block.`;
    return `${D} rips the entry to ${A}.`;
  }
  if (off === "pnr") {
    if (kind === "two") return made ? `Pick-and-roll: ${A} turns the corner, lays it in.` : `Pick-and-roll: ${A} rejects it, pull-up rims out.`;
    if (kind === "three") return made ? `Pick-and-roll: ${A} draws two, ${B} pops — three.` : `${B} pops, three from the slot is long.`;
    if (kind === "ft") return `${A} is fouled on the roll.`;
    return `The trap on the screen gets ${A}.`;
  }
  if (off === "spread" || off === "floppy") {
    if (kind === "three") return made ? `${tag}: ${A} skips to ${B} — clean look. Three.` : `${tag}: they hunt it. ${B} misses from the wing.`;
    if (kind === "two") return made ? `${tag}: closeout, ${A} rips middle.` : `${tag}: ${A} drives into help.`;
    if (kind === "ft") return `${A} draws the closeout foul.`;
    return `The skip is picked. ${D} takes it.`;
  }
  if (off === "iso") {
    if (kind === "two") return made ? `Clear-out: ${A} sits ${D} down and gets to the spot.` : `Clear-out: ${A} hunts it. The jumper is short.`;
    if (kind === "three") return made ? `${A} steps behind the arc. Good.` : `${A} settles. No.`;
    if (kind === "ft") return `${A} gets into the body. Line.`;
    return `Doubled in the clear-out. Stolen.`;
  }
  if (off === "push") {
    if (kind === "two") return made ? `Push: ${A} leaks, ${B} hits him in stride.` : `Push: ${A} is off the glass in transition.`;
    if (kind === "three") return made ? `Early clock. ${B} from the slot. Three.` : `Rushed three from ${B}.`;
    if (kind === "ft") return `Transition foul on ${A}.`;
    return `They run into the pressure. Turnover.`;
  }
  if (off === "horns") {
    if (kind === "two") return made ? `Horns: ${A} dives, pocket pass, finish.` : `Horns: the dive is late. ${A} misses.`;
    if (kind === "three") return made ? `Horns: ${B} lifts off the elbow. Three.` : `Horns: elbow three from ${B} is short.`;
    if (kind === "ft") return `Horns: ${A} is cut off at the nail. FTs.`;
    return `Horns entry is jumped.`;
  }
  if (off === "hammer") {
    if (kind === "three") return made ? `Hammer: ${B} in the corner, unnoticed. Three.` : `Hammer: the corner three from ${B} rims out.`;
    if (kind === "two") return made ? `Hammer: ${A} back-cuts ${D} and finishes.` : `Hammer: the backdoor to ${A} is off.`;
    if (kind === "ft") return `Hammer cut, ${A} is chopped.`;
    return `They read the hammer. Stolen.`;
  }
  if (off === "delay") {
    if (kind === "two") return made ? `Hold: clock down, ${A} gets to the rim.` : `Hold: ${A} waits, the jumper is late.`;
    if (kind === "three") return made ? `Hold: ${B} for one. Three.` : `Hold: last-shot three from ${B} is short.`;
    if (kind === "ft") return `They foul ${A} as the clock dies.`;
    return `The hold turns into a trap. Turnover.`;
  }
  if (kind === "two") return made ? `Motion: ${A} cuts, ${B} hits him.` : `Motion: ${A} off the stagger, short.`;
  if (kind === "three") return made ? `Motion: ${B} lifts — three.` : `Motion: extra pass to ${B}, rims out.`;
  if (kind === "ft") return `Motion cut. ${A} at the line.`;
  return `Motion: skip is late. ${D} takes it.`;
}

function hoopFt(poss: "home" | "away") {
  return poss === "home" ? { x: 88.75, y: 25 } : { x: 5.25, y: 25 };
}

/** Place the play on the floor from the outcome — not a random decoration. */
export function playSpot(
  kind: "two" | "three" | "ft" | "to",
  off: OffPlay,
  poss: "home" | "away",
  rng: Rng,
): { x: number; y: number } {
  const h = hoopFt(poss);
  const dir = poss === "home" ? -1 : 1;
  let x = h.x;
  let y = h.y;
  if (kind === "ft") {
    x = h.x + dir * 13.75;
    y = 25 + (rng() - 0.5) * 0.6;
  } else if (kind === "to") {
    if (off === "push") {
      x = 47 + dir * (8 + rng() * 18);
      y = 10 + rng() * 30;
    } else {
      x = h.x + dir * (18 + rng() * 16);
      y = 8 + rng() * 34;
    }
  } else if (kind === "three") {
    const corner = rng() < 0.34;
    if (corner) {
      x = h.x + dir * 2.2;
      y = rng() < 0.5 ? 3.2 : 46.8;
    } else if (rng() < 0.35) {
      x = h.x + dir * 22.4;
      y = 25 + (rng() - 0.5) * 6;
    } else {
      const ang = (rng() < 0.5 ? 1 : -1) * (0.45 + rng() * 0.55);
      x = h.x + dir * Math.cos(ang) * 22.6;
      y = h.y + Math.sin(ang) * 22.6;
    }
  } else {
    const d =
      off === "post" ? 2 + rng() * 4 :
      off === "pnr" || off === "horns" ? 4 + rng() * 8 :
      3 + rng() * 12;
    const ang = (rng() - 0.5) * 1.6;
    x = h.x + dir * Math.cos(ang) * d;
    y = h.y + Math.sin(ang) * d;
  }
  return { x: clamp(x, 1.5, 92.5), y: clamp(y, 1.5, 48.5) };
}

export function distToHoop(x: number, y: number, poss: "home" | "away") {
  const h = hoopFt(poss);
  return Math.hypot(x - h.x, y - h.y);
}

function impactLine(off: OffPlay, def: DefPlay, kind: string, made: boolean, pts: number, note: string, youOff: boolean): string {
  const call = youOff ? OFF_META[off].label : DEF_META[def].label;
  if (pts > 0) return `${call} worked. ${note} ${pts}.`;
  if (kind === "to") return `${call} got picked. ${note}`;
  if (kind === "ft") return `${call}: the line. ${note}`;
  return made ? `${call}. ${note}` : `${call} didn't get a look. ${note}`;
}

function possSeconds(rng: Rng, off: OffPlay, def: DefPlay, clock: number) {
  if (def === "foul") return Math.min(clock, randInt(rng, 2, 6));
  if (off === "delay") return Math.min(clock, Math.max(6, clock - randInt(rng, 0, 3)));
  let sec = off === "push" ? randInt(rng, 7, 15) : off === "iso" ? randInt(rng, 15, 24) : randInt(rng, 13, 20);
  if (def === "press" || def === "trap") sec = Math.max(8, sec - 4);
  return Math.min(clock, sec);
}

function believeLine(live: LiveGame, rng: Rng, kind: string, made: boolean): string | null {
  if (live.homeId === "utah-state") {
    if (made && kind === "three") return "I Believe that we will win — the Spectrum is on its feet.";
    if (made && kind === "two" && rng() < 0.18) return "I Believe that we will win — the Spectrum is on its feet.";
    if (rng() < 0.12) return "I Believe that we will win — the Spectrum is on its feet.";
    return null;
  }
  if (live.awayId === "utah-state" && rng() < 0.1) {
    return "The Aggie bench is chirping I Believe on the road.";
  }
  return null;
}

export function startLiveGame(state: GameState): GameState | null {
  if (state.liveGame && !state.liveGame.done) return state;
  const open = state.schedule
    .filter((x) => !x.resultId && !x.declined && (x.homeId === state.playerTeamId || x.awayId === state.playerTeamId))
    .sort((a, b) => a.week - b.week);
  const g = open[0];
  if (!g) return null;
  const home = TEAM_BY_ID[g.homeId];
  const away = TEAM_BY_ID[g.awayId];
  if (!home || !away) return null;
  const plan = state.gamePlan;
  const live: LiveGame = {
    slotId: g.id,
    homeId: g.homeId,
    awayId: g.awayId,
    homeScore: 0,
    awayScore: 0,
    half: 1,
    clock: 1200,
    poss: "home",
    offCall: plan?.off[0] ?? "motion",
    defCall: plan?.def[0] ?? "man",
    log: [{ t: "H1 20:00", text: `${away.name} at ${home.name}. Tip to the home side.`, homeScore: 0, awayScore: 0 }],
    done: false,
    planned: false,
    planOff: plan?.off ? [...plan.off] : ["motion", "pnr", "spread"],
    planDef: plan?.def ? [...plan.def] : ["man", "pack"],
    htAdj: false,
    homeLines: availableRoster(state, g.homeId).slice(0, 13).map(blankLine),
    awayLines: availableRoster(state, g.awayId).slice(0, 13).map(blankLine),
  };
  return { ...state, liveGame: live };
}

export function setPlanSlot(state: GameState, side: "off" | "def", index: number, id: OffPlay | DefPlay): GameState {
  const live = state.liveGame;
  const plan = state.gamePlan ?? { off: ["motion", "pnr", "spread"] as [OffPlay, OffPlay, OffPlay], def: ["man", "pack"] as [DefPlay, DefPlay] };
  if (side === "off") {
    const off = [...plan.off] as [OffPlay, OffPlay, OffPlay];
    off[clamp(index, 0, 2)] = id as OffPlay;
    const next = { ...state, gamePlan: { ...plan, off } };
    if (!live || live.done || live.planned) return next;
    return { ...next, liveGame: { ...live, planOff: [...off], offCall: off[0] } };
  }
  const def = [...plan.def] as [DefPlay, DefPlay];
  def[clamp(index, 0, 1)] = id as DefPlay;
  const next = { ...state, gamePlan: { ...plan, def } };
  if (!live || live.done || live.planned) return next;
  return { ...next, liveGame: { ...live, planDef: [...def], defCall: def[0] } };
}

export function lockGamePlan(state: GameState): GameState {
  const live = state.liveGame;
  if (!live || live.done) return state;
  const off = live.planOff?.length ? live.planOff : state.gamePlan?.off ?? ["motion"];
  const def = live.planDef?.length ? live.planDef : state.gamePlan?.def ?? ["man"];
  return {
    ...state,
    liveGame: {
      ...live,
      planned: true,
      offCall: off[0] as OffPlay,
      defCall: def[0] as DefPlay,
      log: [{ t: "H1 20:00", text: `Gameplan set. ${OFF_META[off[0] as OffPlay].label} to start. Tip.`, homeScore: 0, awayScore: 0 }],
    },
  };
}

export function setLiveCall(state: GameState, kind: "off" | "def", id: OffPlay | DefPlay): GameState {
  const live = state.liveGame;
  if (!live || live.done) return state;
  if (kind === "off") return { ...state, liveGame: { ...live, offCall: id as OffPlay, lastYouOff: id as OffPlay, htAdj: live.half >= 2 ? true : live.htAdj } };
  return { ...state, liveGame: { ...live, defCall: id as DefPlay, lastYouDef: id as DefPlay, htAdj: live.half >= 2 ? true : live.htAdj } };
}

export function liveYouOffense(state: GameState) {
  const live = state.liveGame;
  if (!live) return true;
  return (live.poss === "home" ? live.homeId : live.awayId) === state.playerTeamId;
}

/** Full-court press needs a dead-ball inbound. A missed shot is a live rebound. */
export function pressLegal(state: GameState): boolean {
  const live = state.liveGame;
  if (!live) return false;
  const last = live.log.find((e) => e.kind && e.kind !== "period");
  if (!last) return true;
  const lastOff = last.poss === "home" ? live.homeId : live.awayId;
  if (lastOff !== state.playerTeamId) return true;
  if (last.kind === "to") return true;
  return Boolean(last.made);
}

export function offeredCalls(state: GameState): CallOption[] {
  const live = state.liveGame;
  if (!live || live.done) return [];
  const youOff = liveYouOffense(state);
  const rng = mulberry32(state.seed ^ live.clock ^ live.log.length ^ live.half * 17);
  const youScore = live.homeId === state.playerTeamId ? live.homeScore : live.awayScore;
  const themScore = live.homeId === state.playerTeamId ? live.awayScore : live.homeScore;
  const trail = themScore - youScore;
  const late = live.half >= 2 && live.clock <= 90;
  const r = roster(state, state.playerTeamId);
  const big = r.find((p) => p.pos === "C" || p.pos === "PF");
  const wing = r.find((p) => p.pos === "SG" || p.pos === "SF");

  const offPool: OffPlay[] = [];
  const defPool: DefPlay[] = [];

  if (youOff) {
    offPool.push("motion", "pnr");
    if (big && (big.skills?.finish ?? big.ovr) >= 58) offPool.push("post", "horns");
    if (wing && (wing.skills?.shoot ?? wing.ovr) >= 58) offPool.push("spread", "floppy", "hammer");
    offPool.push("iso", "push");
    if (late) offPool.push("delay");
    if (trail >= 4) offPool.push("spread", "push", "hammer");
    if (trail <= -6 && live.clock < 40) offPool.push("delay");
  } else {
    defPool.push("man", "zone", "pack");
    const inbound = pressLegal(state);
    if (inbound && (trail > 0 || live.lastYouOff === "push")) defPool.push("press", "trap");
    else if (inbound) defPool.push("press");
    else if (trail > 0 || live.lastYouOff === "push") defPool.push("trap");
    if (live.lastYouOff === "post") defPool.push("pack", "sag");
    if (live.lastYouOff === "spread" || live.lastYouOff === "floppy") defPool.push("pack", "switch");
    if (late && trail >= 1 && trail <= 3) defPool.push("foul");
    if (trail <= -8) defPool.push("sag", "pack");
    defPool.push("switch");
  }

  const seen = new Set<string>();
  const pool = (youOff ? offPool : defPool).filter((id) => {
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  const shuffled = [...pool].sort(() => rng() - 0.5);
  const planBoost = youOff ? live.planOff ?? [] : live.planDef ?? [];
  const preferred = planBoost.filter((id) => pool.includes(id as never));
  const rest = shuffled.filter((id) => !preferred.includes(id as never));
  const take = [...preferred, ...rest];
  const n = live.half === 2 && !live.htAdj ? 6 : 4;
  while (take.length < n) {
    const extra = youOff
      ? pick(rng, ["motion", "pnr", "iso", "push"] as OffPlay[])
      : pick(rng, (pressLegal(state) ? ["man", "zone", "pack", "press"] : ["man", "zone", "pack", "switch"]) as DefPlay[]);
    if (!take.includes(extra as never)) take.push(extra as never);
    else break;
  }
  return take.slice(0, n).map((id) =>
    youOff
      ? { id, side: "off" as const, label: OFF_META[id as OffPlay].label }
      : { id, side: "def" as const, label: DEF_META[id as DefPlay].label },
  );
}

export function stepLive(state: GameState, n = 1): GameState {
  let s = state;
  for (let i = 0; i < n; i++) {
    if (!s.liveGame || s.liveGame.done) break;
    s = onePoss(s);
  }
  return s;
}

function padLive(live: LiveGame): LiveGame {
  const lo = 52;
  const hi = 105;
  let hs = live.homeScore;
  let as = live.awayScore;
  const homeWon = hs > as;
  const tied = hs === as;
  const homeLines = (live.homeLines ?? []).map((p) => ({ ...p }));
  const awayLines = (live.awayLines ?? []).map((p) => ({ ...p }));
  const bump = (lines: typeof homeLines, n: number) => {
    if (!lines.length || n === 0) return;
    let left = n;
    let guard = 0;
    while (left !== 0 && guard++ < 240) {
      const p = lines[(guard - 1) % lines.length]!;
      if (left > 0) {
        p.ftm = (p.ftm ?? 0) + 1;
        p.fta = (p.fta ?? 0) + 1;
        p.pts += 1;
        left -= 1;
      } else {
        const ftm = p.ftm ?? 0;
        if (ftm > 0) {
          p.ftm = ftm - 1;
          p.fta = Math.max((p.fta ?? 1) - 1, p.ftm ?? 0);
          p.pts = Math.max(0, p.pts - 1);
          left += 1;
        } else if ((p.tpm ?? 0) > 0 && left <= -3) {
          p.tpm = (p.tpm ?? 0) - 1;
          p.fgm = Math.max(0, p.fgm - 1);
          p.tpa = Math.max(p.tpm, (p.tpa ?? 1) - 1);
          p.fga = Math.max(p.fgm, p.fga - 1);
          p.pts = Math.max(0, p.pts - 3);
          left += 3;
        } else if (p.fgm > (p.tpm ?? 0) && left <= -2) {
          p.fgm -= 1;
          p.fga = Math.max(p.fgm, p.fga - 1);
          p.pts = Math.max(0, p.pts - 2);
          left += 2;
        } else if (guard >= lines.length && left < 0) {
          break;
        }
      }
    }
  };
  const apply = (dh: number, da: number) => {
    if (dh) bump(homeLines, dh);
    if (da) bump(awayLines, da);
    hs += dh;
    as += da;
  };
  if (hs < lo || as < lo) {
    const lift = lo - Math.min(hs, as);
    apply(lift, lift);
  }
  if (hs > hi || as > hi) {
    const drop = Math.max(hs, as) - hi;
    apply(-drop, -drop);
  }
  if (hs < lo) apply(lo - hs, 0);
  if (as < lo) apply(0, lo - as);
  if (hs > hi) apply(hi - hs, 0);
  if (as > hi) apply(0, hi - as);
  if (!tied) {
    if (homeWon && hs <= as) apply(as - hs + 1, 0);
    if (!homeWon && as <= hs) apply(0, hs - as + 1);
  } else if (hs === as) {
    apply(1, 0);
  }
  const cap = 32;
  if (hs - as > cap) apply(-(hs - as - cap), 0);
  if (as - hs > cap) apply(0, -(as - hs - cap));
  return { ...live, homeScore: hs, awayScore: as, homeLines, awayLines };
}

export function simRestLive(state: GameState): GameState {
  let s = state;
  let guard = 0;
  while (s.liveGame && !s.liveGame.done && guard++ < 320) s = onePoss(s);
  if (s.liveGame && !s.liveGame.done) {
    const live = padLive({ ...s.liveGame, clock: 0, done: true });
    s = {
      ...s,
      liveGame: {
        ...live,
        log: [
          {
            t: "Final",
            text: `Final: ${TEAM_BY_ID[live.homeId]?.name} ${live.homeScore}, ${TEAM_BY_ID[live.awayId]?.name} ${live.awayScore}.`,
            homeScore: live.homeScore,
            awayScore: live.awayScore,
            kind: "period" as const,
          },
          ...live.log,
        ].slice(0, 48),
      },
    };
  } else if (s.liveGame?.done) {
    s = { ...s, liveGame: padLive(s.liveGame) };
  }
  return s;
}

function onePoss(state: GameState): GameState {
  const live = state.liveGame;
  if (!live || live.done) return state;
  const rng = mulberry32(
    state.seed ^ hashString(live.slotId) ^ (live.homeScore * 13 + live.awayScore * 17 + live.clock + live.half * 1009 + live.log.length),
  );
  const offId = live.poss === "home" ? live.homeId : live.awayId;
  const defId = live.poss === "home" ? live.awayId : live.homeId;
  const youOff = offId === state.playerTeamId;
  const offPlay = youOff ? live.offCall : cpuOff(rng, live.defCall, live.lastYouDef);
  const defPlay = youOff ? cpuDef(rng, live.offCall, live.lastYouOff) : live.defCall;
  const offR = roster(state, offId);
  const defR = roster(state, defId);
  const a = pickPlayer(rng, offR, OFF_META[offPlay].prefer);
  const b = pickPlayer(rng, offR, offPlay === "spread" || offPlay === "floppy" || offPlay === "hammer" ? (["SG", "SF"] as Player["pos"][]) : null);
  const d = pickPlayer(rng, defR, null);
  const c = clash(offPlay, defPlay);
  const coach = state.coachSkills;
  const coachOff = youOff ? ((coach?.offense ?? 48) - 50) / 180 : 0;
  const coachDef = !youOff ? ((coach?.defense ?? 48) - 50) / 180 : 0;
  const offScore = offId === live.homeId ? live.homeScore : live.awayScore;
  const defScore = offId === live.homeId ? live.awayScore : live.homeScore;
  const lead = offScore - defScore;
  let catchUp = 0;
  if (lead < -6) catchUp = Math.min(0.36, (-6 - lead) * 0.02);
  else if (lead > 8) catchUp = -Math.min(0.2, (lead - 8) * 0.01);
  const edge = (teamOvr(state, offId) - teamOvr(state, defId)) / 32 + (offId === live.homeId ? 0.08 : 0) + coachOff - coachDef;
  const chem = teamChemistry(state, offId).score;
  const chemDef = teamChemistry(state, defId).score;
  const chemSwing = (chem - chemDef) / 280;
  const extraPass = chem >= 72 && (a.skills?.iq ?? 0) + (b.skills?.iq ?? 0) >= 140;
  const shoot = (a.skills?.shoot ?? a.ovr) / 100;
  const finish = (a.skills?.finish ?? a.ovr) / 100;
  const iq = (a.skills?.iq ?? a.ovr) / 100;
  const dfn = (d.skills?.defense ?? d.ovr) / 100;
  let kind = rollKind(rng, offPlay, defPlay);
  if (shoot > finish + 0.08 && kind === "two" && rng() < 0.35) kind = "three";
  if (finish > shoot + 0.1 && kind === "three" && rng() < 0.4) kind = "two";
  if ((a.pos === "C" || a.pos === "PF") && kind === "three" && rng() < 0.55) kind = "two";
  if ((a.pos === "SG") && kind === "two" && shoot > 0.72 && rng() < 0.28) kind = "three";
  if (state.eraDecade != null && state.eraDecade < 1980 && kind === "three") kind = rng() < 0.75 ? "two" : "ft";
  if (kind !== "to" && rng() < clamp(0.12 - iq * 0.08 + dfn * 0.05 + c.to * 0.18 - chemSwing * 0.4 - Math.max(0, -lead) * 0.002, 0.08, 0.2)) kind = "to";
  const teamMake = 0.46 + edge * 0.12;
  const make2 = clamp(0.5 * (0.42 + finish * 0.26 - dfn * 0.14) + 0.5 * teamMake + c.two * 0.35 + chemSwing + catchUp + (extraPass ? 0.02 : 0) + gaussian(rng) * 0.01, 0.34, 0.62);
  const make3 = clamp(0.5 * (0.26 + shoot * 0.22 - dfn * 0.08) + 0.5 * (0.33 + edge * 0.08) + c.three * 0.32 + chemSwing * 0.5 + catchUp * 0.85 + (extraPass ? 0.02 : 0) + gaussian(rng) * 0.01, 0.2, 0.44);
  let pts = 0;
  let made = false;
  let and1 = false;
  let ftm = 0;
  let fta = 0;
  if (kind === "two") {
    made = rng() < make2;
    pts = made ? 2 : 0;
    if (made && rng() < 0.08 + finish * 0.1) {
      and1 = true;
      fta = 1;
      if (rng() < clamp(0.66 + shoot * 0.2, 0.52, 0.9)) {
        ftm = 1;
        pts = 3;
      }
    }
  } else if (kind === "three") {
    made = rng() < make3;
    pts = made ? 3 : 0;
  } else if (kind === "ft") {
    const ft = clamp(0.66 + shoot * 0.22 + edge * 0.03, 0.5, 0.9);
    const attempts = 2;
    fta = attempts;
    for (let i = 0; i < attempts; i++) if (rng() < ft) ftm++;
    pts = ftm;
    made = pts > 0;
  }
  if (offScore >= 100 && pts > 0) {
    pts = 0;
    made = false;
    and1 = false;
    ftm = 0;
  }
  if (lead > 26 && pts > 0 && rng() < 0.45) {
    pts = 0;
    made = false;
    and1 = false;
    ftm = 0;
  }
  let text = describe(offPlay, defPlay, kind, made, a, b, d, and1);
  if (extraPass && made && kind !== "to" && rng() < 0.45) text = `${text} Extra pass.`;
  if (chem <= 42 && kind === "to" && rng() < 0.4) text = `${text} Nobody wanted it.`;
  if (kind === "ft") text = `${text} ${pts} of 2.`;
  const believe = believeLine(live, rng, kind, made);
  if (believe) {
    const lock = made && kind === "three" && live.homeId === "utah-state";
    if (lock || rng() < 0.5) text = `${text} ${believe}`;
  }
  const crowd = crowdFill(state, live);
  if (made && kind === "three" && live.poss === "home" && !crowd.split && rng() < crowd.home * 0.4) {
    text = crowd.packed ? `${text} The building goes up.` : `${text} The home side found its voice.`;
  } else if (made && kind === "three" && crowd.split && rng() < 0.25) {
    text = `${text} Split crowd. Both sides stood.`;
  }
  const impact = impactLine(offPlay, defPlay, kind, made, pts, c.note, youOff);

  const used = possSeconds(rng, offPlay, defPlay, live.clock);
  let clock = live.clock - used;
  let half = live.half;
  const homeScore = live.homeScore + (live.poss === "home" ? pts : 0);
  const awayScore = live.awayScore + (live.poss === "away" ? pts : 0);
  const spot = playSpot(kind, offPlay, live.poss, rng);
  let poss: "home" | "away" = live.poss === "home" ? "away" : "home";
  const ast = extraPass && made && kind !== "to" && kind !== "ft" && b.id !== a.id ? b : null;
  const events: LiveEvent[] = [{
    t: clockLabel(half, Math.max(0, clock)),
    text,
    homeScore,
    awayScore,
    impact,
    pts,
    kind,
    made,
    poss: live.poss,
    x: spot.x,
    y: spot.y,
    playerId: a.id,
    astId: ast?.id,
  }, ...live.log].slice(0, 48);

  const homeLines = (live.homeLines ?? availableRoster(state, live.homeId).slice(0, 13).map(blankLine)).map((row) => ({ ...row }));
  const awayLines = (live.awayLines ?? availableRoster(state, live.awayId).slice(0, 13).map(blankLine)).map((row) => ({ ...row }));
  const offLines = live.poss === "home" ? homeLines : awayLines;
  const defLines = live.poss === "home" ? awayLines : homeLines;
  if (a.id && a.id !== "walk" && !offLines.some((x) => x.id === a.id)) offLines.push(blankLine(a));
  if (b.id && b.id !== "walk" && !offLines.some((x) => x.id === b.id)) offLines.push(blankLine(b));
  const shooter = offLines.find((x) => x.id === a.id);
  const passer = ast ? offLines.find((x) => x.id === ast.id) : undefined;
  const dt = used / 60;
  const offFive = onCourtFive(rng, offR, offR.map((p) => Math.max(8, p.mpg)), offR.map((p) => offLines.find((x) => x.id === p.id)?.min ?? 0));
  const defFive = onCourtFive(rng, defR, defR.map((p) => Math.max(8, p.mpg)), defR.map((p) => defLines.find((x) => x.id === p.id)?.min ?? 0));
  for (const p of offFive) credit(offLines.find((x) => x.id === p.id), { min: dt });
  for (const p of defFive) credit(defLines.find((x) => x.id === p.id), { min: dt });
  if (kind === "to") credit(shooter, { to: 1 });
  else if (kind === "ft") credit(shooter, { fta, ftm, pts, min: dt });
  else if (kind === "three") {
    credit(shooter, { fga: 1, tpa: 1, fgm: made ? 1 : 0, tpm: made ? 1 : 0, pts, fta, ftm });
    if (made) credit(passer, { ast: 1 });
    else credit(defLines.find((x) => x.id === d.id) ?? defLines[0], { reb: 1 });
  } else if (kind === "two") {
    credit(shooter, { fga: 1, fgm: made ? 1 : 0, pts, fta, ftm });
    if (made) credit(passer, { ast: 1 });
    else credit(defLines.find((x) => x.id === d.id) ?? defLines[0], { reb: 1 });
  }

  if (clock <= 0) {
    if (half === 1) {
      half = 2;
      clock = 1200;
      poss = "away";
      events.unshift({
        t: "H2 20:00",
        text: `Halftime ${TEAM_BY_ID[live.homeId]?.abbr} ${homeScore}, ${TEAM_BY_ID[live.awayId]?.abbr} ${awayScore}. Mix the plan.`,
        homeScore,
        awayScore,
        kind: "period",
      });
    } else if (half === 2 && homeScore === awayScore) {
      half = 3;
      clock = 300;
      poss = "home";
      events.unshift({ t: "OT 5:00", text: "Tied. Five more minutes.", homeScore, awayScore, kind: "period" });
    } else if (half >= 3 && homeScore === awayScore && half < 5) {
      half = (half + 1) as LiveGame["half"];
      clock = 300;
      poss = "home";
      events.unshift({ t: "OT 5:00", text: "Still tied. Another extra session.", homeScore, awayScore, kind: "period" });
    } else {
      const finished = padLive({ ...live, homeScore, awayScore, clock: 0, poss, half, homeLines, awayLines, done: true, log: events });
      finished.log = [
        {
          t: "Final",
          text: `Final: ${TEAM_BY_ID[finished.homeId]?.name} ${finished.homeScore}, ${TEAM_BY_ID[finished.awayId]?.name} ${finished.awayScore}.`,
          homeScore: finished.homeScore,
          awayScore: finished.awayScore,
          kind: "period" as const,
        },
        ...finished.log.filter((e) => e.t !== "Final"),
      ].slice(0, 48);
      return { ...state, liveGame: finished };
    }
  }

  return {
    ...state,
    liveGame: { ...live, homeScore, awayScore, clock: Math.max(0, clock), half, poss, log: events, done: false, htAdj: half !== live.half ? false : live.htAdj, homeLines, awayLines },
  };
}

function cpuOff(rng: Rng, userDef: DefPlay, lastDef?: DefPlay): OffPlay {
  const d = lastDef ?? userDef;
  if (d === "zone") return rng() < 0.55 ? "spread" : "floppy";
  if (d === "press") return rng() < 0.5 ? "push" : "motion";
  if (d === "pack") return rng() < 0.5 ? "spread" : "hammer";
  if (d === "trap") return rng() < 0.5 ? "motion" : "horns";
  if (d === "foul") return "delay";
  return pick(rng, ["motion", "pnr", "post", "iso", "spread", "push", "horns"]);
}

function cpuDef(rng: Rng, userOff: OffPlay, lastOff?: OffPlay): DefPlay {
  const o = lastOff ?? userOff;
  if (o === "post") return rng() < 0.6 ? "pack" : "sag";
  if (o === "spread" || o === "floppy") return rng() < 0.55 ? "pack" : "switch";
  if (o === "push") return rng() < 0.45 ? "press" : "man";
  if (o === "iso") return rng() < 0.4 ? "trap" : "pack";
  if (o === "delay") return rng() < 0.35 ? "foul" : "man";
  return pick(rng, ["man", "man", "zone", "press", "pack", "switch"]);
}
