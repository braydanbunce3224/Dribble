/** User-facing product copy. Internal ids (ncaa, nit, kenpom) stay for saves. */
export const APP_NAME = "Dribble 2026";
export const APP_SHORT = "Dribble";
export const NATIONAL = "National";
export const NATIONAL_TOURNEY = "National Tournament";
export const INVITE = "The Invite";
export const CROWN = "The Crown";
export const EVAL_BOARD = "Eval";
export const EFFICIENCY_BOARD = "Efficiency";
export const WRITERS_POLL = "Writers";
export const DESK = "The Desk";
export const SUNDAY_BOARD = "Sunday Board";
export const BOARD_100 = "Board 100";
export const PLAY_IN = "Play-in";
export const SELECTION_DAY = "Selection Day";
