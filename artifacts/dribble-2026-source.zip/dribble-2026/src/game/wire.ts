import type { GameResult, GameSlot, GameState, NewsArticle } from "./types";
import { TEAM_BY_ID } from "./teams";
import { identityName } from "./engine-util";
import { hashString, mulberry32, pick, type Rng } from "./rng";
import { recapFor } from "./recap";

const WRITERS = ["Maya Chen", "Rob Vickers", "Ellis Prado", "Janelle Ortiz", "Chris Bohm", "Priya Nair", "Sam Calder", "Nina Vos"];
const OUTLETS = ["The Desk", "Campus Wire", "Nightly Board", "The Tip", "League Notes"];

type Tone = NewsArticle["tone"];

function school(id: string) {
  return TEAM_BY_ID[id];
}

function rngFor(state: GameState, key: string) {
  return mulberry32(state.seed ^ hashString(key) ^ (state.week * 104729));
}

export function asArticle(raw: Partial<NewsArticle> & { week: number; text?: string; tone?: Tone }): NewsArticle {
  const text = raw.text || raw.headline || "The wire is quiet.";
  const headline = raw.headline || text.replace(/\.$/, "");
  return {
    id: raw.id ?? `wire-${raw.week}-${hashString(headline).toString(36)}`,
    week: raw.week,
    season: raw.season,
    tone: raw.tone ?? "even",
    kicker: raw.kicker ?? "Notebook",
    headline,
    dek: raw.dek ?? "",
    byline: raw.byline ?? "Desk staff",
    outlet: raw.outlet ?? "The Desk",
    grafs: raw.grafs?.length ? raw.grafs : [text],
    resultId: raw.resultId,
    names: raw.names,
    text: headline,
  };
}

export function brief(week: number, headline: string, grafs: string[], tone: Tone = "even", kicker = "National"): NewsArticle {
  return asArticle({
    week,
    tone,
    kicker,
    headline,
    dek: grafs[0] ?? "",
    byline: "Desk staff",
    outlet: "The Desk",
    grafs,
    text: headline,
  });
}

function kickerFor(kind: GameSlot["kind"]) {
  if (kind === "conference") return "League";
  if (kind === "noncon") return "Non-conference";
  if (kind === "mte") return "Classic";
  if (kind === "conf-tourney") return "League tournament";
  if (kind === "ncaa") return "National";
  if (kind === "nit") return "Invite";
  if (kind === "crown") return "The Crown";
  return "College basketball";
}

function recordOf(state: GameState, id: string) {
  const t = state.teams[id];
  if (!t) return "";
  const conf = t.confW + t.confL > 0 ? `, ${t.confW}-${t.confL} in league play` : "";
  return `${t.wins}-${t.losses}${conf}`;
}

function cityLine(id: string, site: GameSlot["site"], kind: GameSlot["kind"]) {
  const t = school(id);
  if (!t) return "";
  if (kind === "ncaa" || kind === "nit" || kind === "crown" || kind === "conf-tourney" || kind === "mte" || site === "neutral") {
    return t.city.toUpperCase();
  }
  return t.city.toUpperCase();
}

function quoteWin(rng: Rng, last: string, margin: number) {
  const q =
    margin <= 3
      ? pick(rng, [
          "We made enough plays. Barely.",
          "Nobody in that locker room thinks we're good yet. We just weren't done.",
          "That's a grown-up win. The next one won't care.",
        ])
      : margin <= 12
        ? pick(rng, [
            "We were the tougher team for 40 minutes. I'll take that.",
            "Stops, then a rebound, then we didn't give it back.",
            "The guys who sit kept us in it. That's the part I liked.",
          ])
        : pick(rng, [
            "That's the standard. Don't come in here looking for a parade.",
            "We played like ourselves. They didn't.",
            "Put it in the book and get on the bus.",
          ]);
  return `${last} didn't dress it up afterward. "${q}"`;
}

function quoteLoss(rng: Rng, last: string, margin: number) {
  const q =
    margin <= 3
      ? pick(rng, [
          "We had it. We gave it back. That's on me.",
          "One possession. We'll live with the film. We won't like it.",
          "You don't get those nights back.",
        ])
      : pick(rng, [
          "We were second on every ball. That's the whole story.",
          "Credit them. We weren't serious for long enough.",
          "If that tape doesn't make you sick, you're in the wrong gym.",
        ]);
  return `${last} stood in the hallway longer than the questions. "${q}"`;
}

export function gameStory(state: GameState, slot: GameSlot, result: GameResult): NewsArticle {
  const rng = rngFor(state, result.id);
  const recap = recapFor(state, result);
  const homeWin = result.homeScore > result.awayScore;
  const winnerId = homeWin ? result.homeId : result.awayId;
  const loserId = homeWin ? result.awayId : result.homeId;
  const w = school(winnerId);
  const l = school(loserId);
  const winner = w?.name ?? winnerId;
  const loser = l?.name ?? loserId;
  const ws = homeWin ? result.homeScore : result.awayScore;
  const ls = homeWin ? result.awayScore : result.homeScore;
  const margin = ws - ls;
  const youIn = slot.homeId === state.playerTeamId || slot.awayId === state.playerTeamId;
  const youWin = winnerId === state.playerTeamId;
  const tone: Tone = !youIn ? "even" : youWin ? "good" : "bad";
  const dateline = cityLine(slot.homeId, slot.site, slot.kind);
  const site =
    slot.kind === "ncaa" || slot.kind === "mte" || slot.site === "neutral"
      ? "on a neutral floor"
      : slot.homeId === winnerId
        ? "at home"
        : "on the road";
  const star = (homeWin ? recap.homeLeaders : recap.awayLeaders)[0];
  const coachLast = youIn ? state.identity.last || "the coach" : "the bench";
  const ot = (result.minutes ?? 40) > 40;

  let headline = recap.headline.replace(/,\s*\d+[–-]\d+\s*$/, "").trim();
  if (headline.length < 12) {
    headline =
      margin <= 3
        ? `${winner} crawls past ${loser}`
        : margin <= 10
          ? `${winner} holds off ${loser}`
          : `${winner} puts ${loser} away`;
  }
  if (ot) headline = `${winner} outlasts ${loser} in overtime`;

  const dek = `${winner} ${ws}, ${loser} ${ls}${ot ? " in OT" : ""}`;
  const lead = `${dateline} — ${winner} walked out with ${ws}–${ls}${ot ? " in overtime" : ""} over ${loser} ${site}, a ${kickerFor(slot.kind).toLowerCase()} night that looks clean in the paper and felt anything but in the building.`;

  const starGraf = star
    ? `${star.name} led ${winner} with ${star.pts} points (${star.fgm}-for-${star.fga} from the floor), ${star.reb} rebounds and ${star.ast} assists in ${star.min} minutes.${margin <= 5 ? " Every one of them felt necessary." : " The gym spent the second half waiting for someone else to match him."}`
    : `${winner} got enough from the top of the rotation. ${loser} spent the night chasing.`;

  const recGraf = `${winner} sits at ${recordOf(state, winnerId) || "a result"}. ${loser} is ${recordOf(state, loserId) || "still looking"}. ${recap.keyPlay}`;

  const quote = youIn
    ? youWin
      ? quoteWin(rng, coachLast, margin)
      : quoteLoss(rng, coachLast, margin)
    : margin <= 4
      ? `It was a one-possession game in the last two minutes. Nobody in the building sat down.`
      : `${w?.mascot ?? "The winners"} were the better team for long enough. That was the difference.`;

  const next = youIn
    ? `Coach ${identityName(state.identity)} has ${state.recruitingHours} hours left on the trail this week and another one already on the calendar.`
    : undefined;

  const grafs = [lead, starGraf, recGraf, quote, next].filter((g): g is string => Boolean(g));
  const byline = pick(rng, WRITERS);
  const outlet = pick(rng, OUTLETS);

  return asArticle({
    id: `story-${result.id}`,
    week: result.week,
    season: state.season,
    tone,
    kicker: kickerFor(slot.kind),
    headline,
    dek,
    byline,
    outlet,
    grafs,
    resultId: result.id,
    text: `${headline} (${dek})`,
  });
}

export function campCopy(state: GameState): NewsArticle {
  const t = school(state.playerTeamId);
  const rng = rngFor(state, `camp-${state.season}`);
  const name = t?.name ?? "the program";
  return asArticle({
    week: 0,
    season: state.season,
    tone: "even",
    kicker: "Camp",
    headline: `${name} opens ${state.season} with more questions than answers`,
    dek: `${identityName(state.identity)} has the keys. The board will keep the receipts.`,
    byline: pick(rng, WRITERS),
    outlet: pick(rng, OUTLETS),
    grafs: [
      `${(t?.city ?? "Campus").toUpperCase()} — ${name} reported for ${state.season} this week. The gym smells like paint and new shoes. Nobody is picking them to do anything they haven't already earned.`,
      `${identityName(state.identity)} takes the chair after a hiring cycle that felt longer than it was. Prestige sits at ${state.teams[state.playerTeamId]?.prestige ?? "—"}. The league does not care.`,
      `Thirteen scholarships. A schedule still in pencil. The first real night will tell more than any presser.`,
    ],
    text: `${name} opens camp.`,
  });
}

export function lockCopy(state: GameState, filled: number): NewsArticle {
  const t = school(state.playerTeamId);
  return asArticle({
    week: 1,
    season: state.season,
    tone: "even",
    kicker: "Schedule",
    headline: `${t?.name ?? "The club"} sets the ${state.season} slate`,
    dek: filled > 0 ? `Staff filled ${filled} non-conference game${filled === 1 ? "" : "s"} to get to a full year.` : "The non-conference slate is set. League nights are already on it.",
    byline: "Desk staff",
    outlet: "The Desk",
    grafs: [
      `${t?.name ?? "The club"} finalized the ${state.season} regular season this week. ${filled > 0 ? `The office had holes. Staff went out and bought ${filled} game${filled === 1 ? "" : "s"} so the year actually has 30 nights.` : "They didn't wait on the phone. The 30 were already there."}`,
      `League play still sits in the middle of the calendar. The first tip is the only one that matters this week.`,
    ],
    text: `${t?.name ?? "The club"} set the schedule.`,
  });
}

export function hydrateNews(raw: GameState["news"] | { week: number; text: string; tone: Tone }[] | undefined): NewsArticle[] {
  if (!raw?.length) return [];
  return raw.map((n, i) => {
    if ("headline" in n && n.headline && "grafs" in n && Array.isArray(n.grafs) && n.grafs.length) {
      return asArticle(n);
    }
    const text = "text" in n && n.text ? n.text : "headline" in n ? String(n.headline) : "The wire.";
    return asArticle({
      id: `legacy-${n.week}-${i}`,
      week: n.week,
      tone: n.tone,
      kicker: "Notebook",
      headline: text.replace(/\.$/, ""),
      dek: "",
      grafs: [text],
      text,
    });
  });
}
