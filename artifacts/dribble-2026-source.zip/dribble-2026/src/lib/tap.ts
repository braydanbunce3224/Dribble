import type { MouseEvent } from "react";

export function installIosTaps(): () => void {
  return () => {};
}

export function bindTap(fn: () => void) {
  return {
    onClick: (e: MouseEvent<HTMLButtonElement>) => {
      e.stopPropagation();
      fn();
    },
  };
}

export function buzz(ms = 28) {
  try {
    if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") navigator.vibrate(ms);
  } catch {
    /* ignore */
  }
}
