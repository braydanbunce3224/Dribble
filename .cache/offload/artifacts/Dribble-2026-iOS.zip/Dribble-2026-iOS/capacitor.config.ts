import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.dribble2026.app",
  appName: "Dribble 2026",
  webDir: "native/www/client",
  bundledWebRuntime: false,
  backgroundColor: "#0b1f3a",
  ios: {
    contentInset: "automatic",
    preferredContentMode: "mobile",
    scheme: "Dribble2026",
  },
  android: {
    allowMixedContent: false,
    backgroundColor: "#0b1f3a",
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1200,
      backgroundColor: "#0B1F3A",
      showSpinner: false,
    },
    StatusBar: {
      style: "DARK",
      backgroundColor: "#0B1F3A",
    },
  },
};

export default config;
