package com.theprogram.dynasty;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
