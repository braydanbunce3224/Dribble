import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.theprogram.dynasty",
  appName: "Hoops Hero",
  webDir: "public-dist",
  backgroundColor: "#0b0b0c",
  android: {
    allowMixedContent: false,
    backgroundColor: "#0b0b0c",
  },
  ios: {
    backgroundColor: "#0b0b0c",
    contentInset: "automatic",
    preferredContentMode: "mobile",
    scheme: "Hoops Hero",
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1400,
      launchAutoHide: true,
      backgroundColor: "#0b0b0c",
      showSpinner: false,
      androidScaleType: "CENTER_CROP",
    },
    StatusBar: {
      style: "DARK",
      backgroundColor: "#0b0b0c",
    },
  },
};

export default config;
