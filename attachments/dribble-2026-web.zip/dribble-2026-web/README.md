# Dribble 2026 — playable browser build

A self-contained, dependency-free build of the **real Dribble 2026 engine** running in the
browser. No npm install, no build step, no server framework.

## Run it

ES modules require HTTP (not `file://`). From this folder:

```
python3 -m http.server 8099
```

then open <http://127.0.0.1:8099/>

Any static host works too — drop the folder on Netlify/Vercel/GitHub Pages as-is.

## What's in here

```
index.html      UI shell + styles
app.js          UI layer (vanilla JS, no framework)
game/*.js       the real engine, transpiled from src/game/*.ts
game/packs/     real-school name pack
```

`game/` is your actual simulation code — `engine`, `sim`, `plays`, `selection`, `ranks`,
`recruiting`, `portal`, `compliance`, `contract`, `chemistry`, `awards`, `persist` — with
TypeScript types stripped and import specifiers rewritten to `.js`. **No game logic was
changed.** Rebuild it any time with:

```
node scripts/build-web.mjs
```

## What works

- Dynasty or Career start, any of 365 schools
- Sim game / sim week / sim rest of season
- Press conferences with real consequences (AD heat, fan mood, morale)
- Roster: minutes, morale, pep talks, class/redshirt/injury status
- Recruiting: fog-of-war ratings, scout/offer/visit/sign, sign odds, assisted recruiting
- **Live gamecast**: pregame plan (10 offensive x 8 defensive calls), possession-by-possession play calling, shot chart, play-by-play, full box-score recap
- Rankings: efficiency (KenPom-style) + writers poll
- NCAA bracket with seeds, regions, auto bids, First Four
- Season rollover, contract reviews, extensions, the coaching carousel, stay-or-go draft
- History + awards, autosave to localStorage (resumes on reload)

## Not in this UI

This is a **lightweight UI over the full engine**, not a port of the React app. The engine
supports these but the UI doesn't surface them yet: the Invite/Crown tournaments, transfer portal screens, training camp,
NIL donor decisions, the news wire, schedule editing / holiday classics, and the Hall of Fame.
Adding any of them is UI work only — the engine calls already exist and are exported.

## Engine fixes included

This build contains the stability fixes made during the audit:

1. **CPU season stats** — `bumpMinutes` credited only your roster, so every other program
   ended each season at 0 games. That silently disabled the entire awards system
   (needs a 20+ player pool) and starved draft/stay-go scoring. Now ~480 awards/season.
2. **Save size** — portal transfers each stored a 364-entry interest map; the schedule was
   never slimmed; autosaves were written twice. 3,508 KB -> 2,324 KB, verified lossless.
3. **Draft roster floor** — with real stats flowing, blue bloods lost 5 players in one
   offseason and fell below the legal minimum. Added a 3-per-team cap and 9-player floor.
4. **Prestige snowball** — prestige rose +1 per tournament bid with no decay or ceiling
   pressure, ratcheting to 99 and driving a 66%-title-rate runaway. Added diminishing
   returns above 84/92 and mean-reversion toward the program baseline.
5. **`startNextSeason`** now warns instead of silently no-oping on an unresolved contract.
6. **Live box scores were wrong on every played game.** `live.log` is capped at 48 entries
   for display, but `boxFromLive()` rebuilt the official box by replaying that truncated
   log - recording a ~140-possession game as 23 possessions / 21 FGA / 0 FTA and yielding
   an impossible 3.35 points per possession. Those bogus boxes were stored on the result
   and fed team analytics, efficiency ratings and betting lines. Now derived from the
   authoritative per-player lines: possessions 69-72, PPP 0.72-1.25.
7. **Duplicate call buttons.** A gameplan may legally list the same play in two slots;
   `offeredCalls` then showed it twice and wasted one of the four buttons.

## Known caveat

Longest verified clean run is ~29 consecutive seasons with zero invariant failures.
A full 100-year validation run was still in progress when the audit ended, and fix #4
(the snowball rebalance) has not yet been confirmed to bend the title curve over a
full century. Treat 100-year stability as strongly indicated but not yet proven.
