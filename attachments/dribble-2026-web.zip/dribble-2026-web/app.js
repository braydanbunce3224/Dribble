import {
  newDynasty, lockSchedule, simWeek, simGame, nextYourGame, yourGames, resultFor,
  recordLine, scoutRecruit, offerRecruit, visitRecruit, signRecruit, setAssistedRecruit,
  interestIn, recruitStage, scholarshipsLeft, recruitingProgress, signChance,
  startNextSeason, goOffseason, settleDraft, draftWaiting, talkStay, letGo,
  answerPresser, recapFor, setPlayerMpg, pepTalk, classLabel, signExtension,
  takeContractJob, runLabel, yourAwards, awardLine,
  beginLiveGame, runLivePossession, runLiveRest, closeLive,
} from "./game/engine.js";
import {
  OFF_OPTS, DEF_OPTS, offeredCalls, liveYouOffense, clockLabel, crowdFill,
  setPlanSlot, lockGamePlan, setLiveCall,
} from "./game/plays.js";
import { TEAMS, TEAM_BY_ID, careerEligible } from "./game/teams.js";
import { teamChemistry } from "./game/chemistry.js";
import { kenpom, netRanks, apPoll } from "./game/ranks.js";
import { contractLine, contractProgress } from "./game/contract.js";
import { writeSave, loadSave, packedSize } from "./game/persist.js";

const $ = (id) => document.getElementById(id);
let S = null;
let view = "office";
let toast = null;
let recapId = null;

const fmt = (n) => (n == null ? "—" : n);
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const team = (id) => TEAM_BY_ID[id] ?? { name: id, abbr: id, mascot: "", color: "#888" };

function say(msg) {
  toast = msg;
  render();
  setTimeout(() => { if (toast === msg) { toast = null; render(); } }, 2600);
}

function commit(next, msg) {
  S = next;
  try { writeSave(S); } catch {}
  if (msg) say(msg);
  else render();
}

function busy(label, fn) {
  const el = $("busy");
  el.textContent = label;
  el.classList.add("on");
  setTimeout(() => {
    try { fn(); } catch (e) { console.error(e); say("Error: " + e.message); }
    el.classList.remove("on");
  }, 20);
}

/* ---------------- title / start ---------------- */

function renderTitle() {
  const saved = loadSave();
  const pool = [...TEAMS].sort((a, b) => b.prestige - a.prestige);
  return `
  <div class="title">
    <h1>DRIBBLE <span>2026</span></h1>
    <p class="sub">College basketball dynasty. 365 schools, 31 leagues, three postseason tournaments.</p>
    ${saved ? `<button class="big" data-act="continue">Continue — ${esc(team(saved.playerTeamId).name)} ${saved.season}</button>` : ""}
    <div class="startbox">
      <label>Coach name
        <input id="cn" value="Pat Stone" maxlength="24">
      </label>
      <label>Mode
        <select id="cmode">
          <option value="dynasty">Dynasty — pick any school</option>
          <option value="career">Career — start at a small program</option>
        </select>
      </label>
      <label>School
        <select id="cteam">
          ${pool.map((t) => `<option value="${t.id}">${esc(t.name)} (${t.prestige})</option>`).join("")}
        </select>
      </label>
      <button class="big" data-act="start">Take the job</button>
    </div>
  </div>`;
}

function startGame() {
  const name = ($("cn").value || "Pat Stone").trim().split(" ");
  const mode = $("cmode").value;
  const teamId = $("cteam").value;
  const t = TEAM_BY_ID[teamId];
  if (mode === "career" && !careerEligible(t)) {
    say("Career mode starts at prestige 62 or under. Pick a smaller school.");
    return;
  }
  busy("Building 365 rosters…", () => {
    const st = newDynasty(teamId, (Date.now() ^ (Math.random() * 1e9)) >>> 0, {
      careerMode: mode === "career",
      identity: { first: name[0] || "Pat", last: name.slice(1).join(" ") || "Stone", age: 38, almaMaterId: teamId },
    });
    S = lockSchedule(st);
    view = "office";
    commit(S, `${esc(t.name)} is yours.`);
  });
}

/* ---------------- views ---------------- */

function phaseLabel() {
  const p = S.phase;
  if (p === "preseason") return "Preseason";
  if (p === "regular") return `Week ${S.week}`;
  if (p === "conference") return "League tournament";
  if (p === "selection") return "Selection Day";
  if (p === "ncaa") return "National Tournament";
  if (p === "nit") return "The Invite";
  if (p === "crown") return "The Crown";
  return "Offseason";
}

function office() {
  const t = S.teams[S.playerTeamId];
  const sc = team(S.playerTeamId);
  const nx = nextYourGame(S);
  const opp = nx ? team(nx.homeId === S.playerTeamId ? nx.awayId : nx.homeId) : null;
  const chem = teamChemistry(S, S.playerTeamId);
  const kp = kenpom(S).find((r) => r.id === S.playerTeamId);
  const off = S.phase === "offseason";
  const rev = S.contractReview;
  const boardWaiting = off && rev && !rev.resolved && (rev.decision === "fire" || rev.decision === "extend");
  const last = S.history.log[S.history.log.length - 1];

  return `
  <div class="score" style="border-left:6px solid ${sc.color}">
    <div class="kick">${esc(S.identity.first)} ${esc(S.identity.last)} · ${phaseLabel()} · ${S.season}</div>
    <h2>${esc(sc.name)} <small>${esc(sc.mascot)}</small></h2>
    <div class="rec">${recordLine(t)}</div>
    <div class="kick">${t.conference} · prestige ${t.prestige} · league ${t.confW}-${t.confL}
      ${kp ? ` · KP #${kp.rank} (${kp.adjEM >= 0 ? "+" : ""}${kp.adjEM.toFixed(1)})` : ""}</div>
    <div class="kick">Career ${S.history.wins}-${S.history.losses}
      ${S.history.titles ? ` · ${S.history.titles} title${S.history.titles > 1 ? "s" : ""}` : ""}
      ${S.history.ncaaBids ? ` · ${S.history.ncaaBids} bids` : ""}</div>
  </div>

  ${last && last.season === S.season && last.run ? `<div class="card good"><b>${esc(runLabel(last.run) || "Season complete")}</b> — ${last.wins}-${last.losses}${last.confTitle ? ", league title" : ""}</div>` : ""}

  ${boardWaiting ? `<div class="card bad">
      <b>${rev.decision === "fire" ? "The board is moving on." : "Extension on the desk."}</b>
      <p>${esc(rev.letter)}</p>
      ${rev.decision === "extend"
        ? `<button data-act="sign">Sign the extension</button>`
        : rev.jobs.map((j) => `<button data-act="job" data-id="${j.teamId}">Take ${esc(team(j.teamId).name)}</button>`).join(" ")}
    </div>` : ""}

  ${nx && !off ? `<div class="card">
      <div class="kick">Next tip</div>
      <h3>${esc(opp.name)}</h3>
      <div class="kick">${nx.homeId === S.playerTeamId ? "vs" : nx.site === "neutral" ? "neutral" : "at"} ${opp.abbr}
        · Week ${nx.week} · ${nx.kind === "conference" ? "League" : nx.kind === "mte" ? "Classic" : nx.kind}</div>
    </div>` : ""}

  <div class="actions">
    ${off ? (draftWaiting(S)
        ? `<button class="big" data-act="draft">Stay-or-go decisions</button>`
        : boardWaiting ? "" : `<button class="big" data-act="next">Start ${S.season + 1} season</button>`)
      : `<button class="big" data-act="play">Play game</button>
         <button data-act="simgame">Sim next game</button>
         <button data-act="simweek">Sim week</button>`}
    ${!off && S.phase !== "preseason" ? `<button data-act="simseason">Sim rest of season</button>` : ""}
  </div>

  <div class="grid">
    <div class="tile"><div class="kick">Chemistry</div><b>${chem.score} · ${chem.label}</b><p>${esc(chem.note)}</p></div>
    <div class="tile"><div class="kick">Contract</div><b>${S.contract ? esc(contractLine(S.contract)) : "—"}</b>
      <p>${contractProgress(S).map((r) => `${esc(r.label)}: ${r.met ? "✓" : r.actual + "/" + r.target}`).join(" · ")}</p></div>
    <div class="tile"><div class="kick">Compliance</div><b>APR ${fmt(S.compliance?.apr)}</b><p>Heat ${fmt(S.compliance?.heat)}${S.compliance?.banned ? " · POSTSEASON BAN" : ""}</p></div>
    <div class="tile"><div class="kick">Mood</div><b>AD ${S.adHeat} · Fans ${S.fanMood}</b><p>Donors ${S.donorMood} · NIL pool ${S.nilCap}</p></div>
  </div>

  ${S.news.length ? `<div class="card"><div class="kick">${esc(S.news[0].kicker)}</div>
      <h3>${esc(S.news[0].headline)}</h3><p>${esc(S.news[0].grafs[0] || "")}</p></div>` : ""}
  `;
}

function rosterView() {
  const list = S.players.filter((p) => p.teamId === S.playerTeamId).sort((a, b) => b.ovr - a.ovr);
  const chem = teamChemistry(S, S.playerTeamId);
  return `<h2>Roster</h2>
  <div class="kick">Chemistry ${chem.score} (${chem.label}) · ${esc(chem.note)}</div>
  <table><thead><tr><th>Player</th><th>Pos</th><th>Yr</th><th>OVR</th><th>POT</th><th>MPG</th><th>Mor</th><th></th></tr></thead><tbody>
  ${list.map((p) => `<tr>
    <td><b>${esc(p.first)} ${esc(p.last)}</b>${p.injury && p.injury.weeksLeft > 0 ? ` <span class="bad-t">(${esc(p.injury.part)} ${p.injury.weeksLeft}w)</span>` : ""}${p.redshirt ? " <span class='kick'>RS</span>" : ""}</td>
    <td>${p.pos}</td><td>${esc(classLabel(p))}</td>
    <td><b>${p.ovr}</b></td><td>${p.potential}</td>
    <td><button data-act="mpg" data-id="${p.id}" data-d="-2">−</button> ${p.mpg} <button data-act="mpg" data-id="${p.id}" data-d="2">+</button></td>
    <td>${p.morale}</td>
    <td><button data-act="pep" data-id="${p.id}">Talk</button></td>
  </tr>`).join("")}
  </tbody></table>`;
}

function recruitView() {
  const pr = recruitingProgress(S);
  const you = S.playerTeamId;
  const board = S.recruits
    .filter((r) => !r.committedTo || r.committedTo === you)
    .sort((a, b) => (b.committedTo === you) - (a.committedTo === you) || interestIn(b, you, S) - interestIn(a, you, S) || b.stars - a.stars)
    .slice(0, 60);
  return `<h2>Recruiting</h2>
  <div class="kick">${pr.signed} signed · ${pr.open} spots open · ${S.recruitingHours}h this week · ${scholarshipsLeft(S)} scholarships</div>
  <label class="row"><input type="checkbox" id="assist" ${S.cpuRecruit ? "checked" : ""}> Assisted recruiting (staff works the board)</label>
  <table><thead><tr><th>Recruit</th><th>Pos</th><th>★</th><th>OVR</th><th>Interest</th><th>Stage</th><th>Odds</th><th>Actions</th></tr></thead><tbody>
  ${board.map((r) => {
    const signed = r.committedTo === you;
    const heat = interestIn(r, you, S);
    return `<tr class="${signed ? "signed" : ""}">
      <td><b>${esc(r.last)}</b>, ${esc(r.first)}${r.freakTag ? ` <span class="kick">${esc(r.freakTag)}</span>` : ""}${r.path === "juco" ? " <span class='kick'>JUCO</span>" : ""}</td>
      <td>${r.pos}</td><td>${"★".repeat(r.stars)}</td>
      <td>${r.scouted ? r.ovr : "?"}</td>
      <td><div class="bar"><i style="width:${heat}%"></i></div>${heat}</td>
      <td>${esc(recruitStage(r, you, S))}</td>
      <td>${signed ? "—" : signChance(r, S) + "%"}</td>
      <td>${signed ? "<b>Signed</b>" : `
        <button data-act="scout" data-id="${r.id}">Scout</button>
        <button data-act="offer" data-id="${r.id}">Offer</button>
        <button data-act="visit" data-id="${r.id}">Visit</button>
        <button data-act="signr" data-id="${r.id}">Sign</button>`}</td>
    </tr>`;
  }).join("")}
  </tbody></table>`;
}

function scheduleView() {
  const gs = yourGames(S).sort((a, b) => a.week - b.week);
  return `<h2>Schedule</h2>
  <table><thead><tr><th>Wk</th><th>Opponent</th><th>Site</th><th>Type</th><th>Result</th></tr></thead><tbody>
  ${gs.map((g) => {
    const oppId = g.homeId === S.playerTeamId ? g.awayId : g.homeId;
    const r = resultFor(S, g);
    let res = "—";
    if (r) {
      const mine = g.homeId === S.playerTeamId ? r.homeScore : r.awayScore;
      const th = g.homeId === S.playerTeamId ? r.awayScore : r.homeScore;
      res = `<b class="${mine > th ? "good-t" : "bad-t"}">${mine > th ? "W" : "L"}</b> ${mine}–${th}`;
    }
    return `<tr><td>${g.week}</td><td>${esc(team(oppId).name)}</td>
      <td>${g.homeId === S.playerTeamId ? "H" : g.site === "neutral" ? "N" : "A"}</td>
      <td>${g.kind}</td><td>${res}</td></tr>`;
  }).join("")}
  </tbody></table>`;
}

function ranksView() {
  const kp = kenpom(S).slice(0, 25);
  const ap = apPoll(S).slice(0, 25);
  return `<h2>Rankings</h2>
  <div class="two">
    <div><h3>Efficiency (top 25)</h3><table><thead><tr><th>#</th><th>Team</th><th>AdjEM</th><th>W-L</th></tr></thead><tbody>
      ${kp.map((r) => `<tr class="${r.id === S.playerTeamId ? "me" : ""}"><td>${r.rank}</td><td>${esc(team(r.id).name)}</td>
      <td>${r.adjEM >= 0 ? "+" : ""}${r.adjEM.toFixed(1)}</td><td>${r.wins}-${r.losses}</td></tr>`).join("")}
    </tbody></table></div>
    <div><h3>Writers poll</h3><table><thead><tr><th>#</th><th>Team</th><th>Rec</th><th>Pts</th></tr></thead><tbody>
      ${ap.map((r) => `<tr class="${r.id === S.playerTeamId ? "me" : ""}"><td>${r.rank}</td><td>${esc(team(r.id).name)}</td>
      <td>${r.wins}-${r.losses}</td><td>${r.points}</td></tr>`).join("")}
    </tbody></table></div>
  </div>`;
}

function bracketView() {
  const sel = S.selection;
  if (!sel || !sel.ncaa.length) return `<h2>Bracket</h2><p class="kick">The field is set on Selection Day.</p>`;
  const regions = ["East", "West", "South", "Midwest"];
  return `<h2>National Tournament</h2>
  ${sel.champ ? `<div class="card good"><b>Champion: ${esc(team(sel.champ).name)}</b></div>` : ""}
  <div class="two">${regions.map((rg) => `<div><h3>${rg}</h3><table><tbody>
    ${sel.ncaa.filter((b) => b.region === rg).sort((a, b) => a.seed - b.seed)
      .map((b) => `<tr class="${b.teamId === S.playerTeamId ? "me" : ""}"><td>${b.seed}</td><td>${esc(team(b.teamId).name)}</td>
        <td class="kick">${b.path === "auto" ? "AUTO" : ""}${b.playIn ? " FF" : ""}</td></tr>`).join("")}
  </tbody></table></div>`).join("")}</div>`;
}

function historyView() {
  const aw = yourAwards(S);
  return `<h2>History</h2>
  ${aw.length ? `<div class="card"><div class="kick">This season's honors</div>${aw.slice(0, 8).map((a) => `<div>${esc(awardLine(a))}</div>`).join("")}</div>` : ""}
  <table><thead><tr><th>Season</th><th>School</th><th>Record</th><th>League</th><th>March</th></tr></thead><tbody>
  ${[...S.history.log].reverse().map((y) => `<tr>
    <td>${y.season}</td><td>${esc(team(y.teamId).name)}</td><td>${y.wins}-${y.losses}</td>
    <td>${y.confW}-${y.confL}${y.confTitle ? " 🏆" : ""}</td>
    <td>${esc(runLabel(y.run) || (y.ncaaBid ? "Bid" : "—"))}</td></tr>`).join("")}
  </tbody></table>`;
}

function draftView() {
  const d = S.draft;
  if (!d) return `<h2>Draft</h2><p class="kick">No draft board.</p>`;
  const open = d.rows.filter((r) => !r.decided);
  return `<h2>Stay or go</h2>
  ${open.length === 0 ? `<p class="kick">No decisions left.</p>` : ""}
  ${open.map((r) => `<div class="card">
    <b>${esc(r.name)}</b> <span class="kick">${r.pos} · ${r.ovr} ovr · ${r.band} · stay ${r.stayChance}%</span>
    <div><button data-act="stay" data-id="${r.playerId}">Talk him into staying</button>
    <button data-act="go" data-id="${r.playerId}">Let him go</button></div></div>`).join("")}
  ${d.league.length ? `<h3>Draft board</h3><table><tbody>${d.league.slice(0, 30).map((p) => `<tr>
    <td>${p.pick}</td><td>${esc(p.name)}${p.yours ? " <b>(yours)</b>" : ""}</td><td class="kick">${esc(p.proName || "")}</td></tr>`).join("")}</tbody></table>` : ""}`;
}

function presserView() {
  const p = S.pendingPresser;
  const q = p.questions[p.asked];
  return `<div class="card"><div class="kick">Press conference · ${p.asked + 1} of ${p.questions.length}</div>
  <h2>${esc(q.prompt)}</h2>
  ${q.choices.map((c) => `<button class="wide" data-act="answer" data-id="${c.id}">${esc(c.label)}</button>`).join("")}</div>`;
}

/* ---------------- live gamecast ---------------- */

const OFF_LABEL = Object.fromEntries(OFF_OPTS.map((o) => [o.id, o.label]));
const DEF_LABEL = Object.fromEntries(DEF_OPTS.map((o) => [o.id, o.label]));

function court(live) {
  // Engine coords are a 94x50ft floor; events carry x/y, kind, made, poss.
  const marks = live.log
    .filter((e) => e.kind && e.kind !== "period" && e.x != null && e.y != null)
    .slice(0, 40);
  const last = marks[0];
  const dot = (e, i) => {
    const home = e.poss === "home";
    const col = home ? "var(--homec)" : "var(--awayc)";
    const isLast = e === last;
    if (e.kind === "to") {
      return `<g opacity="${isLast ? 1 : .38}" transform="translate(${e.x},${e.y})">
        <line x1="-1.3" y1="-1.3" x2="1.3" y2="1.3" stroke="#c48982" stroke-width=".5"/>
        <line x1="1.3" y1="-1.3" x2="-1.3" y2="1.3" stroke="#c48982" stroke-width=".5"/></g>`;
    }
    const r = e.kind === "three" ? 1.35 : 1.1;
    return `<circle cx="${e.x}" cy="${e.y}" r="${r}" fill="${e.made ? col : "none"}"
      stroke="${col}" stroke-width=".5" opacity="${isLast ? 1 : .42}"/>`;
  };
  return `<svg viewBox="0 0 94 50" class="court" role="img" aria-label="Shot chart">
    <rect width="94" height="50" fill="#1a3a24"/>
    <rect x="1" y="1" width="92" height="48" fill="none" stroke="rgba(242,241,236,.35)" stroke-width=".4"/>
    <line x1="47" y1="1" x2="47" y2="49" stroke="rgba(242,241,236,.28)" stroke-width=".3"/>
    <circle cx="47" cy="25" r="6" fill="none" stroke="rgba(242,241,236,.28)" stroke-width=".3"/>
    <rect x="1" y="16" width="18" height="18" fill="none" stroke="rgba(242,241,236,.28)" stroke-width=".3"/>
    <rect x="75" y="16" width="18" height="18" fill="none" stroke="rgba(242,241,236,.28)" stroke-width=".3"/>
    <circle cx="19" cy="25" r="6" fill="none" stroke="rgba(242,241,236,.22)" stroke-width=".3"/>
    <circle cx="75" cy="25" r="6" fill="none" stroke="rgba(242,241,236,.22)" stroke-width=".3"/>
    <path d="M 2.25 3.2 L 2.25 8 A 22.15 22.15 0 0 0 2.25 42 L 2.25 46.8" fill="none" stroke="rgba(242,241,236,.32)" stroke-width=".3"/>
    <path d="M 91.75 3.2 L 91.75 8 A 22.15 22.15 0 0 1 91.75 42 L 91.75 46.8" fill="none" stroke="rgba(242,241,236,.32)" stroke-width=".3"/>
    <circle cx="5.25" cy="25" r=".9" fill="none" stroke="#c45c3e" stroke-width=".35"/>
    <circle cx="88.75" cy="25" r=".9" fill="none" stroke="#c45c3e" stroke-width=".35"/>
    ${marks.slice().reverse().map(dot).join("")}
  </svg>`;
}

function pregame(live) {
  const home = team(live.homeId), away = team(live.awayId);
  const off = live.planOff ?? ["motion", "pnr", "spread"];
  const def = live.planDef ?? ["man", "pack"];
  const crowd = crowdFill(S, live);
  const row = (side, i, cur, opts) => `
    <div class="planrow">
      <div class="kick">${side === "off" ? (i === 0 ? "1st look" : i === 1 ? "2nd look" : "3rd look") : (i === 0 ? "Base" : "Change")} · ${esc(opts[cur] || cur)}</div>
      <div class="chips">${Object.entries(opts).map(([id, label]) =>
        `<button class="chip ${id === cur ? "on" : ""}" data-act="plan" data-side="${side}" data-i="${i}" data-id="${id}">${esc(label)}</button>`).join("")}</div>
    </div>`;
  return `<div class="gamecast">
    <div class="kick">Gameplan</div>
    <h2>${esc(away.name)} at ${esc(home.name)}</h2>
    <div class="kick">${crowd.split ? "Split crowd" : crowd.packed ? "Packed house" : "Home gym"} · ${Math.round(crowd.home * 100)}% house</div>
    <h3>Offense</h3>
    ${off.slice(0, 3).map((id, i) => row("off", i, id, OFF_LABEL)).join("")}
    <h3>Defense</h3>
    ${def.slice(0, 2).map((id, i) => row("def", i, id, DEF_LABEL)).join("")}
    <div class="actions">
      <button class="big" data-act="tipoff">Tip off</button>
      <button data-act="simrest">Sim the game</button>
    </div>
  </div>`;
}

function gamecast() {
  const live = S.liveGame;
  if (!live) return office();
  if (!live.planned && !live.done) return pregame(live);

  const home = team(live.homeId), away = team(live.awayId);
  const youHome = live.homeId === S.playerTeamId;
  const last = live.log.find((e) => e.kind && e.kind !== "period") ?? live.log[0];
  const youOff = liveYouOffense(S);
  const calls = live.done ? [] : offeredCalls(S);
  const ht = live.planned && live.half === 2 && !live.htAdj && !live.done;

  return `<div class="gamecast" style="--homec:${home.color};--awayc:${away.color}">
    <div class="kick">${live.done ? "Final" : clockLabel(live.half, live.clock)}</div>
    <div class="scoreline">
      <div class="side ${youHome ? "you" : ""} ${live.poss === "home" && !live.done ? "ball" : ""}">
        <span class="dot" style="background:${home.color}"></span>
        <b>${esc(home.abbr)}</b><span class="pts">${live.homeScore}</span>
      </div>
      <div class="side ${!youHome ? "you" : ""} ${live.poss === "away" && !live.done ? "ball" : ""}">
        <span class="dot" style="background:${away.color}"></span>
        <b>${esc(away.abbr)}</b><span class="pts">${live.awayScore}</span>
      </div>
    </div>

    ${court(live)}

    ${last ? `<div class="lastplay"><span class="kick">${esc(last.t)}</span>
      <p>${esc(last.text)}</p>
      ${last.impact ? `<p class="${(last.pts ?? 0) > 0 ? "good-t" : "bad-t"}"><b>${esc(last.impact)}</b></p>` : ""}</div>` : ""}

    ${live.done ? `<div class="actions">
        <button class="big" data-act="finishgame">Read the recap</button>
      </div>`
      : `<div class="callbox">
          <div class="kick">${ht ? "Halftime — mix the plan" : youOff ? "Your ball — pick a call" : "Their ball — pick a defense"}</div>
          <div class="calls">${calls.map((c) =>
            `<button class="call" data-act="call" data-side="${c.side}" data-id="${c.id}">${esc(c.label)}</button>`).join("")}</div>
          <button data-act="simrest">Sim rest of game</button>
        </div>`}

    <div class="pbp">${live.log.filter((e) => e !== last).slice(0, 12).map((e) =>
      `<div><span class="kick">${esc(e.t)}</span> ${esc(e.text)}</div>`).join("")}</div>
  </div>`;
}

function recapView() {
  const r = S.results.find((x) => x.id === recapId)
    ?? [...S.results].reverse().find((x) => x.homeId === S.playerTeamId || x.awayId === S.playerTeamId);
  if (!r) { view = "office"; return office(); }
  const rec = recapFor(S, r);
  const home = team(r.homeId), away = team(r.awayId);
  const youHome = r.homeId === S.playerTeamId;
  const mine = youHome ? r.homeScore : r.awayScore;
  const theirs = youHome ? r.awayScore : r.homeScore;
  const box = (title, color, rows) => `<div class="boxcard">
    <h3><span class="dot" style="background:${color}"></span>${esc(title)}</h3>
    <table><thead><tr><th>Player</th><th>MIN</th><th>PTS</th><th>REB</th><th>AST</th><th>FG</th><th>3PT</th><th>FT</th></tr></thead><tbody>
    ${rows.slice(0, 8).map((p) => `<tr><td><b>${esc(p.name)}</b> <span class="kick">${p.pos}</span></td>
      <td>${p.min}</td><td><b>${p.pts}</b></td><td>${p.reb}</td><td>${p.ast}</td>
      <td>${p.fgm}-${p.fga}</td><td>${p.tpm ?? 0}-${p.tpa ?? 0}</td><td>${p.ftm ?? 0}-${p.fta ?? 0}</td></tr>`).join("")}
    </tbody></table></div>`;
  return `<div class="recap">
    <div class="kick">${rec.played ? "You called it" : "Simulated"} · Week ${r.week}</div>
    <h2>${esc(rec.headline)}</h2>
    <p class="lede">${esc(rec.lede)}</p>
    <div class="finalbar ${mine > theirs ? "won" : "lost"}">
      <b>${mine > theirs ? "WIN" : "LOSS"}</b> ${esc(away.abbr)} ${r.awayScore} — ${r.homeScore} ${esc(home.abbr)}
    </div>
    ${rec.grafs.map((g) => `<p>${esc(g)}</p>`).join("")}
    <div class="card"><div class="kick">Key sequence</div><p>${esc(rec.keyPlay)}</p></div>
    <div class="two">
      ${box(home.name, home.color, rec.homeLeaders)}
      ${box(away.name, away.color, rec.awayLeaders)}
    </div>
    ${rec.notes.length ? `<ul class="notes">${rec.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>` : ""}
    <button class="big" data-act="closerecap">Back to the office</button>
  </div>`;
}

/* ---------------- shell ---------------- */

function render() {
  const root = $("app");
  if (!S) { root.innerHTML = renderTitle(); wire(); return; }
  if (S.pendingPresser) { root.innerHTML = presserView(); wire(); return; }
  if (S.liveGame && view === "game") { root.innerHTML = gamecast(); wire(); return; }
  if (view === "recap") { root.innerHTML = recapView(); wire(); return; }

  const tabs = [["office", "Office"], ["roster", "Roster"], ["schedule", "Schedule"], ["recruit", "Recruit"],
                ["ranks", "Ranks"], ["bracket", "Bracket"], ["history", "History"]];
  if (draftWaiting(S)) tabs.push(["draft", "Draft"]);

  const body = { office, roster: rosterView, schedule: scheduleView, recruit: recruitView,
                 ranks: ranksView, bracket: bracketView, history: historyView, draft: draftView }[view] || office;

  root.innerHTML = `
    <nav>${tabs.map(([id, label]) => `<button class="${view === id ? "on" : ""}" data-tab="${id}">${label}</button>`).join("")}
      <span class="spacer"></span>
      <button data-act="title" class="ghost">Title</button></nav>
    <main>${body()}</main>
    ${toast ? `<div class="toast">${esc(toast)}</div>` : ""}`;
  wire();
}

function wire() {
  document.querySelectorAll("[data-tab]").forEach((b) => b.onclick = () => { view = b.dataset.tab; render(); });
  const as = $("assist");
  if (as) as.onchange = () => commit(setAssistedRecruit(S, as.checked).state, as.checked ? "Staff is on the trail." : "You're recruiting.");
  document.querySelectorAll("[data-act]").forEach((b) => { b.onclick = () => act(b.dataset.act, b.dataset); });
}

function simToOffseason() {
  let s = S, guard = 0;
  while (s.phase !== "offseason" && guard++ < 120) s = { ...simWeek(s), pendingPresser: null };
  return s;
}

function act(a, data) {
  const id = data.id;
  if (a === "start") return startGame();
  if (a === "continue") { S = loadSave(); view = "office"; return render(); }
  if (a === "title") { if (confirm("Back to title? Progress is saved.")) { S = null; render(); } return; }

  if (a === "play") {
    const next = beginLiveGame(S);
    if (!next) return say("No game left to play.");
    S = next; view = "game"; return render();
  }
  if (a === "plan") { S = setPlanSlot(S, data.side, Number(data.i), id); return render(); }
  if (a === "tipoff") { S = lockGamePlan(S); return render(); }
  if (a === "call") {
    let s = S;
    if (s.liveGame && !s.liveGame.planned) s = lockGamePlan(s);
    s = setLiveCall(s, data.side, id);
    S = runLivePossession(s);
    return render();
  }
  if (a === "simrest") return busy("Playing it out…", () => {
    let s = S;
    if (s.liveGame && !s.liveGame.planned) s = lockGamePlan(s);
    S = runLiveRest(s); render();
  });
  if (a === "finishgame") return busy("Filing the recap…", () => {
    const slotId = S.liveGame?.slotId;
    const closed = closeLive(S);
    const res = closed.results.find((r) => r.slotId === slotId);
    recapId = res ? res.id : null;
    view = "recap";
    commit(closed);
  });
  if (a === "closerecap") { recapId = null; view = "office"; return render(); }

  if (a === "simgame") return busy("Playing the game…", () => {
    const before = new Set(S.results.map((r) => r.id));
    const next = { ...simGame(S) };
    const added = next.results.find((r) => !before.has(r.id) && (r.homeId === next.playerTeamId || r.awayId === next.playerTeamId));
    if (added && !next.pendingPresser) { recapId = added.id; view = "recap"; }
    commit(next);
  });
  if (a === "simweek") return busy("Playing the week…", () => commit({ ...simWeek(S) }));
  if (a === "simseason") return busy("Simulating the season…", () => commit(simToOffseason()));
  if (a === "next") return busy("Opening next season…", () => { const n = startNextSeason(S); commit(lockSchedule(n), `${n.season} is open.`); });
  if (a === "draft") { view = "draft"; return render(); }

  if (a === "answer") return commit(answerPresser(S, id).state);
  if (a === "sign") { const r = signExtension(S); return commit(r.state, r.ok ? "Signed." : "Nothing to sign."); }
  if (a === "job") { const r = takeContractJob(S, id); return commit(r.state, r.ok ? `You're at ${team(id).name}.` : "Gone."); }
  if (a === "stay") { const r = talkStay(S, id); return commit(r.state, r.feedback.title); }
  if (a === "go") { const r = letGo(S, id); return commit(r.state, r.feedback.title); }

  if (a === "mpg") { const p = S.players.find((x) => x.id === id); return commit(setPlayerMpg(S, id, p.mpg + Number(data.d))); }
  if (a === "pep") { const r = pepTalk(S, id); return commit(r.state, r.feedback.title); }

  const rec = { scout: scoutRecruit, offer: offerRecruit, visit: visitRecruit, signr: signRecruit }[a];
  if (rec) { const r = rec(S, id); return commit(r.state, r.feedback.title + (r.feedback.detail ? " — " + r.feedback.detail : "")); }
}

/* boot */
const prior = loadSave();
if (prior) { S = prior; }
render();
window.addEventListener("beforeunload", () => { if (S) try { writeSave(S); } catch {} });
