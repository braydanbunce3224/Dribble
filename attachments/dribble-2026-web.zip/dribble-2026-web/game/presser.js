                                                                                  
import { TEAM_BY_ID } from "./teams.js";
import { hashString, mulberry32,          } from "./rng.js";
import { identityName } from "./engine-util.js";

                          
                 
               
                 
                  
                      
                      
                
                
                   
                   
                 
               
               
               
 

export function gameCtx(state           , slotId        )                 {
  const slot = state.schedule.find((g) => g.id === slotId);
  const res = state.results.find((r) => r.slotId === slotId);
  if (!slot || !res) return null;
  const youHome = slot.homeId === state.playerTeamId;
  const youScore = youHome ? res.homeScore : res.awayScore;
  const oppScore = youHome ? res.awayScore : res.homeScore;
  const oppId = youHome ? slot.awayId : slot.homeId;
  const opp = TEAM_BY_ID[oppId] ;
  const you = state.teams[state.playerTeamId] ;
  const school = TEAM_BY_ID[state.playerTeamId] ;
  const star = state.players.filter((p) => p.teamId === state.playerTeamId).sort((a, b) => b.ovr - a.ovr)[0];
  return {
    slotId,
    won: youScore > oppScore,
    margin: Math.abs(youScore - oppScore),
    oppName: opp.name,
    oppPrestige: TEAM_BY_ID[oppId]?.prestige ?? 60,
    youPrestige: school.prestige,
    home: youHome && slot.site === "home",
    conf: slot.kind === "conference" || slot.kind === "conf-tourney",
    youScore,
    oppScore,
    record: `${you.wins}-${you.losses}`,
    star: star ? `${star.first} ${star.last}` : "the lead guard",
    week: slot.week,
    nil: state.nilCap > 0,
  };
}

export function shouldHoldPresser(state           , ctx         , rng     )          {
  const notable = ctx.margin <= 4 || ctx.margin >= 16 || ctx.conf || Math.abs(ctx.youPrestige - ctx.oppPrestige) >= 12 || ctx.week >= 16;
  const since = state.week - (state.lastPresserWeek ?? -9);
  if (notable) return rng() < (since <= 1 ? 0.45 : 0.7);
  if (since <= 2) return false;
  return rng() < 0.2;
}

                
             
                                              
                                               
                                                                   
  

function C(id        , label        , tone                       , morale        , ad        , fans        )                {
  return { id, label, tone, morale, ad, fans };
}

const FACTORIES            = [
  {
    id: "win-close",
    when: (c) => c.won && c.margin <= 5,
    prompt: (c) => `You needed one more stop against ${c.oppName} and you got it, ${c.youScore}-${c.oppScore}. What was the difference?`,
    choices: (c, s) => [
      C("a", "The guys who have been in the gym in June. That's who made the play.", "cool", 4, 2, 2),
      C("b", "We executed the last two possessions. That's the job.", "even", 2, 3, 1),
      C("c", "Luck. We'll take it. Don't ask me to draw it up again.", "even", 1, -1, 2),
      C("d", "They folded. We didn't. That's who we are.", "hot", -2, 0, 4),
    ],
  },
  {
    id: "win-blowout",
    when: (c) => c.won && c.margin >= 16,
    prompt: (c) => `${c.oppName} never got in the game. ${c.youScore}-${c.oppScore}. Is that the standard now?`,
    choices: (c) => [
      C("a", "One night. The film will still be ugly in spots.", "cool", 2, 3, 0),
      C("b", "That's how we should look when we play on time.", "even", 3, 2, 2),
      C("c", "We're built for this. The league can take notes.", "hot", 0, 1, 5),
      C("d", "Ask me in March. November blowouts don't hang banners.", "even", 1, 2, -1),
    ],
  },
  {
    id: "win-standard",
    when: (c) => c.won && c.margin > 5 && c.margin < 16,
    prompt: (c) => `You beat ${c.oppName} ${c.youScore}-${c.oppScore}. How do you want this locker room to hear it?`,
    choices: () => [
      C("a", "Credit the guys who sat and the ones who played.", "cool", 4, 2, 1),
      C("b", "We're not satisfied. That was a step, not a statement.", "even", 1, 3, 2),
      C("c", "They doubted us. They can keep talking.", "hot", -2, -1, 5),
      C("d", "That's the system. I had them ready.", "hot", -5, -2, 0),
    ],
  },
  {
    id: "loss-close",
    when: (c) => !c.won && c.margin <= 5,
    prompt: (c) => `${c.oppName} made one more play. ${c.oppScore}-${c.youScore}. How do you live with that film?`,
    choices: () => [
      C("a", "That's on me. I'll take the last possession.", "cool", 3, 4, 1),
      C("b", "We compete. The result is one night.", "even", 1, 0, 2),
      C("c", "I'm not talking about the officiating. You saw it.", "hot", -1, -4, 3),
      C("d", "We had it. We gave it away. That's the truth.", "hot", -3, -1, 1),
    ],
  },
  {
    id: "loss-blowout",
    when: (c) => !c.won && c.margin >= 16,
    prompt: (c) => `That was a ${c.margin}-point night against ${c.oppName}. Are you still the right voice for this locker room?`,
    choices: () => [
      C("a", "Yes. We'll get this fixed on the floor, not on a podium.", "even", 2, 2, 0),
      C("b", "I didn't have them ready. That's the only headline.", "cool", 1, 4, -1),
      C("c", "Some guys didn't show up. That's the truth.", "hot", -6, -3, -2),
      C("d", "Ask the people writing the checks if they still believe. I do.", "hot", -2, -5, 3),
    ],
  },
  {
    id: "loss-standard",
    when: (c) => !c.won && c.margin > 5 && c.margin < 16,
    prompt: (c) => `${c.oppName} had the last word, ${c.oppScore}-${c.youScore}. What's the message?`,
    choices: () => [
      C("a", "That's on me. We'll fix the film.", "cool", 2, 3, 1),
      C("b", "We compete. The result is one night.", "even", 1, 0, 2),
      C("c", "I'm not talking about the officiating. You saw it.", "hot", -1, -4, 3),
      C("d", "Minutes will change. The tape was honest.", "hot", -4, 1, 0),
    ],
  },
  {
    id: "home-crowd",
    when: (c) => c.home,
    prompt: (c) => `The students waited through ${c.oppName}. What did they just pay to watch?`,
    choices: (c) => [
      C("a", "A team that will play for this building every night.", "cool", 3, 2, 4),
      C("b", c.won ? "A win. That's what they came for." : "A group that still has work to do. We owe them better.", "even", 1, 1, 2),
      C("c", "They were louder than we were. That's on us.", "even", 2, 0, 1),
      C("d", "If they want a show, write the NIL checks.", "hot", 0, -4, 3),
    ],
  },
  {
    id: "road",
    when: (c) => !c.home,
    prompt: (c) => `Hostile gym at ${c.oppName}. Did you like how you competed?`,
    choices: (c) => [
      C("a", c.won ? "Loved it. That's a road group." : "We competed. We didn't finish.", "even", 3, 2, 2),
      C("b", "The crowd got to a couple of guys. I'll handle that.", "cool", 1, 3, 0),
      C("c", "This league doesn't scare us. Next building.", "hot", 2, 0, 3),
      C("d", "We came to survive, not to make friends.", "even", 0, 1, 1),
    ],
  },
  {
    id: "league",
    when: (c) => c.conf,
    prompt: (c) => `League play is a different animal. What's the message to the rest of the conference after ${c.oppName}?`,
    choices: () => [
      C("a", "We're not going anywhere.", "even", 2, 2, 3),
      C("b", "One league game. There are a lot of them.", "cool", 1, 3, 0),
      C("c", "If you want our gym, bring a better team.", "hot", 1, 0, 4),
      C("d", "The standings will sort it out. I'm not doing the sorting tonight.", "even", 0, 2, -1),
    ],
  },
  {
    id: "star",
    when: (c) => true,
    prompt: (c) => `${c.star} had the ball in his hands down the stretch. Is that the plan going forward?`,
    choices: (c) => [
      C("a", `${c.star} earned that. He'll keep it until someone takes it.`, "cool", 4, 1, 2),
      C("b", "Whoever is hot. The playbook is bigger than one name.", "even", 2, 2, 1),
      C("c", "If he wants the shot, he has to guard. That's the deal.", "hot", -2, 2, 0),
      C("d", "I call the play. They run it. Ego doesn't get a vote.", "even", 0, 3, -1),
    ],
  },
  {
    id: "ad-watch",
    when: (_c, s) => s.adHeat >= 62 || s.adHeat <= 32,
    prompt: (_c, s) => s.adHeat >= 62
      ? "The administration is in the back of the room. Can you still do this job?"
      : "The AD just nodded through your last three answers. What do they need to hear?",
    choices: () => [
      C("a", "I was hired to build this. I'm still building it.", "even", 2, 3, 1),
      C("b", "Win the next one and this conversation changes.", "even", 1, 2, 2),
      C("c", "If they want a new voice, they know where to find me.", "hot", -3, -5, 2),
      C("d", "Trust the work. March is built in November.", "cool", 2, 4, 2),
    ],
  },
  {
    id: "nil",
    when: (c) => c.nil,
    prompt: (c) => `Donors keep asking about the NIL pool after ${c.oppName}. What do you tell them?`,
    choices: () => [
      C("a", "Help us keep the guys who already bled for this place.", "cool", 3, 1, 2),
      C("b", "Write the checks and we'll keep the talent. That's the sport now.", "hot", 1, -3, 4),
      C("c", "Development still beats a contract. I believe that.", "even", 4, 2, -1),
      C("d", "That's above my pay grade. I coach the ones in the gym.", "even", 2, 3, 0),
    ],
  },
  {
    id: "fans",
    when: (c) => true,
    prompt: (c, s) => identityName(s.identity) + `, the fan base is ${s.fanMood >= 60 ? "with you" : "restless"}. What do they need to hear?`,
    choices: () => [
      C("a", "Stay with us. This group will give you a reason.", "cool", 2, 2, 4),
      C("b", "Boos don't bother me. Losing does.", "hot", 0, 1, -2),
      C("c", "We're going to play fast, physical, and honest.", "even", 3, 2, 3),
      C("d", "If you're here for a 40-win fairy tale, you're in the wrong gym.", "hot", -1, -2, -3),
    ],
  },
  {
    id: "morale",
    when: (_c, s) => {
      const r = s.players.filter((p) => p.teamId === s.playerTeamId);
      const avg = r.reduce((n, p) => n + p.morale, 0) / Math.max(1, r.length);
      return avg < 58;
    },
    prompt: () => "The body language was obvious. How do you get this room back?",
    choices: () => [
      C("a", "Closed doors. Honest film. Then we go back to work.", "cool", 5, 2, 0),
      C("b", "Minutes will change if the tape says so.", "hot", -3, 2, 0),
      C("c", "I believe in every guy who walked in that locker room.", "cool", 5, 1, 2),
      C("d", "Some of them should be nervous.", "hot", -7, 0, -1),
    ],
  },
  {
    id: "belief",
    when: () => true,
    prompt: () => "Last one from the tunnel — a player asked if you still believe in this group.",
    choices: () => [
      C("a", "I believe in every guy who walked in that locker room.", "cool", 5, 1, 2),
      C("b", "Belief is earned on the next possession.", "even", 1, 2, 1),
      C("c", "Minutes will change if the tape says so.", "hot", -3, 2, 0),
      C("d", "Some of them should be nervous.", "hot", -7, 0, -1),
    ],
  },
];

export function buildPresser(state           , slotId        )                 {
  const ctx = gameCtx(state, slotId);
  if (!ctx) return null;
  const rng = mulberry32(state.seed ^ hashString(slotId) ^ (state.week * 911) ^ (state.recentQuestionIds?.length ?? 0));
  if (!shouldHoldPresser(state, ctx, rng)) return null;
  const recent = new Set(state.recentQuestionIds ?? []);
  const matched = FACTORIES.filter((f) => f.when(ctx, state));
  const fresh = matched.filter((f) => !recent.has(f.id));
  const pool = fresh.length >= 2 ? fresh : matched;
  const shuffled = [...pool].sort(() => rng() - 0.5);
  const take = shuffled.slice(0, rng() < 0.35 ? 1 : 2);
  const questions                    = take.map((f) => ({
    id: f.id,
    prompt: f.prompt(ctx, state),
    choices: f.choices(ctx, state, rng).sort(() => rng() - 0.5),
  }));
  if (!questions.length) return null;
  return { gameId: slotId, questions, asked: 0, log: [] };
}

export function rememberQuestions(state           , presser         )           {
  const ids = [...presser.questions.map((q) => q.id), ...(state.recentQuestionIds ?? [])];
  return ids.slice(0, 16);
}
