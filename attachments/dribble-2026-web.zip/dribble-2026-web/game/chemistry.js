                                                 
import { clamp } from "./rng.js";
import { effectiveMpg, isOut } from "./college.js";

let cacheKey = "";
let cache = new Map                    ();
let rosters = new Map                  ();

export function bustChemCache() {
  cacheKey = "";
  cache = new Map();
  rosters = new Map();
}

function ensureIndex(state           ) {
  const k = `${state.season}:${state.week}:${state.phase}:${state.players.length}`;
  if (k === cacheKey && rosters.size) return;
  cacheKey = k;
  cache = new Map();
  rosters = new Map();
  for (const p of state.players) {
    const a = rosters.get(p.teamId);
    if (a) a.push(p);
    else rosters.set(p.teamId, [p]);
  }
}

export function teamRoster(state           , teamId        )           {
  ensureIndex(state);
  return rosters.get(teamId) ?? [];
}

                             
                
                                                                
                
                     
                 
                
                       
                     
               
 

function rotation(players          ) {
  return players
    .filter((p) => !isOut(p) && effectiveMpg(p) > 0)
    .slice()
    .sort((a, b) => effectiveMpg(b) - effectiveMpg(a) || b.ovr - a.ovr)
    .slice(0, 8);
}

export function lockerVoice(players          )                {
  const pool = players.filter((p) => p.year >= 3);
  if (!pool.length) return players.slice().sort((a, b) => b.skills.iq * b.mpg - a.skills.iq * a.mpg)[0] ?? null;
  return pool.slice().sort((a, b) => b.year * b.skills.iq * (8 + b.mpg) - a.year * a.skills.iq * (8 + a.mpg))[0] ?? null;
}

function rolesScore(rot          ) {
  const total = rot.reduce((n, p) => n + p.mpg, 0);
  let s = 78 - Math.abs(total - 200) / 3.2;
  const starters = rot.slice(0, 5);
  const bench = rot.slice(5);
  for (const p of starters) {
    if (p.mpg > 36) s -= (p.mpg - 36) * 1.6;
    else if (p.mpg < 22) s -= (22 - p.mpg) * 0.9;
  }
  for (const p of bench) {
    if (p.mpg > 22) s -= (p.mpg - 22) * 1.1;
    if (p.mpg < 8) s -= 3;
  }
  const byPos                         = {};
  for (const p of starters) byPos[p.pos] = (byPos[p.pos] ?? 0) + 1;
  for (const n of Object.values(byPos)) if (n >= 3) s -= 8;
  const hog = rot[0];
  if (hog && hog.mpg >= 38 && (rot[1]?.mpg ?? 0) < 16) s -= 10;
  return clamp(Math.round(s), 18, 96);
}

function continuityScore(rot          , week        ) {
  const mpg = rot.reduce((n, p) => n + Math.max(1, p.mpg), 0);
  const ret = rot.filter((p) => p.year >= 2).reduce((n, p) => n + p.mpg, 0);
  const fresh = rot.filter((p) => p.year === 1).reduce((n, p) => n + p.mpg, 0);
  const seniors = rot.filter((p) => p.year >= 4).reduce((n, p) => n + p.mpg, 0);
  let s = 38 + (ret / mpg) * 52;
  const freshShare = fresh / mpg;
  if (freshShare > 0.42) s -= 16;
  else if (freshShare > 0.32) s -= 8;
  if (week > 0 && week < 5) s -= freshShare * 14;
  if (week >= 10) s += Math.min(6, week - 9);
  if (seniors / mpg < 0.08) s -= 6;
  if (seniors / mpg > 0.55) s -= 4;
  return clamp(Math.round(s), 18, 96);
}

function lockerScore(rot          , voice               ) {
  const mpg = rot.reduce((n, p) => n + Math.max(1, p.mpg), 0);
  const weighted = rot.reduce((n, p) => n + p.morale * p.mpg, 0) / mpg;
  let s = weighted;
  const star = rot[0];
  if (star && star.morale < 52) s -= 14;
  else if (star && star.morale < 62) s -= 6;
  if (voice && voice.morale < 50) s -= 12;
  const mean = rot.reduce((n, p) => n + p.morale, 0) / rot.length;
  const spread = Math.sqrt(rot.reduce((n, p) => n + (p.morale - mean) ** 2, 0) / rot.length);
  if (spread > 18) s -= 8;
  return clamp(Math.round(s), 18, 96);
}

function trustScore(rot          , lead        ) {
  const iq = rot.reduce((n, p) => n + p.skills.iq, 0) / rot.length;
  const pos = new Set(rot.slice(0, 5).map((p) => p.pos)).size;
  let s = iq * 0.72 + (pos / 5) * 18 + (lead - 50) * 0.22;
  const top = rot.slice(0, 5);
  let pair = 0;
  let n = 0;
  for (let i = 0; i < top.length; i++) {
    for (let j = i + 1; j < top.length; j++) {
      const a = top[i] ;
      const b = top[j] ;
      pair += (a.skills.iq + b.skills.iq) / 2 - Math.abs(a.morale - b.morale) / 5;
      n++;
    }
  }
  if (n) s = s * 0.7 + (pair / n) * 0.3;
  return clamp(Math.round(s), 18, 96);
}

export function chemLabel(score        )                      {
  if (score >= 80) return "Connected";
  if (score >= 68) return "Tight";
  if (score >= 55) return "Working";
  if (score >= 42) return "Frayed";
  return "Toxic";
}

export function teamChemistry(state           , teamId        )             {
  ensureIndex(state);
  const hit = cache.get(teamId);
  if (hit) return hit;
  const players = rosters.get(teamId) ?? [];
  const rot = rotation(players);
  if (!rot.length) {
    return { score: 55, label: "Working", roles: 55, continuity: 55, locker: 55, trust: 55, voice: null, hog: null, note: "No rotation yet." };
  }
  const voice = lockerVoice(players);
  const roles = rolesScore(rot);
  const continuity = continuityScore(rot, state.week);
  const locker = lockerScore(rot, voice);
  const trust = trustScore(rot, state.playerTeamId === teamId ? (state.coachSkills?.leadership ?? 50) : 50);
  const score = clamp(Math.round(roles * 0.28 + continuity * 0.22 + locker * 0.28 + trust * 0.22), 18, 96);
  const hog = rot[0] && rot[0].mpg >= 36 ? rot[0] : null;
  const note = diagnose(roles, continuity, locker, trust, rot, voice, hog, state.week);
  const report = { score, label: chemLabel(score), roles, continuity, locker, trust, voice, hog, note };
  cache.set(teamId, report);
  return report;
}

function diagnose(
  roles        ,
  continuity        ,
  locker        ,
  trust        ,
  rot          ,
  voice               ,
  hog               ,
  week        ,
)         {
  const pillars                     = [
    [roles, "roles"],
    [locker, "locker"],
    [continuity, "continuity"],
    [trust, "trust"],
  ];
  const weakest = pillars.sort((a, b) => a[0] - b[0])[0] ;
  if (hog) return `${hog.first} is eating the ball. The rest of the rotation is watching.`;
  if (voice && voice.morale < 50) return `${voice.first} is the voice in that locker room, and he is not buying in.`;
  if (weakest[1] === "roles") return "Minutes are a mess. Starters need 28, the bench needs a job.";
  if (weakest[1] === "continuity") {
    return week < 6
      ? "Too many new faces in the first five. The extra pass is late."
      : "The rotation still does not know who takes the last shot.";
  }
  if (weakest[1] === "locker" && locker < 58) return "The locker room is split. Check in with the guys who sit.";
  if (trust < 58) return "IQ is not traveling. Motion dies when the second pass is late.";
  if (roles >= 74 && locker >= 74) return "Ball is moving. They know who they are.";
  return "They're working. Keep the minutes honest and the seniors loud.";
}

export function chemistryEdge(state           , homeId        , awayId        ) {
  return (teamChemistry(state, homeId).score - teamChemistry(state, awayId).score) / 28;
}

export function applyChemistryWeek(state           )           {
  const you = state.playerTeamId;
  const c = teamChemistry(state, you);
  return state.players.map((p) => {
    if (p.teamId !== you) return p;
    let m = p.morale;
    if (c.score >= 78) m += 1;
    else if (c.score <= 42) m -= p.mpg < 12 ? 2 : 1;
    else if (c.score <= 52) m -= p.mpg < 14 ? 1 : 0;
    if (p.year >= 3 && p.mpg < 14) m -= 1;
    if (p.year === 1 && p.mpg >= 18 && c.roles >= 60) m += 1;
    if (c.hog && p.id !== c.hog.id && p.mpg < 16) m -= 1;
    return { ...p, morale: clamp(m, 18, 99) };
  });
}