                                                                             
import { availableRoster, effectiveMpg } from "./college.js";
import { teamChemistry } from "./chemistry.js";
import { simBias } from "./league.js";
import { clamp, gaussian,          } from "./rng.js";

                             
                    
                    
               
                  
                   
                   
                           
                           
 

export function blankLine(p        )              {
  return {
    id: p.id,
    name: `${p.first} ${p.last}`,
    pos: p.pos,
    min: 0,
    pts: 0,
    reb: 0,
    ast: 0,
    fgm: 0,
    fga: 0,
    tpm: 0,
    tpa: 0,
    ftm: 0,
    fta: 0,
    to: 0,
  };
}

export function rotationOf(state           , teamId        )           {
  const real = availableRoster(state, teamId)
    .sort((a, b) => effectiveMpg(b) - effectiveMpg(a) || b.ovr - a.ovr)
    .slice(0, 10);
  if (real.length >= 5) return real;
  const pos                  = ["PG", "SG", "SF", "PF", "C"];
  const fillers           = Array.from({ length: 8 - real.length }, (_, i) => ({
    id: `wo-${teamId}-${i}`,
    first: "Walk",
    last: `On${i + 1}`,
    pos: pos[i % 5] ,
    year: 2,
    ovr: 60,
    potential: 60,
    morale: 58,
    teamId,
    mpg: 18,
    skills: { shoot: 58, finish: 60, defense: 58, iq: 58 },
    seasonMinutes: 0,
    seasonGames: 0,
    careerMinutes: 0,
    careerGames: 0,
  }));
  return [...real, ...fillers].slice(0, 10);
}

function sk(p        , key                        )         {
  return (p.skills?.[key] ?? p.ovr) / 100;
}

function usageW(p        )         {
  const usg = p.usage ?? p.mpg * 2.15;
  return Math.max(0.4, p.mpg) * (0.55 + usg / 50) * (0.7 + sk(p, "shoot") * 0.4 + sk(p, "finish") * 0.45);
}

function pickWeighted(rng     , players          , weight                       )         {
  const w = players.map(weight);
  let t = rng() * Math.max(0.001, w.reduce((s, n) => s + n, 0));
  for (let i = 0; i < players.length; i++) {
    t -= w[i] ;
    if (t <= 0) return players[i] ;
  }
  return players[0] ;
}

export function onCourtFive(rng     , roster          , target          , played          )           {
  if (roster.length <= 5) return roster.slice();
  const picked           = [];
  const used = new Set        ();
  for (let k = 0; k < 5; k++) {
    const weights = roster.map((p, i) => {
      if (used.has(i)) return 0;
      const left = Math.max(0.2, (target[i] ?? 12) - (played[i] ?? 0));
      return left * left * (p.mpg + 3);
    });
    const sum = weights.reduce((s, n) => s + n, 0);
    if (sum <= 0) break;
    let t = rng() * sum;
    let idx = 0;
    for (let i = 0; i < weights.length; i++) {
      t -= weights[i] ;
      if (t <= 0) {
        idx = i;
        break;
      }
    }
    used.add(idx);
    picked.push(roster[idx] );
  }
  return picked;
}

function targetMinutes(roster          , total        )           {
  const raw = roster.map((p, i) => {
    const starter = i < 5 ? 1.18 : 0.72;
    return Math.max(i < 8 ? 4 : 0, effectiveMpg(p) * starter);
  });
  const sum = raw.reduce((s, n) => s + n, 0) || 1;
  let mins = raw.map((n) => (n / sum) * total);
  mins = mins.map((m, i) => (i < 8 ? clamp(m, i < 5 ? 18 : 6, 38) : clamp(m, 0, 16)));
  let drift = total - mins.reduce((s, n) => s + n, 0);
  let guard = 0;
  while (Math.abs(drift) > 0.05 && guard++ < 24) {
    const i = guard % mins.length;
    const next = clamp(mins[i]  + Math.sign(drift) * 0.5, 0, 38);
    drift -= next - mins[i] ;
    mins[i] = next;
  }
  return mins.map((m) => Math.round(m * 10) / 10);
}

function threeShare(p        , era                           )         {
  const modern = era == null || era >= 2010;
  const old = era != null && era < 1987;
  if (old) return p.pos === "SG" || p.pos === "SF" ? 0.06 : 0.01;
  const byPos = { PG: 0.38, SG: 0.5, SF: 0.36, PF: 0.2, C: 0.06 }[p.pos];
  const shoot = sk(p, "shoot");
  const base = (modern ? 1 : 0.7) * byPos * (0.45 + shoot);
  return clamp(base, 0.04, 0.62);
}

function findLine(lines               , id        )                          {
  return lines.find((x) => x.id === id);
}

export function credit(line                         , patch                      ) {
  if (!line) return;
  for (const [k, v] of Object.entries(patch)) {
    if (typeof v !== "number") continue;
    (line                                     )[k] = ((line                                     )[k] ?? 0) + v;
  }
}

function teamDef(on          )         {
  if (!on.length) return 0.6;
  return on.reduce((s, p) => s + sk(p, "defense"), 0) / on.length;
}

function teamIq(on          )         {
  if (!on.length) return 0.6;
  return on.reduce((s, p) => s + sk(p, "iq"), 0) / on.length;
}

function boxOf(lines               , extraOrb        )          {
  const fga = lines.reduce((n, p) => n + p.fga, 0);
  const to = lines.reduce((n, p) => n + (p.to ?? 0), 0);
  const fta = lines.reduce((n, p) => n + (p.fta ?? 0), 0);
  const poss = Math.max(40, Math.round(fga - extraOrb + to + 0.475 * fta));
  return { poss, fga, orb: extraOrb, to, fta };
}

function capTeam(lines               , lo        , hi        ) {
  const order = [...lines].sort((a, b) => b.pts - a.pts || b.fga - a.fga);
  const total = () => lines.reduce((s, p) => s + p.pts, 0);
  let guard = 0;
  while (total() > hi && guard++ < 80) {
    const p = order[guard % order.length] ;
    if ((p.ftm ?? 0) > 0) {
      p.ftm = (p.ftm ?? 0) - 1;
      p.fta = Math.max((p.fta ?? 1) - 1, p.ftm ?? 0);
      p.pts -= 1;
    } else if ((p.tpm ?? 0) > 0) {
      p.tpm = (p.tpm ?? 0) - 1;
      p.fgm -= 1;
      p.pts -= 3;
    } else if (p.fgm > 0) {
      p.fgm -= 1;
      p.pts -= 2;
    }
  }
  while (total() < lo && guard++ < 160) {
    const p = order[0] ;
    if (!p) break;
    p.ftm = (p.ftm ?? 0) + 1;
    p.fta = (p.fta ?? 0) + 1;
    p.pts += 1;
  }
}

function finishLines(lines               , minutes        )                {
  const live = lines.filter((p) => p.min > 0.4 || p.pts > 0 || p.fga > 0);
  const sum = live.reduce((n, p) => n + p.min, 0) || 1;
  const scaled = live.map((p) => ({ ...p, min: clamp(Math.round((p.min / sum) * minutes * 5), 1, minutes - 2) }));
  let drift = minutes * 5 - scaled.reduce((n, p) => n + p.min, 0);
  let i = 0;
  while (drift !== 0 && scaled.length && i < 40) {
    const row = scaled[i % scaled.length] ;
    if (drift > 0 && row.min < minutes - 2) {
      row.min += 1;
      drift -= 1;
    } else if (drift < 0 && row.min > 1) {
      row.min -= 1;
      drift += 1;
    }
    i++;
  }
  return scaled.sort((a, b) => b.pts - a.pts || b.min - a.min);
}

export function simContest(
  state           ,
  homeId        ,
  awayId        ,
  rng     ,
  opts                                                                       = {},
)             {
  const homeR = rotationOf(state, homeId);
  const awayR = rotationOf(state, awayId);
  const era = state.eraDecade;
  const old = era != null && era < 1980;
  const pace = clamp((old ? 71 : 67.8) + gaussian(rng) * 2.1, old ? 64 : 62, old ? 78 : 74);
  let n = Math.round(pace);
  const minutes0 = 40;
  const homeT = targetMinutes(homeR, minutes0 * 5);
  const awayT = targetMinutes(awayR, minutes0 * 5);
  const homePlayed = homeR.map(() => 0);
  const awayPlayed = awayR.map(() => 0);
  const homeLines = homeR.map(blankLine);
  const awayLines = awayR.map(blankLine);
  let homeOrb = 0;
  let awayOrb = 0;
  const homeChem = teamChemistry(state, homeId).score;
  const awayChem = teamChemistry(state, awayId).score;
  const homeCourt = opts.site === "neutral" ? 0 : 0.018;
  let youH = 0;
  let youA = 0;
  if (opts.youHome === true) {
    youH += ((opts.youOff ?? 48) - 50) * 0.0011 + simBias(state);
    youA -= ((opts.youDef ?? 48) - 50) * 0.001;
  } else if (opts.youHome === false) {
    youA += ((opts.youOff ?? 48) - 50) * 0.0011 + simBias(state);
    youH -= ((opts.youDef ?? 48) - 50) * 0.001;
  }

  const tickMin = (side                 , five          , dt        ) => {
    const roster = side === "home" ? homeR : awayR;
    const played = side === "home" ? homePlayed : awayPlayed;
    const lines = side === "home" ? homeLines : awayLines;
    for (const p of five) {
      const i = roster.findIndex((x) => x.id === p.id);
      if (i < 0) continue;
      played[i] = (played[i] ?? 0) + dt;
      const line = lines[i];
      if (line) line.min += dt;
    }
  };

  const possOnce = (offHome         , depth = 0) => {
    const offR = offHome ? homeR : awayR;
    const defR = offHome ? awayR : homeR;
    const offP = offHome ? homePlayed : awayPlayed;
    const defP = offHome ? awayPlayed : homePlayed;
    const offT = offHome ? homeT : awayT;
    const defT = offHome ? awayT : homeT;
    const offL = offHome ? homeLines : awayLines;
    const defL = offHome ? awayLines : homeLines;
    const on = onCourtFive(rng, offR, offT, offP);
    const defOn = onCourtFive(rng, defR, defT, defP);
    if (!on.length) return;
    const dt = 40 / Math.max(60, n);
    tickMin("home", offHome ? on : defOn, dt);
    tickMin("away", offHome ? defOn : on, dt);

    const def = teamDef(defOn);
    const iq = teamIq(on);
    const chem = ((offHome ? homeChem : awayChem) - 60) / 400;
    const hc = offHome ? homeCourt : -homeCourt * 0.4;
    const you = offHome ? youH : youA;
    const toRate = clamp(0.16 - (iq - 0.6) * 0.16 + (def - 0.6) * 0.1 - chem + (old ? 0.02 : 0), 0.1, 0.22);
    const shooter = pickWeighted(rng, on, (p) => usageW(p));
    const sLine = findLine(offL, shooter.id);
    const mates = on.filter((p) => p.id !== shooter.id);
    const pass = () => {
      if (!mates.length) return;
      if (rng() > 0.55 + iq * 0.25) return;
      const passer = pickWeighted(rng, mates, (p) => sk(p, "iq") * (p.pos === "PG" ? 1.8 : 1) * p.mpg);
      credit(findLine(offL, passer.id), { ast: 1 });
    };
    const putback = () => {
      if (depth >= 2) return;
      if (offHome) homeOrb++;
      else awayOrb++;
      const rebounder = pickWeighted(rng, on, (p) => (p.pos === "C" ? 3.3 : p.pos === "PF" ? 2.4 : 1) * (0.55 + sk(p, "finish")));
      credit(findLine(offL, rebounder.id), { reb: 1 });
      possOnce(offHome, depth + 1);
    };
    const defBoard = () => {
      if (!defOn.length) return;
      const rebounder = pickWeighted(rng, defOn, (p) => (p.pos === "C" ? 3.3 : p.pos === "PF" ? 2.4 : 1) * (0.55 + sk(p, "defense")));
      credit(findLine(defL, rebounder.id), { reb: 1 });
    };

    if (rng() < toRate) {
      credit(sLine, { to: 1 });
      return;
    }

    const ftr = clamp(0.22 + sk(shooter, "finish") * 0.16 - def * 0.08, 0.12, 0.42);
    if (rng() < ftr * 0.55) {
      const attempts = rng() < 0.12 ? 3 : 2;
      const ft = clamp(0.68 + (sk(shooter, "shoot") - 0.6) * 0.45 + you * 4, 0.52, 0.9);
      credit(sLine, { fta: attempts });
      let made = 0;
      for (let i = 0; i < attempts; i++) if (rng() < ft) made++;
      credit(sLine, { ftm: made, pts: made });
      return;
    }

    const want3 = rng() < threeShare(shooter, era);
    if (want3) {
      const make3 = clamp(
        0.32 + (sk(shooter, "shoot") - 0.6) * 0.32 - (def - 0.6) * 0.16 + hc + you + chem * 0.4 + gaussian(rng) * 0.012,
        0.22,
        0.44,
      );
      credit(sLine, { fga: 1, tpa: 1 });
      if (rng() < make3) {
        credit(sLine, { fgm: 1, tpm: 1, pts: 3 });
        pass();
      } else if (rng() < clamp(0.26 + (sk(on.find((p) => p.pos === "C" || p.pos === "PF") ?? shooter, "finish") - 0.55) * 0.2 - def * 0.08, 0.16, 0.36)) {
        putback();
      } else {
        defBoard();
      }
      return;
    }

    const make2 = clamp(
      0.47 + (sk(shooter, "finish") - 0.6) * 0.34 - (def - 0.6) * 0.2 + hc + you + chem * 0.5 + gaussian(rng) * 0.01,
      0.36,
      0.62,
    );
    credit(sLine, { fga: 1 });
    if (rng() < make2) {
      credit(sLine, { fgm: 1, pts: 2 });
      if (rng() < 0.08 + sk(shooter, "finish") * 0.08) {
        const ft = clamp(0.68 + (sk(shooter, "shoot") - 0.6) * 0.4, 0.52, 0.9);
        credit(sLine, { fta: 1 });
        if (rng() < ft) credit(sLine, { ftm: 1, pts: 1 });
      }
      pass();
    } else if (rng() < clamp(0.28 + (sk(on.find((p) => p.pos === "C" || p.pos === "PF") ?? shooter, "finish") - 0.55) * 0.18 - def * 0.07, 0.17, 0.38)) {
      putback();
    } else {
      defBoard();
    }
  };

  let extra = 0;
  const runHalf = (count        ) => {
    for (let i = 0; i < count; i++) {
      possOnce(true);
      possOnce(false);
    }
  };
  runHalf(Math.round(n / 2));
  runHalf(n - Math.round(n / 2));
  const score = (lines               ) => lines.reduce((s, p) => s + p.pts, 0);
  let hs = score(homeLines);
  let as = score(awayLines);
  let minutes = 40;
  while (hs === as && extra < 3) {
    extra++;
    minutes += 5;
    n += 8;
    runHalf(4);
    hs = score(homeLines);
    as = score(awayLines);
  }
  if (hs === as) {
    if (rng() > 0.5) {
      const star = homeLines.slice().sort((a, b) => b.fga - a.fga)[0];
      if (star) credit(star, { ftm: 1, fta: 1, pts: 1 });
      hs += 1;
    } else {
      const star = awayLines.slice().sort((a, b) => b.fga - a.fga)[0];
      if (star) credit(star, { ftm: 1, fta: 1, pts: 1 });
      as += 1;
    }
  }
  capTeam(homeLines, 52, 102);
  capTeam(awayLines, 52, 102);
  hs = score(homeLines);
  as = score(awayLines);
  if (hs === as) {
    const star = homeLines.slice().sort((a, b) => b.fga - a.fga)[0];
    if (star) credit(star, { ftm: 1, fta: 1, pts: 1 });
  }

  const homeDone = finishLines(homeLines, minutes);
  const awayDone = finishLines(awayLines, minutes);
  return {
    homeScore: score(homeDone),
    awayScore: score(awayDone),
    poss: n,
    minutes,
    homeBox: boxOf(homeDone, homeOrb),
    awayBox: boxOf(awayDone, awayOrb),
    homeLines: homeDone,
    awayLines: awayDone,
  };
}

export function scaleLiveMinutes(lines               , minutes        )                {
  return finishLines(lines, minutes);
}
