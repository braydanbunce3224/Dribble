                                                                                   
import { clamp, gaussian,          } from "./rng.js";

export function identityName(d                       ) {
  if (!d) return "Coach Stone";
  return `${d.first ?? ""} ${d.last ?? ""}`.trim() || "Coach Stone";
}

function oneBox(poss        , rng     )          {
  const p = clamp(Math.round(poss), 56, 88);
  const to = clamp(Math.round(p * (0.155 + rng() * 0.07)), 7, 22);
  const fta = clamp(Math.round(p * (0.26 + rng() * 0.18)), 6, 38);
  const orb = clamp(Math.round(p * (0.08 + rng() * 0.06)), 3, 16);
  const fga = clamp(Math.round(p - to - 0.475 * fta + orb), 38, 92);
  return { poss: p, fga, orb, to, fta };
}

/** Light box that is consistent with Poss ≈ FGA − OR + TO + 0.475×FTA. */
export function estimateGameBoxes(hs        , as        , rng     )                                                    {
  const gamePoss = clamp((hs + as) / 2.12 + gaussian(rng) * 1.8, 58, 84);
  const drift = rng() < 0.55 ? 0 : rng() < 0.5 ? 1 : -1;
  return { home: oneBox(gamePoss + drift, rng), away: oneBox(gamePoss - drift, rng), minutes: 40 };
}

export function liveMinutes(half        ) {
  return half <= 2 ? 40 : 40 + (half - 2) * 5;
}

function boxFromLines(lines                           )                 {
  if (!lines?.length) return null;
  let fga = 0;
  let fta = 0;
  let to = 0;
  for (const p of lines) {
    fga += p.fga ?? 0;
    fta += p.fta ?? 0;
    to += p.to ?? 0;
  }
  if (fga < 20) return null;
  // Standard possession estimate. Offensive boards are not tracked per player
  // in the live path, so approximate them off missed shots.
  const orb = Math.round(fga * 0.1);
  const poss = Math.max(40, Math.round(fga - orb + to + 0.475 * fta));
  return { poss, fga, orb, to, fta };
}

export function boxFromLive(live          )                                                    {
  // The per-player lines are the authoritative record: they accumulate every
  // possession. live.log is capped at 48 entries for display, so replaying it
  // reconstructed a ~23-possession game out of a ~140-possession one and
  // produced impossible efficiency (3.3 PPP) on every played game — which then
  // fed the stored result box, team analytics and the efficiency ratings.
  const fromLines =
    live.homeLines && live.awayLines
      ? { home: boxFromLines(live.homeLines), away: boxFromLines(live.awayLines) }
      : { home: null, away: null };
  if (fromLines.home && fromLines.away) {
    return { home: fromLines.home, away: fromLines.away, minutes: liveMinutes(live.half) };
  }

  const empty = ()          => ({ poss: 0, fga: 0, orb: 0, to: 0, fta: 0 });
  const home = empty();
  const away = empty();
  for (const e of live.log) {
    if (!e.kind || e.kind === "period" || !e.poss) continue;
    const b = e.poss === "home" ? home : away;
    b.poss++;
    if (e.kind === "two" || e.kind === "three") {
      b.fga++;
      if (e.kind === "two" && e.pts === 3) b.fta += 1;
    } else if (e.kind === "ft") {
      b.fta += 2;
    } else if (e.kind === "to") {
      b.to++;
    }
  }
  if (home.poss < 20 || away.poss < 20) {
    return estimateGameBoxes(live.homeScore, live.awayScore, () => 0.37);
  }
  return { home, away, minutes: liveMinutes(live.half) };
}

export function gamePossessions(home          , away          , hs = 70, as = 70) {
  if (home && away) return (home.poss + away.poss) / 2;
  if (home) return home.poss;
  if (away) return away.poss;
  return clamp((hs + as) / 2.12, 58, 84);
}

/** Shared-pace score. Both teams live on the same possession count. */
export function projectScore(
  rng     ,
  homeOvr        ,
  awayOvr        ,
  opts   
                
                        
                      
                      
                    
                    
                      
    = {},
)                                                         {
  const old = opts.era != null && opts.era < 1980;
  const poss = clamp((old ? 71.2 : 68.4) + gaussian(rng) * 2.2, old ? 64 : 63, old ? 79 : 75);
  const chemH = ((opts.homeChem ?? 60) - 60) * 0.05;
  const chemA = ((opts.awayChem ?? 60) - 60) * 0.05;
  let youH = 0;
  let youA = 0;
  if (opts.youHome === true) {
    youH += ((opts.youOff ?? 48) - 50) * 0.06;
    youA -= ((opts.youDef ?? 48) - 50) * 0.05;
  } else if (opts.youHome === false) {
    youA += ((opts.youOff ?? 48) - 50) * 0.06;
    youH -= ((opts.youDef ?? 48) - 50) * 0.05;
  }
  const avg = 107;
  const offH = avg + (homeOvr - 72) * 0.58 + chemH + youH;
  const defH = avg - (homeOvr - 72) * 0.50;
  const offA = avg + (awayOvr - 72) * 0.58 + chemA + youA;
  const defA = avg - (awayOvr - 72) * 0.50;
  const homeCourt = opts.site === "neutral" ? 1 : 1.014;
  let hPpp = ((offH * defA) / (avg * 100)) * homeCourt;
  let aPpp = (offA * defH) / (avg * 100) / (opts.site === "neutral" ? 1 : 1.01);
  hPpp *= 1 + gaussian(rng) * 0.065;
  aPpp *= 1 + gaussian(rng) * 0.065;
  hPpp = clamp(hPpp, 0.82, 1.22);
  aPpp = clamp(aPpp, 0.82, 1.22);
  let hs = Math.round(poss * hPpp);
  let as = Math.round(poss * aPpp);
  const lo = old ? 55 : 58;
  const hi = old ? 99 : 92;
  hs = clamp(hs, lo, hi);
  as = clamp(as, lo, hi);
  if (hs === as) {
    if (rng() > 0.5) hs += 1;
    else as += 1;
  }
  if (Math.abs(hs - as) >= 14 && rng() < 0.1) {
    const leader = hs > as ? "h" : "a";
    const pull = 5 + Math.round(rng() * 4);
    if (leader === "h") {
      hs = Math.max(as + 1, hs - pull);
      as = Math.min(hs - 1, as + Math.round(pull * 0.45));
    } else {
      as = Math.max(hs + 1, as - pull);
      hs = Math.min(as - 1, hs + Math.round(pull * 0.45));
    }
  }
  return { homeScore: hs, awayScore: as, poss: Math.round(poss) };
}