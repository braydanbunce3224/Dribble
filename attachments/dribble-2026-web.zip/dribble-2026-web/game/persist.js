                                                                                
import { SAVE_VERSION } from "./types.js";
import { hydrateState } from "./develop.js";
import { identityName } from "./engine-util.js";
import { restorePack } from "./names.js";
                                        

const KEY = "dribble-2026.save.v1";
const INDEX_KEY = "dribble-2026.slots.index";
const TUTORIAL_KEY = "dribble-2026.tutorial";
const MAX_MANUAL = 8;

                           
             
               
                    
                 
                 
               
                 
                
                 
 

let cached                            ;

function storage()                 {
  if (cached !== undefined) return cached;
  try {
    const s = window.localStorage;
    s.setItem("__d26", "1");
    s.removeItem("__d26");
    cached = s;
    return s;
  } catch {
    try {
      cached = window.sessionStorage;
      return cached;
    } catch {
      cached = null;
      return null;
    }
  }
}

function slotKey(id        ) {
  return `dribble-2026.slot.${id}`;
}

function readIndex()             {
  try {
    const raw = storage()?.getItem(INDEX_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw)              ;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeIndex(list            ) {
  storage()?.setItem(INDEX_KEY, JSON.stringify(list));
}

function metaOf(state           , id        , name        , auto         )           {
  const t = state.teams[state.playerTeamId];
  return {
    id,
    name,
    updatedAt: Date.now(),
    teamId: state.playerTeamId,
    season: state.season,
    wins: t?.wins ?? 0,
    losses: t?.losses ?? 0,
    coach: identityName(state.identity),
    auto,
  };
}

function slimInterest(interest                                    , you        )                         {
  const src = interest && typeof interest === "object" ? interest : {};
  const youV = src[you];
  const top = Object.entries(src).sort((a, b) => b[1] - a[1]).slice(0, 12);
  const next                         = {};
  for (const [k, v] of top) next[k] = v;
  if (youV != null) next[you] = youV;
  return next;
}

function slimPlayer(p        , you        )                                                        {
  if (p.teamId === you) return p;
  return {
    id: p.id,
    first: p.first,
    last: p.last,
    pos: p.pos,
    year: p.year,
    ovr: p.ovr,
    potential: p.potential,
    morale: p.morale,
    teamId: p.teamId,
    mpg: p.mpg,
    seasonMinutes: p.seasonMinutes ?? 0,
    seasonGames: p.seasonGames ?? 0,
    careerMinutes: p.careerMinutes ?? 0,
    careerGames: p.careerGames ?? 0,
    usage: p.usage,
    redshirt: p.redshirt || undefined,
    usedRedshirt: p.usedRedshirt || undefined,
    injury: p.injury,
    country: p.country,
    freak: p.freak,
    freakTag: p.freakTag,
    height: p.height,
    portalFrom: p.portalFrom,
    portalSeason: p.portalSeason,
  }          ;
}

function slimRecruit(r         , you        )          {
  return {
    ...r,
    interest: slimInterest(r.interest, you),
    offers: (r.offers ?? []).slice(0, 8),
    visits: (r.visits ?? []).slice(0, 6),
  };
}

function slimTransfer(t          , you        )           {
  return {
    ...t,
    interest: slimInterest(t.interest, you),
    offers: (t.offers ?? []).slice(0, 8),
    visits: (t.visits ?? []).slice(0, 6),
  };
}

function slimResult(r            , you        )             {
  const yours = r.homeId === you || r.awayId === you;
  if (yours) return r;
  return {
    id: r.id,
    slotId: r.slotId,
    homeId: r.homeId,
    awayId: r.awayId,
    homeScore: r.homeScore,
    awayScore: r.awayScore,
    week: r.week,
  };
}

export function slimState(state           )            {
  const you = state.playerTeamId;
  const live = state.liveGame
    ? { ...state.liveGame, log: (state.liveGame.log ?? []).slice(-48) }
    : null;
  const teams = Object.fromEntries(
    Object.entries(state.teams).map(([id, t]) => [id, id === you ? t : { ...t, series: undefined }]),
  );
  return {
    ...state,
    version: SAVE_VERSION,
    teams,
    players: state.players.map((p) => slimPlayer(p, you)          ),
    recruits: state.recruits.map((r) => slimRecruit(r, you)),
    results: state.results.map((r) => slimResult(r, you)),
    portal: state.portal
      ? { ...state.portal, transfers: state.portal.transfers.map((t) => slimTransfer(t, you)) }
      : state.portal,
    news: (state.news ?? []).slice(0, 24),
    mail: (state.mail ?? []).slice(0, 24),
    liveGame: live,
  };
}

function encode(state           )         {
  const slim = slimState(state);
  const you = slim.playerTeamId;
  return JSON.stringify({
    ...slim,
    results: slim.results.map((r) =>
      r.homeId === you || r.awayId === you
        ? r
        : [r.id, r.slotId, r.homeId, r.awayId, r.homeScore, r.awayScore, r.week],
    ),
    schedule: slim.schedule.map((g) =>
      g.homeId === you || g.awayId === you
        ? g
        : [g.id, g.week, g.homeId, g.awayId, g.site, g.kind, g.resultId ?? 0, g.declined ? 1 : 0],
    ),
  });
}

export function packedSize(state           ) {
  return encode(state).length;
}

function putSlot(id        , name        , state           , auto         ) {
  const s = storage();
  if (!s) throw new Error("Storage is blocked on this device.");
  const payload = encode(state);
  s.setItem(slotKey(id), payload);
  const next = [metaOf(state, id, name, auto), ...readIndex().filter((m) => m.id !== id)].sort(
    (a, b) => b.updatedAt - a.updatedAt,
  );
  writeIndex(next);
}

export function listSaves()             {
  return readIndex().sort((a, b) => Number(b.auto) - Number(a.auto) || b.updatedAt - a.updatedAt);
}

function hydrateSave(parsed           )            {
  if (!parsed || typeof parsed !== "object") throw new Error("Empty save.");
  const state = hydrateState({
    ...parsed,
    liveGame: parsed.liveGame ?? null,
    lastPresserWeek: parsed.lastPresserWeek ?? -9,
    recentQuestionIds: parsed.recentQuestionIds ?? [],
    namePack: parsed.namePack ?? null,
  });
  if (!state.playerTeamId) throw new Error("Save is missing a team.");
  if (state.namePack?.title) {
    restorePack({
      kind: "dribble-2026-names",
      version: 1,
      id: state.namePack.id,
      title: state.namePack.title,
      note: state.namePack.note,
      teams: state.namePack.teams,
      conferences: state.namePack.conferences,
    }            );
  }
  return state;
}

export function loadSave()                   {
  try {
    const s = storage();
    const raw = s?.getItem(slotKey("auto")) ?? s?.getItem(KEY) ?? s?.getItem("hoops-hero.save.v7");
    if (!raw) return null;
    let parsed         ;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (!parsed || typeof parsed !== "object") return null;
    return hydrateSave(parsed             );
  } catch (e) {
    console.error(e);
    return null;
  }
}

export function loadSlot(id        )                   {
  try {
    const raw = storage()?.getItem(slotKey(id)) ?? (id === "auto" ? storage()?.getItem(KEY) : null);
    if (!raw) return null;
    let parsed         ;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (!parsed || typeof parsed !== "object") return null;
    return hydrateSave(parsed             );
  } catch (e) {
    console.error(e);
    return null;
  }
}

export function writeSave(state           )          {
  try {
    const s = storage();
    if (!s) return false;
    const persist = (st           ) => {
      // The autosave slot is the source of truth. The legacy KEY is only read
      // as a fallback for pre-slot saves (see loadSave), so writing it too just
      // doubled every autosave's storage cost. Drop it once the slot is safely
      // written to reclaim that space.
      putSlot("auto", "Autosave", st, true);
      try {
        s.removeItem(KEY);
      } catch {
        /* ignore */
      }
    };
    try {
      persist(state);
      return true;
    } catch {
      try {
        s.removeItem(KEY);
        persist({
          ...state,
          news: (state.news ?? []).slice(0, 6),
          mail: (state.mail ?? []).slice(0, 8),
          liveGame: state.liveGame ? { ...state.liveGame, log: [] } : null,
        });
        return true;
      } catch (e) {
        console.error(e);
        return false;
      }
    }
  } catch (e) {
    console.error(e);
    return false;
  }
}

export function saveNamed(state           , name        )                                               {
  const label = name.trim() || `Season ${state.season}`;
  const manuals = readIndex().filter((m) => !m.auto);
  if (manuals.length >= MAX_MANUAL) {
    return { ok: false, error: `Cap is ${MAX_MANUAL} manual files. Delete one first.` };
  }
  try {
    const id = `m-${Date.now().toString(36)}`;
    putSlot(id, label, state, false);
    return { ok: true, id };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Couldn't write that file." };
  }
}

export function deleteSlot(id        ) {
  try {
    if (id === "auto") return;
    storage()?.removeItem(slotKey(id));
    writeIndex(readIndex().filter((m) => m.id !== id));
  } catch {
    /* */
  }
}

export function clearSave() {
  try {
    storage()?.removeItem(KEY);
    storage()?.removeItem(slotKey("auto"));
    writeIndex(readIndex().filter((m) => !m.auto && m.id !== "auto"));
  } catch {
    /* */
  }
}

export function tutorialDone()          {
  try {
    return storage()?.getItem(TUTORIAL_KEY) === "1";
  } catch {
    return false;
  }
}

export function setTutorialDone(done         ) {
  try {
    const s = storage();
    if (!s) return;
    if (done) s.setItem(TUTORIAL_KEY, "1");
    else s.removeItem(TUTORIAL_KEY);
  } catch {
    /* */
  }
}

export { MAX_MANUAL };
