                                                                       
import { clamp, hashString, mulberry32, pick } from "./rng.js";
import { bustChemCache } from "./chemistry.js";
import { TEAM_BY_ID } from "./teams.js";

function yours(state           ) {
  return state.players.filter((p) => p.teamId === state.playerTeamId && !p.redshirt);
}

function nm(p        ) {
  return `${p.first} ${p.last}`;
}

function autoPick(ev            ) {
  return ev.choices.find((c) => c.tone === "even")?.id ?? ev.choices[0]?.id ?? "even";
}

export function rollStory(state           )            {
  if (state.phase !== "regular") return state;
  if (state.pendingStory) return resolveStory(state, autoPick(state.pendingStory)).state;
  const rng = mulberry32(state.seed ^ (state.week * 7919) ^ (state.season * 104729) ^ 0x57);
  if (rng() > 0.22) return state;
  const rot = yours(state).slice().sort((a, b) => b.mpg - a.mpg || b.ovr - a.ovr);
  if (rot.length < 3) return state;
  const star = rot[0] ;
  const bench = rot[rot.length - 1] ;
  const voice = rot.find((p) => p.year >= 3) ?? rot[1] ;
  const frosh = rot.find((p) => p.year === 1) ?? rot[2] ;
  const school = TEAM_BY_ID[state.playerTeamId]?.name ?? "the program";
  const nilOn = state.nilCap > 0;

                                                                                     
  const kinds         = ["minutes", "clash", "flash", "voice", "homesick", "rumor"];
  if (nilOn) kinds.push("nil");
  const kind = pick(rng, kinds);
  const id = `st-${state.season}-${state.week}-${kind}`;

  let ev            ;
  if (kind === "minutes") {
    ev = {
      id,
      week: state.week,
      title: `${nm(star)} wants the ball`,
      body: `${nm(star)} is at ${star.mpg} a night. He thinks the offense should run through him. The next man up is listening.`,
      playerIds: [star.id],
      choices: [
        { id: "feed", label: `Feed him. Bump ${star.first} and live with the hog.`, tone: "hot" },
        { id: "even", label: "Hold the rotation. Minutes are earned on film.", tone: "even" },
        { id: "bench", label: "Sit him a half. The room needs to see it.", tone: "cool" },
      ],
    };
  } else if (kind === "clash") {
    ev = {
      id,
      week: state.week,
      title: `${star.first} and ${voice.first} in the hallway`,
      body: `Two voices, one gym. ${nm(star)} and ${nm(voice)} went at it after film. The rest of the locker room is picking a side.`,
      playerIds: [star.id, voice.id],
      choices: [
        { id: "star", label: `Back ${star.first}. He's the engine.`, tone: "hot" },
        { id: "even", label: "Close the door. They work it out.", tone: "even" },
        { id: "voice", label: `Back ${voice.first}. The room follows the senior.`, tone: "cool" },
      ],
    };
  } else if (kind === "flash") {
    ev = {
      id,
      week: state.week,
      title: `${nm(frosh)} on a heater`,
      body: `The freshman just stacked a week. Assistants want him in the closing group. ${nm(star)} has those minutes now.`,
      playerIds: [frosh.id, star.id],
      choices: [
        { id: "promote", label: `Close with ${frosh.first}. The future is now.`, tone: "hot" },
        { id: "even", label: "Spot minutes. Don't blow up a rotation midweek.", tone: "even" },
        { id: "hold", label: "Veterans close. The kid waits.", tone: "cool" },
      ],
    };
  } else if (kind === "nil") {
    ev = {
      id,
      week: state.week,
      title: `A booster dinner for ${star.first}`,
      body: `Someone with a checkbook wants ${nm(star)} at a downtown table. Compliance is already drafting the memo.`,
      playerIds: [star.id],
      choices: [
        { id: "go", label: "Take the dinner. The number goes up. Heat goes up.", tone: "hot" },
        { id: "even", label: "Staff only. Keep the book clean.", tone: "even" },
        { id: "pass", label: "Shut it down. Tell the booster no.", tone: "cool" },
      ],
    };
  } else if (kind === "voice") {
    ev = {
      id,
      week: state.week,
      title: `${nm(voice)} wants the floor`,
      body: `The senior asked for a closed-door. He thinks the staff has lost the room. ${school} is  listening.`,
      playerIds: [voice.id],
      choices: [
        { id: "listen", label: "Give him the floor. Change a call.", tone: "hot" },
        { id: "even", label: "Hear him. Don't change the board.", tone: "even" },
        { id: "shut", label: "This is still your gym.", tone: "cool" },
      ],
    };
  } else if (kind === "homesick") {
    ev = {
      id,
      week: state.week,
      title: `${nm(bench)} wants a ticket home`,
      body: `${nm(bench)} is averaging ${bench.mpg} minutes and looking at the portal window. A parent called the AD.`,
      playerIds: [bench.id],
      choices: [
        { id: "minutes", label: `Promise him a look. ${bench.mpg + 6} a night.`, tone: "hot" },
        { id: "even", label: "Honest talk. The rotation is the rotation.", tone: "even" },
        { id: "portal", label: "Bless the portal. Don't chain him to the bench.", tone: "cool" },
      ],
    };
  } else {
    ev = {
      id,
      week: state.week,
      title: `A rumor on ${nm(star)}`,
      body: `A national desk item has ${nm(star)} "exploring options." He hasn't said it. The group chat has.`,
      playerIds: [star.id],
      choices: [
        { id: "podium", label: "Put him at the podium. Kill it in public.", tone: "hot" },
        { id: "even", label: "Private meeting. No statement.", tone: "even" },
        { id: "ignore", label: "Ignore it. Noise is noise.", tone: "cool" },
      ],
    };
  }

  return { ...state, pendingStory: ev };
}

export function resolveStory(state           , choiceId        )                                           {
  const ev = state.pendingStory;
  if (!ev) return { state, feedback: { title: "Quiet", detail: "", parts: [] } };
  const choice = ev.choices.find((c) => c.id === choiceId) ?? ev.choices.find((c) => c.tone === "even") ?? ev.choices[0];
  if (!choice) return { state: { ...state, pendingStory: null }, feedback: { title: "Quiet", detail: "", parts: [] } };

  const ids = new Set(ev.playerIds);
  let players = state.players;
  let ad = 0;
  let fans = 0;
  let donor = 0;
  const hit = (id        , n        ) => {
    players = players.map((p) => (p.id === id ? { ...p, morale: clamp(p.morale + n, 20, 99) } : p));
  };
  const bumpMpg = (id        , n        ) => {
    players = players.map((p) => (p.id === id ? { ...p, mpg: clamp(p.mpg + n, 0, 38) } : p));
  };

  switch (choice.id) {
    case "feed":
      hit(ev.playerIds[0] , 8);
      bumpMpg(ev.playerIds[0] , 3);
      fans += 2;
      break;
    case "bench":
      hit(ev.playerIds[0] , -10);
      bumpMpg(ev.playerIds[0] , -4);
      ad += 2;
      break;
    case "star":
      hit(ev.playerIds[0] , 6);
      if (ev.playerIds[1]) hit(ev.playerIds[1], -6);
      break;
    case "voice":
      if (ev.playerIds[1]) hit(ev.playerIds[1], 6);
      hit(ev.playerIds[0] , -5);
      break;
    case "promote":
      hit(ev.playerIds[0] , 7);
      bumpMpg(ev.playerIds[0] , 4);
      if (ev.playerIds[1]) {
        hit(ev.playerIds[1], -4);
        bumpMpg(ev.playerIds[1], -2);
      }
      break;
    case "hold":
      hit(ev.playerIds[0] , -4);
      if (ev.playerIds[1]) hit(ev.playerIds[1], 3);
      break;
    case "go":
      hit(ev.playerIds[0] , 6);
      donor += 6;
      ad -= 4;
      break;
    case "pass":
      hit(ev.playerIds[0] , -3);
      ad += 3;
      donor -= 4;
      break;
    case "listen":
      hit(ev.playerIds[0] , 5);
      fans += 2;
      break;
    case "shut":
      hit(ev.playerIds[0] , -6);
      ad += 2;
      break;
    case "minutes":
      hit(ev.playerIds[0] , 6);
      bumpMpg(ev.playerIds[0] , 5);
      break;
    case "portal":
      hit(ev.playerIds[0] , 2);
      ad -= 2;
      break;
    case "podium":
      hit(ev.playerIds[0] , 4);
      fans += 3;
      break;
    case "ignore":
      hit(ev.playerIds[0] , -2);
      break;
    default:
      for (const id of ids) hit(id, 2);
      break;
  }

  bustChemCache();
  const school = TEAM_BY_ID[state.playerTeamId]?.name ?? "the office";
  return {
    state: {
      ...state,
      pendingStory: null,
      players,
      adHeat: clamp((state.adHeat ?? 55) + ad, 10, 99),
      fanMood: clamp((state.fanMood ?? 60) + fans, 10, 99),
      donorMood: clamp((state.donorMood ?? 58) + donor, 10, 99),
      news: [
        {
          id: `${ev.id}-out`,
          week: state.week,
          season: state.season,
          tone: (choice.tone === "hot" ? "good" : choice.tone === "cool" ? "bad" : "even")                           ,
          kicker: "Locker",
          headline: ev.title,
          dek: choice.label,
          byline: "Inside the program",
          outlet: school,
          grafs: [ev.body, `Staff decision: ${choice.label}`],
          text: choice.label,
        },
        ...state.news,
      ].slice(0, 60),
    },
    feedback: {
      title: choice.label,
      detail: ev.title,
      parts: [
        ...(ad ? [{ label: "AD", delta: ad }] : []),
        ...(fans ? [{ label: "Fans", delta: fans }] : []),
        ...(donor ? [{ label: "Donors", delta: donor }] : []),
      ],
    },
  };
}

void hashString;
