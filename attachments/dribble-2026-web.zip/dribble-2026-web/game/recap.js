                                                                                                        
import { TEAM_BY_ID } from "./teams.js";
import { clamp, hashString, mulberry32,          } from "./rng.js";

const KIND                                   = {
  conference: "League",
  noncon: "Non-conference",
  mte: "Classic",
  "conf-tourney": "League tournament",
  ncaa: "National",
  nit: "Invite",
  crown: "The Crown",
};

function nameOf(id        ) {
  return TEAM_BY_ID[id]?.name ?? id;
}

function mascotOf(id        ) {
  return TEAM_BY_ID[id]?.mascot ?? nameOf(id);
}

function siteLine(site      , kind                  ) {
  if (kind === "mte" || kind === "ncaa" || kind === "nit" || kind === "crown" || kind === "conf-tourney") return "neutral floor";
  if (site === "neutral") return "neutral floor";
  if (site === "home") return "at home";
  return "on the road";
}

function usable(rows                           , score        )                       {
  if (!rows?.length) return null;
  const pts = rows.reduce((n, p) => n + p.pts, 0);
  if (pts !== score) return null;
  return rows;
}

function rot(state           , teamId        ) {
  return state.players.filter((p) => p.teamId === teamId).sort((a, b) => b.mpg - a.mpg || b.ovr - a.ovr);
}

function split(total        , weights          , rng     )           {
  const sum = weights.reduce((n, w) => n + w, 0) || 1;
  const raw = weights.map((w) => (total * w) / sum);
  const out = raw.map((n) => Math.floor(n));
  let left = total - out.reduce((n, x) => n + x, 0);
  const order = raw.map((n, i) => ({ i, frac: n - Math.floor(n) + rng() * 0.02 })).sort((a, b) => b.frac - a.frac);
  for (const o of order) {
    if (left <= 0) break;
    out[o.i]  += 1;
    left--;
  }
  return out;
}

function boxPlayers(state           , teamId        , score        , fga        , minutes        , rng     )                {
  const use = rot(state, teamId).slice(0, 9);
  if (!use.length) return [];
  const minW = use.map((p, i) => Math.max(i < 8 ? 5 : 0, p.mpg * (i < 5 ? 1.15 : 0.75)));
  const mins = split(minutes * 5, minW, rng).map((m, i) => clamp(m, i < 5 ? 16 : 4, 38));
  const usg = use.map((p, i) => Math.max(2, mins[i]  * (0.35 + (p.usage ?? p.mpg * 2.15) / 90 + p.skills.shoot / 400 + p.skills.finish / 380)));
  const fgas = split(Math.max(fga, 48), usg, rng);
  const tpaShare = use.map((p) => {
    const byPos = { PG: 0.4, SG: 0.5, SF: 0.36, PF: 0.18, C: 0.05 }[p.pos];
    return clamp(byPos * (0.4 + p.skills.shoot / 140), 0.04, 0.62);
  });
  const tpas = fgas.map((n, i) => clamp(Math.round(n * tpaShare[i] ), 0, n));
  const tpPct = use.map((p) => clamp(0.29 + (p.skills.shoot - 60) * 0.0035 + rng() * 0.02, 0.2, 0.44));
  const twoPct = use.map((p) => clamp(0.44 + (p.skills.finish - 60) * 0.004 - rng() * 0.02, 0.34, 0.62));
  const ftPct = use.map((p) => clamp(0.69 + (p.skills.shoot - 60) * 0.004, 0.55, 0.88));
  const tpms = tpas.map((n, i) => clamp(Math.round(n * tpPct[i] ), 0, n));
  const twoA = fgas.map((n, i) => n - tpas[i] );
  const twoM = twoA.map((n, i) => clamp(Math.round(n * twoPct[i] ), 0, n));
  const fgm = twoM.map((n, i) => n + tpms[i] );
  let pts = fgm.map((_, i) => twoM[i]  * 2 + tpms[i]  * 3);
  const ftas = use.map((p, i) => clamp(Math.round(mins[i]  * (0.12 + p.skills.finish / 500) + rng() * 2), 0, 14));
  const ftms = ftas.map((n, i) => clamp(Math.round(n * ftPct[i] ), 0, n));
  pts = pts.map((n, i) => n + ftms[i] );
  let drift = score - pts.reduce((s, n) => s + n, 0);
  const order = use.map((_, i) => i).sort((a, b) => usg[b]  - usg[a] );
  for (const i of order) {
    if (drift === 0) break;
    if (drift > 0) {
      ftas[i]  += 1;
      ftms[i]  += 1;
      pts[i]  += 1;
      drift -= 1;
    } else if (pts[i]  > 0 && ftms[i]  > 0) {
      ftms[i]  -= 1;
      ftas[i] = Math.max(ftas[i] , ftms[i] );
      pts[i]  -= 1;
      drift += 1;
    }
  }
  if (drift !== 0) {
    const star = order[0] ;
    pts[star]  += drift;
    if (drift > 0) {
      ftms[star]  += drift;
      ftas[star]  += drift;
    }
  }
  const rebW = use.map((p, i) => Math.max(1, mins[i]  * (p.pos === "C" ? 0.32 : p.pos === "PF" ? 0.26 : p.pos === "SF" ? 0.16 : 0.1) * (0.8 + p.skills.defense / 280)));
  const rebs = split(clamp(Math.round(30 + rng() * 8), 24, 42), rebW, rng);
  const astW = use.map((p, i) => Math.max(0.5, mins[i]  * (p.pos === "PG" ? 0.26 : p.pos === "SG" ? 0.14 : 0.07) * (p.skills.iq / 70)));
  const madeFg = fgm.reduce((s, n) => s + n, 0);
  const asts = split(clamp(Math.round(madeFg * (0.48 + rng() * 0.1)), 7, 22), astW, rng);
  const toW = use.map((p, i) => Math.max(0.4, mins[i]  * (0.08 + (100 - p.skills.iq) / 400)));
  const tos = split(clamp(Math.round(11 + rng() * 6), 8, 20), toW, rng);
  return use.map((p, i) => ({
    id: p.id,
    name: `${p.first} ${p.last}`,
    pos: p.pos,
    min: mins[i] ,
    pts: Math.max(0, pts[i] ),
    reb: rebs[i] ,
    ast: asts[i] ,
    fgm: fgm[i] ,
    fga: Math.max(fgm[i] , fgas[i] ),
    tpm: tpms[i] ,
    tpa: Math.max(tpms[i] , tpas[i] ),
    ftm: ftms[i] ,
    fta: Math.max(ftms[i] , ftas[i] ),
    to: tos[i] ,
  })).sort((a, b) => b.pts - a.pts || b.min - a.min);
}

function biggestRun(log             )                                                {
  let best = 0;
  let bestSide                         = null;
  let cur = 0;
  let side                         = null;
  for (const e of log) {
    if (!e.pts || e.pts <= 0 || !e.poss) {
      continue;
    }
    if (e.poss === side) cur += e.pts;
    else {
      cur = e.pts;
      side = e.poss;
    }
    if (cur > best) {
      best = cur;
      bestSide = side;
    }
  }
  if (!bestSide || best < 6) return null;
  return { side: bestSide, pts: best };
}

function keyFromLog(log             , winnerHome         )                {
  const scoring = log.filter((e) => (e.pts ?? 0) > 0 && e.text);
  if (!scoring.length) return null;
  const late = [...scoring].reverse().find((e) => e.t.includes("H2") || e.t.includes("OT"));
  const hit = late ?? scoring[scoring.length - 1] ;
  const run = biggestRun(log);
  if (run && run.pts >= 8) {
    const who = run.side === "home" ? "the home side" : "the visitors";
    return `A ${run.pts}-0 run from ${who} flipped the floor. ${hit.text}`;
  }
  return hit.impact ? `${hit.t}: ${hit.impact}` : hit.text;
}

function marginTone(margin        , winner        , loser        , site        )                                     {
  if (margin <= 3) {
    return {
      headline: `${winner} survives ${loser}, one possession`,
      lede: `${winner} got out of ${site} with a one-possession game over ${loser}. Nobody left the gym sure it was over until the last whistle.`,
    };
  }
  if (margin <= 8) {
    return {
      headline: `${winner} holds off ${loser}`,
      lede: `${winner} had an answer every time ${loser} got close ${site}. The last five minutes were about stops, not style.`,
    };
  }
  if (margin <= 15) {
    return {
      headline: `${winner} pulls away from ${loser}`,
      lede: `${winner} broke it open ${site} and never gave ${loser} a clean look back in. The lead grew in bunches.`,
    };
  }
  return {
    headline: `${winner} walks through ${loser}`,
    lede: `${winner} was the better team ${site} from the first timeout. ${loser} spent the night chasing.`,
  };
}

export function buildRecap(
  state           ,
  slot                                                      ,
  result            ,
  rng     ,
  log              ,
  lines                                               ,
)            {
  const kind = slot?.kind ?? "noncon";
  const site = slot?.site ?? "home";
  const home = nameOf(result.homeId);
  const away = nameOf(result.awayId);
  const homeWin = result.homeScore > result.awayScore;
  const winnerId = homeWin ? result.homeId : result.awayId;
  const loserId = homeWin ? result.awayId : result.homeId;
  const winner = nameOf(winnerId);
  const loser = nameOf(loserId);
  const ws = homeWin ? result.homeScore : result.awayScore;
  const ls = homeWin ? result.awayScore : result.homeScore;
  const margin = ws - ls;
  const minutes = result.minutes ?? (log?.some((e) => e.t.startsWith("OT")) ? 45 : 40);
  const homeBox = result.homeBox;
  const awayBox = result.awayBox;
  const homePoss = homeBox?.poss ?? clamp(Math.round((result.homeScore + result.awayScore) / 2.12), 60, 80);
  const awayPoss = awayBox?.poss ?? homePoss;
  const homeLeaders = usable(lines?.home, result.homeScore) ?? boxPlayers(state, result.homeId, result.homeScore, homeBox?.fga ?? 62, minutes, rng);
  const awayLeaders = usable(lines?.away, result.awayScore) ?? boxPlayers(state, result.awayId, result.awayScore, awayBox?.fga ?? 62, minutes, rng);
  const star = (homeWin ? homeLeaders : awayLeaders)[0];
  const floor = siteLine(site, kind);
  const tone = marginTone(margin, winner, loser, floor);
  const played = Boolean(log && log.length > 8);
  const keyPlay = (played ? keyFromLog(log , homeWin) : null)
    ?? (star
      ? `${star.name} had ${star.pts} for the ${mascotOf(winnerId)} on ${star.fgm}-${star.fga} from the floor.`
      : `${winner} ${ws}, ${loser} ${ls}.`);
  const homePpp = Math.round((result.homeScore / homePoss) * 100) / 100;
  const awayPpp = Math.round((result.awayScore / awayPoss) * 100) / 100;
  const you = state.playerTeamId;
  const youWin = winnerId === you;
  const youIn = result.homeId === you || result.awayId === you;
  const grafs           = [];
  grafs.push(
    `${home} ${result.homeScore}, ${away} ${result.awayScore}. ${KIND[kind]} · week ${result.week} · ${floor}. ${played ? "You called it." : "The board played it out."}`,
  );
  if (star) {
    grafs.push(
      `${star.name} led ${winner} with ${star.pts} points (${star.fgm}-${star.fga} FG${star.tpm != null ? `, ${star.tpm}-${star.tpa} 3PT` : ""}${star.ftm != null ? `, ${star.ftm}-${star.fta} FT` : ""}) in ${star.min} minutes.`,
    );
  }
  const pppLine = homeWin
    ? `${home} scored ${homePpp.toFixed(2)} per trip. ${away} sat at ${awayPpp.toFixed(2)}.`
    : `${away} scored ${awayPpp.toFixed(2)} per trip. ${home} sat at ${homePpp.toFixed(2)}.`;
  grafs.push(pppLine);
  if (youIn) {
    grafs.push(youWin
      ? `The record moves. The locker room will take it. The next one is already on the calendar.`
      : `That's a loss you have to sit with. The tape will be short and unkind.`);
  }
  const notes           = [
    `${mascotOf(result.homeId)} ${homeBox?.fga ?? "—"} shots, ${homeBox?.to ?? "—"} turnovers, ${homeBox?.orb ?? "—"} offensive boards.`,
    `${mascotOf(result.awayId)} ${awayBox?.fga ?? "—"} shots, ${awayBox?.to ?? "—"} turnovers, ${awayBox?.orb ?? "—"} offensive boards.`,
  ];
  if (minutes > 40) notes.push(`This one needed overtime (${minutes} minutes).`);
  if (margin <= 3) notes.push("Final margin: one possession.");
  else if (margin >= 18) notes.push(`Final margin: ${margin}. It was over before the last media.`);
  const run = played ? biggestRun(log ) : null;
  if (run) notes.push(`${run.pts}-0 run for the ${run.side === "home" ? mascotOf(result.homeId) : mascotOf(result.awayId)}.`);

  return {
    headline: `${tone.headline}, ${ws}–${ls}`,
    lede: tone.lede,
    grafs,
    notes,
    keyPlay,
    played,
    homeLeaders,
    awayLeaders,
    homePpp,
    awayPpp,
    homeTo: homeBox?.to ?? 0,
    awayTo: awayBox?.to ?? 0,
    homeOrb: homeBox?.orb ?? 0,
    awayOrb: awayBox?.orb ?? 0,
  };
}

export function recapFor(state           , result            )            {
  if (result.recap?.headline && result.recap.homeLeaders?.length) return result.recap;
  const slot = state.schedule.find((g) => g.id === result.slotId);
  const rng = mulberry32(state.seed ^ hashString(result.id) ^ 0x1ec);
  return buildRecap(state, slot, result, rng);
}

export function withRecap(state           , result            , log              , lines                                               )             {
  if (result.recap?.headline) return result;
  const youIn = result.homeId === state.playerTeamId || result.awayId === state.playerTeamId;
  if (!youIn) return result;
  const slot = state.schedule.find((g) => g.id === result.slotId);
  const rng = mulberry32(state.seed ^ hashString(result.id) ^ 0x1ec);
  return { ...result, recap: buildRecap(state, slot, result, rng, log, lines) };
}
