                                                                
import { TEAM_BY_ID } from "./teams.js";
import { kenpom } from "./ranks.js";
import { clamp } from "./rng.js";

                             
                 
               
                 
                 
                         
                         
                     
                
                 
                 
                  
                  
                
                 
                    
 

export function emptySheet()              {
  return { picks: [], wins: 0, losses: 0, pushes: 0 };
}

function roundHalf(n        ) {
  const r = Math.round(n * 2) / 2;
  return Object.is(r, -0) ? 0 : r;
}

function pythag(pf        , pa        ) {
  const a = Math.pow(Math.max(1, pf), 10.25);
  const b = Math.pow(Math.max(1, pa), 10.25);
  return a / (a + b);
}

export function american(p        ) {
  const x = clamp(p, 0.08, 0.92);
  if (x >= 0.5) return -Math.round((x / (1 - x)) * 100);
  return Math.round(((1 - x) / x) * 100);
}

function juice(p        ) {
  if (p >= 0.5) return clamp(p + 0.018, 0.5, 0.92);
  return clamp(p - 0.018, 0.08, 0.5);
}

export function hangLine(state           , slot          )             {
  const kp = kenpom(state);
  const home = kp.find((r) => r.id === slot.homeId);
  const away = kp.find((r) => r.id === slot.awayId);
  const neutral = slot.site === "neutral" || slot.kind === "mte" || slot.kind === "ncaa" || slot.kind === "nit" || slot.kind === "crown" || slot.kind === "conf-tourney";
  const hca = neutral ? 0 : 3.2;
  const tempo = ((home?.adjT ?? 68.4) + (away?.adjT ?? 68.4)) / 2;
  const expHome = tempo * ((home?.adjO ?? 100) / 100) * ((away?.adjD ?? 100) / 100) + hca / 2;
  const expAway = tempo * ((away?.adjO ?? 100) / 100) * ((home?.adjD ?? 100) / 100) - hca / 2;
  const margin = expHome - expAway;
  const pHome = juice(pythag(expHome, expAway));
  return {
    slotId: slot.id,
    week: slot.week,
    homeId: slot.homeId,
    awayId: slot.awayId,
    kind: slot.kind,
    site: slot.site,
    homeSpread: roundHalf(-margin),
    total: roundHalf(expHome + expAway),
    mlHome: american(pHome),
    mlAway: american(1 - pHome),
    expHome: Math.round(expHome * 10) / 10,
    expAway: Math.round(expAway * 10) / 10,
    pHome,
    yours: slot.homeId === state.playerTeamId || slot.awayId === state.playerTeamId,
    resultId: slot.resultId,
  };
}

export function weekCard(state           , week = state.week || 1)               {
  const kp = kenpom(state);
  const rank = (id        ) => kp.find((r) => r.id === id)?.rank ?? 200;
  const open = state.schedule.filter((g) => !g.declined && g.week === week);
  const yours = open.filter((g) => g.homeId === state.playerTeamId || g.awayId === state.playerTeamId);
  const rest = open
    .filter((g) => g.homeId !== state.playerTeamId && g.awayId !== state.playerTeamId)
    .sort((a, b) => Math.min(rank(a.homeId), rank(a.awayId)) - Math.min(rank(b.homeId), rank(b.awayId)));
  const seen = new Set        ();
  const list             = [];
  for (const g of [...yours, ...rest]) {
    if (seen.has(g.id)) continue;
    seen.add(g.id);
    list.push(g);
    if (list.length >= 32) break;
  }
  return list.map((g) => hangLine(state, g));
}

export function mlLabel(n        ) {
  return n > 0 ? `+${n}` : `${n}`;
}

export function spreadLabel(n        ) {
  if (n === 0) return "PK";
  return n > 0 ? `+${n}` : `${n}`;
}

export function spreadText(homeSpread        , homeAbbr        , awayAbbr        ) {
  if (homeSpread === 0) return `${homeAbbr} PK`;
  if (homeSpread < 0) return `${homeAbbr} ${homeSpread}`;
  return `${awayAbbr} ${-homeSpread}`;
}

export function teamAbbr(id        ) {
  return TEAM_BY_ID[id]?.abbr ?? id;
}
